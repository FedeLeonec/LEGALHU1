"use server"

import { createServerSupabaseClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

export async function getCasos() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase
    .from("casos")
    .select(`
      *,
      clientes (
        id,
        nombre
      )
    `)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error al obtener casos:", error)
    throw new Error("No se pudieron cargar los casos")
  }

  return data
}

export async function getCasoById(id: string) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase
    .from("casos")
    .select(`
      *,
      clientes (
        id,
        nombre
      ),
      documentos (*)
    `)
    .eq("id", id)
    .single()

  if (error) {
    console.error("Error al obtener caso:", error)
    throw new Error("No se pudo cargar el caso")
  }

  return data
}

export async function createCaso(caso: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("casos").insert([caso]).select()

  if (error) {
    console.error("Error al crear caso:", error)
    throw new Error("No se pudo crear el caso")
  }

  revalidatePath("/casos")
  revalidatePath("/dashboard")
  return data[0]
}

export async function updateCaso(id: string, caso: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("casos").update(caso).eq("id", id).select()

  if (error) {
    console.error("Error al actualizar caso:", error)
    throw new Error("No se pudo actualizar el caso")
  }

  revalidatePath("/casos")
  revalidatePath("/dashboard")
  return data[0]
}

export async function deleteCaso(id: string) {
  const supabase = createServerSupabaseClient()

  // Primero eliminar documentos asociados
  const { error: docError } = await supabase.from("documentos").delete().eq("caso_id", id)

  if (docError) {
    console.error("Error al eliminar documentos del caso:", docError)
    throw new Error("No se pudieron eliminar los documentos asociados al caso")
  }

  // Luego eliminar el caso
  const { error } = await supabase.from("casos").delete().eq("id", id)

  if (error) {
    console.error("Error al eliminar caso:", error)
    throw new Error("No se pudo eliminar el caso")
  }

  revalidatePath("/casos")
  revalidatePath("/dashboard")
  return true
}

export async function countCasos() {
  const supabase = createServerSupabaseClient()
  const { count, error } = await supabase.from("casos").select("*", { count: "exact", head: true })

  if (error) {
    console.error("Error al contar casos:", error)
    throw new Error("No se pudieron contar los casos")
  }

  return count || 0
}
