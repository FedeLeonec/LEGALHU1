"use server"

import { createServerSupabaseClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

export async function getTareas() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("tareas").select("*").order("created_at", { ascending: false })

  if (error) {
    console.error("Error al obtener tareas:", error)
    throw new Error("No se pudieron cargar las tareas")
  }

  return data
}

export async function getTareaById(id: string) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("tareas").select("*").eq("id", id).single()

  if (error) {
    console.error("Error al obtener tarea:", error)
    throw new Error("No se pudo cargar la tarea")
  }

  return data
}

export async function createTarea(tarea: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("tareas").insert([tarea]).select()

  if (error) {
    console.error("Error al crear tarea:", error)
    throw new Error("No se pudo crear la tarea")
  }

  revalidatePath("/tareas")
  revalidatePath("/dashboard")
  return data[0]
}

export async function updateTarea(id: string, tarea: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("tareas").update(tarea).eq("id", id).select()

  if (error) {
    console.error("Error al actualizar tarea:", error)
    throw new Error("No se pudo actualizar la tarea")
  }

  revalidatePath("/tareas")
  revalidatePath("/dashboard")
  return data[0]
}

export async function deleteTarea(id: string) {
  const supabase = createServerSupabaseClient()
  const { error } = await supabase.from("tareas").delete().eq("id", id)

  if (error) {
    console.error("Error al eliminar tarea:", error)
    throw new Error("No se pudo eliminar la tarea")
  }

  revalidatePath("/tareas")
  revalidatePath("/dashboard")
  return true
}

export async function getRecentTareas(limit = 5) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase
    .from("tareas")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(limit)

  if (error) {
    console.error("Error al obtener tareas recientes:", error)
    throw new Error("No se pudieron cargar las tareas recientes")
  }

  return data
}
