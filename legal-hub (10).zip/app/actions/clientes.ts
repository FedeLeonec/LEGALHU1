"use server"

import { createServerSupabaseClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

export async function getClientes() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("clientes").select("*").order("created_at", { ascending: false })

  if (error) {
    console.error("Error al obtener clientes:", error)
    throw new Error("No se pudieron cargar los clientes")
  }

  return data
}

export async function getClienteById(id: string) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("clientes").select("*").eq("id", id).single()

  if (error) {
    console.error("Error al obtener cliente:", error)
    throw new Error("No se pudo cargar el cliente")
  }

  return data
}

export async function createCliente(cliente: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("clientes").insert([cliente]).select()

  if (error) {
    console.error("Error al crear cliente:", error)
    throw new Error("No se pudo crear el cliente")
  }

  revalidatePath("/clientes")
  revalidatePath("/dashboard")
  return data[0]
}

export async function updateCliente(id: string, cliente: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("clientes").update(cliente).eq("id", id).select()

  if (error) {
    console.error("Error al actualizar cliente:", error)
    throw new Error("No se pudo actualizar el cliente")
  }

  revalidatePath("/clientes")
  revalidatePath("/dashboard")
  return data[0]
}

export async function deleteCliente(id: string) {
  const supabase = createServerSupabaseClient()
  const { error } = await supabase.from("clientes").delete().eq("id", id)

  if (error) {
    console.error("Error al eliminar cliente:", error)
    throw new Error("No se pudo eliminar el cliente")
  }

  revalidatePath("/clientes")
  revalidatePath("/dashboard")
  return true
}

export async function countClientes() {
  const supabase = createServerSupabaseClient()
  const { count, error } = await supabase.from("clientes").select("*", { count: "exact", head: true })

  if (error) {
    console.error("Error al contar clientes:", error)
    throw new Error("No se pudieron contar los clientes")
  }

  return count || 0
}
