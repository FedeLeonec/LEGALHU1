"use server"

import { createServerSupabaseClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

export async function getEventos() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("eventos").select("*").order("fecha_inicio", { ascending: true })

  if (error) {
    console.error("Error al obtener eventos:", error)
    throw new Error("No se pudieron cargar los eventos")
  }

  return data
}

export async function getEventosByMonth(año: number, mes: number) {
  const supabase = createServerSupabaseClient()

  // Crear fechas para el inicio y fin del mes
  const fechaInicio = new Date(año, mes - 1, 1).toISOString()
  const fechaFin = new Date(año, mes, 0, 23, 59, 59).toISOString()

  const { data, error } = await supabase
    .from("eventos")
    .select("*")
    .or(`fecha_inicio.gte.${fechaInicio},fecha_fin.gte.${fechaInicio}`)
    .lt("fecha_inicio", fechaFin)
    .order("fecha_inicio", { ascending: true })

  if (error) {
    console.error("Error al obtener eventos del mes:", error)
    throw new Error("No se pudieron cargar los eventos del mes")
  }

  return data
}

export async function getProximosEventos(limit = 5) {
  const supabase = createServerSupabaseClient()
  const ahora = new Date().toISOString()

  const { data, error } = await supabase
    .from("eventos")
    .select("*")
    .gte("fecha_inicio", ahora)
    .order("fecha_inicio", { ascending: true })
    .limit(limit)

  if (error) {
    console.error("Error al obtener próximos eventos:", error)
    throw new Error("No se pudieron cargar los próximos eventos")
  }

  return data
}

export async function createEvento(evento: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("eventos").insert([evento]).select()

  if (error) {
    console.error("Error al crear evento:", error)
    throw new Error("No se pudo crear el evento")
  }

  revalidatePath("/calendario")
  revalidatePath("/dashboard")
  return data[0]
}

export async function updateEvento(id: string, evento: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("eventos").update(evento).eq("id", id).select()

  if (error) {
    console.error("Error al actualizar evento:", error)
    throw new Error("No se pudo actualizar el evento")
  }

  revalidatePath("/calendario")
  revalidatePath("/dashboard")
  return data[0]
}

export async function deleteEvento(id: string) {
  const supabase = createServerSupabaseClient()
  const { error } = await supabase.from("eventos").delete().eq("id", id)

  if (error) {
    console.error("Error al eliminar evento:", error)
    throw new Error("No se pudo eliminar el evento")
  }

  revalidatePath("/calendario")
  revalidatePath("/dashboard")
  return true
}
