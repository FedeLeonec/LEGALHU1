"use server"

import { createServerSupabaseClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

export async function getTransacciones() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("transacciones").select("*").order("fecha", { ascending: false })

  if (error) {
    console.error("Error al obtener transacciones:", error)
    throw new Error("No se pudieron cargar las transacciones")
  }

  return data
}

export async function createTransaccion(transaccion: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("transacciones").insert([transaccion]).select()

  if (error) {
    console.error("Error al crear transacción:", error)
    throw new Error("No se pudo crear la transacción")
  }

  revalidatePath("/contabilidad")
  revalidatePath("/dashboard")
  return data[0]
}

export async function updateTransaccion(id: string, transaccion: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("transacciones").update(transaccion).eq("id", id).select()

  if (error) {
    console.error("Error al actualizar transacción:", error)
    throw new Error("No se pudo actualizar la transacción")
  }

  revalidatePath("/contabilidad")
  revalidatePath("/dashboard")
  return data[0]
}

export async function deleteTransaccion(id: string) {
  const supabase = createServerSupabaseClient()
  const { error } = await supabase.from("transacciones").delete().eq("id", id)

  if (error) {
    console.error("Error al eliminar transacción:", error)
    throw new Error("No se pudo eliminar la transacción")
  }

  revalidatePath("/contabilidad")
  revalidatePath("/dashboard")
  return true
}

export async function getIngresosMensuales(mes: number, año: number) {
  const supabase = createServerSupabaseClient()

  // Crear fechas para el inicio y fin del mes
  const fechaInicio = new Date(año, mes - 1, 1).toISOString().split("T")[0]
  const fechaFin = new Date(año, mes, 0).toISOString().split("T")[0]

  const { data, error } = await supabase
    .from("transacciones")
    .select("monto")
    .eq("tipo", "Ingreso")
    .gte("fecha", fechaInicio)
    .lte("fecha", fechaFin)

  if (error) {
    console.error("Error al obtener ingresos mensuales:", error)
    throw new Error("No se pudieron cargar los ingresos mensuales")
  }

  // Sumar todos los montos
  const total = data.reduce((sum, item) => sum + Number.parseFloat(item.monto), 0)
  return total
}

export async function getEgresosMensuales(mes: number, año: number) {
  const supabase = createServerSupabaseClient()

  // Crear fechas para el inicio y fin del mes
  const fechaInicio = new Date(año, mes - 1, 1).toISOString().split("T")[0]
  const fechaFin = new Date(año, mes, 0).toISOString().split("T")[0]

  const { data, error } = await supabase
    .from("transacciones")
    .select("monto")
    .eq("tipo", "Egreso")
    .gte("fecha", fechaInicio)
    .lte("fecha", fechaFin)

  if (error) {
    console.error("Error al obtener egresos mensuales:", error)
    throw new Error("No se pudieron cargar los egresos mensuales")
  }

  // Sumar todos los montos (en valor absoluto)
  const total = data.reduce((sum, item) => sum + Math.abs(Number.parseFloat(item.monto)), 0)
  return total
}

export async function getSaldoActual() {
  const supabase = createServerSupabaseClient()

  const { data, error } = await supabase.from("transacciones").select("tipo, monto")

  if (error) {
    console.error("Error al obtener saldo actual:", error)
    throw new Error("No se pudo cargar el saldo actual")
  }

  // Calcular saldo sumando ingresos y restando egresos
  const saldo = data.reduce((sum, item) => {
    if (item.tipo === "Ingreso") {
      return sum + Number.parseFloat(item.monto)
    } else if (item.tipo === "Egreso") {
      return sum - Math.abs(Number.parseFloat(item.monto))
    }
    return sum
  }, 0)

  return saldo
}

export async function countCasosMensuales(mes: number, año: number) {
  const supabase = createServerSupabaseClient()

  // Crear fechas para el inicio y fin del mes
  const fechaInicio = new Date(año, mes - 1, 1).toISOString()
  const fechaFin = new Date(año, mes, 0, 23, 59, 59).toISOString()

  const { count, error } = await supabase
    .from("casos")
    .select("*", { count: "exact", head: true })
    .gte("created_at", fechaInicio)
    .lte("created_at", fechaFin)

  if (error) {
    console.error("Error al contar casos mensuales:", error)
    throw new Error("No se pudieron contar los casos mensuales")
  }

  return count || 0
}
