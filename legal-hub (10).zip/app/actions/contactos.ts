"use server"

import { createServerSupabaseClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

export async function getCategorias() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("categorias_contactos").select("*").order("nombre", { ascending: true })

  if (error) {
    console.error("Error al obtener categorías:", error)
    throw new Error("No se pudieron cargar las categorías")
  }

  return data
}

export async function createCategoria(categoria: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("categorias_contactos").insert([categoria]).select()

  if (error) {
    console.error("Error al crear categoría:", error)
    throw new Error("No se pudo crear la categoría")
  }

  revalidatePath("/contactos")
  return data[0]
}

export async function getContactosByCategoria(categoriaId: string) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase
    .from("contactos")
    .select("*")
    .eq("categoria_id", categoriaId)
    .order("nombre", { ascending: true })

  if (error) {
    console.error("Error al obtener contactos por categoría:", error)
    throw new Error("No se pudieron cargar los contactos")
  }

  return data
}

export async function createContacto(contacto: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("contactos").insert([contacto]).select()

  if (error) {
    console.error("Error al crear contacto:", error)
    throw new Error("No se pudo crear el contacto")
  }

  revalidatePath("/contactos")
  return data[0]
}

export async function updateContacto(id: string, contacto: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("contactos").update(contacto).eq("id", id).select()

  if (error) {
    console.error("Error al actualizar contacto:", error)
    throw new Error("No se pudo actualizar el contacto")
  }

  revalidatePath("/contactos")
  return data[0]
}

export async function deleteContacto(id: string) {
  const supabase = createServerSupabaseClient()
  const { error } = await supabase.from("contactos").delete().eq("id", id)

  if (error) {
    console.error("Error al eliminar contacto:", error)
    throw new Error("No se pudo eliminar el contacto")
  }

  revalidatePath("/contactos")
  return true
}
