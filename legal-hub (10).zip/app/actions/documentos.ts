"use server"

import { createServerSupabaseClient } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

export async function getDocumentos() {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase
    .from("documentos")
    .select(`
      *,
      casos (
        id,
        nombre
      )
    `)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error al obtener documentos:", error)
    throw new Error("No se pudieron cargar los documentos")
  }

  return data
}

export async function getDocumentosByCasoId(casoId: string) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase
    .from("documentos")
    .select("*")
    .eq("caso_id", casoId)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error al obtener documentos del caso:", error)
    throw new Error("No se pudieron cargar los documentos del caso")
  }

  return data
}

export async function getDocumentoById(id: string) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase
    .from("documentos")
    .select(`
      *,
      casos (
        id,
        nombre
      )
    `)
    .eq("id", id)
    .single()

  if (error) {
    console.error("Error al obtener documento:", error)
    throw new Error("No se pudo cargar el documento")
  }

  return data
}

export async function createDocumento(documento: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("documentos").insert([documento]).select()

  if (error) {
    console.error("Error al crear documento:", error)
    throw new Error("No se pudo crear el documento")
  }

  revalidatePath("/documentos")
  if (documento.caso_id) {
    revalidatePath(`/casos/${documento.caso_id}`)
  }
  return data[0]
}

export async function updateDocumento(id: string, documento: any) {
  const supabase = createServerSupabaseClient()
  const { data, error } = await supabase.from("documentos").update(documento).eq("id", id).select()

  if (error) {
    console.error("Error al actualizar documento:", error)
    throw new Error("No se pudo actualizar el documento")
  }

  revalidatePath("/documentos")
  if (documento.caso_id) {
    revalidatePath(`/casos/${documento.caso_id}`)
  }
  return data[0]
}

export async function deleteDocumento(id: string) {
  const supabase = createServerSupabaseClient()
  const { error } = await supabase.from("documentos").delete().eq("id", id)

  if (error) {
    console.error("Error al eliminar documento:", error)
    throw new Error("No se pudo eliminar el documento")
  }

  revalidatePath("/documentos")
  return true
}
