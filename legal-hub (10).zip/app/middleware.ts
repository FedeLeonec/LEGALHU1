import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Obtener la ruta actual
  const path = request.nextUrl.pathname

  // Verificar si es una ruta protegida (todas excepto login y archivos estáticos)
  const isProtectedRoute = !path.startsWith("/login") && !path.includes("/_next") && !path.includes("/favicon.ico")

  // Obtener el token de autenticación de las cookies
  const isAuthenticated = request.cookies.get("isAuthenticated")?.value === "true"

  // Si es una ruta protegida y no está autenticado, redirigir al login
  if (isProtectedRoute && !isAuthenticated) {
    const url = new URL("/login", request.url)
    return NextResponse.redirect(url)
  }

  // Si está autenticado y va al login, redirigir al dashboard
  if (path === "/login" && isAuthenticated) {
    const url = new URL("/dashboard", request.url)
    return NextResponse.redirect(url)
  }

  // Continuar con la solicitud
  return NextResponse.next()
}

// Configurar las rutas que deben ser manejadas por el middleware
export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
}
