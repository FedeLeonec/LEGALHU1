import { NotificacionesManager } from "@/components/notificaciones/notificaciones-manager"

export default function NotificacionesPage() {
  return <NotificacionesManager />
}
