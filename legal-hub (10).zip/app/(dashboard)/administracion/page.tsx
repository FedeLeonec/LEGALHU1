import { AdministracionManager } from "@/components/administracion/administracion-manager"

export default function AdministracionPage() {
  return <AdministracionManager />
}
