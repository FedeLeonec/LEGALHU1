import { ClientesManager } from "@/components/clientes/clientes-manager"

export default function ClientesPage() {
  return <ClientesManager />
}
