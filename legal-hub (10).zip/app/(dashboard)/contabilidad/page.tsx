import { ContabilidadManager } from "@/components/contabilidad/contabilidad-manager"

export default function ContabilidadPage() {
  return <ContabilidadManager />
}
