import { DashboardMetrics } from "@/components/dashboard/dashboard-metrics"
import { ImportantDeadlines } from "@/components/dashboard/important-deadlines"
import { RecentClients } from "@/components/dashboard/recent-clients"

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <DashboardMetrics />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ImportantDeadlines />
        <RecentClients />
      </div>
    </div>
  )
}
