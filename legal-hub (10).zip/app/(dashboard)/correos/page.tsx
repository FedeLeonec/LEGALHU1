import { CorreosManager } from "@/components/correos/correos-manager"

export default function CorreosPage() {
  return <CorreosManager />
}
