import { ArchivosManager } from "@/components/archivos/archivos-manager"

export default function ArchivosPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Archivos</h1>
      </div>
      <ArchivosManager />
    </div>
  )
}
