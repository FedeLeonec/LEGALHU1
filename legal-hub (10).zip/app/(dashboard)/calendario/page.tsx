import { CalendarioManager } from "@/components/calendario/calendario-manager"

export default function CalendarioPage() {
  return <CalendarioManager />
}
