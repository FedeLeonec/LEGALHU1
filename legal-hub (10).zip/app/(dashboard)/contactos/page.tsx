import { ContactosManager } from "@/components/contactos/contactos-manager"

export default function ContactosPage() {
  return <ContactosManager />
}
