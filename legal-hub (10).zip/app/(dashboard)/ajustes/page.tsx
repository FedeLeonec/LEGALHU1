import { AjustesManager } from "@/components/ajustes/ajustes-manager"

export default function AjustesPage() {
  return <AjustesManager />
}
