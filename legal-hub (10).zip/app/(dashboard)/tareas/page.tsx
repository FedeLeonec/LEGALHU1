import { TareasManager } from "@/components/tareas/tareas-manager"

export default function TareasPage() {
  return <TareasManager />
}
