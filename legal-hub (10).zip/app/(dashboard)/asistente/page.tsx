import { AsistenteLegal } from "@/components/asistente/asistente-legal"

export default function AsistentePage() {
  return <AsistenteLegal />
}
