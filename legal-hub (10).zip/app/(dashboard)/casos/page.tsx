import { CasosManager } from "@/components/casos/casos-manager"

export default function CasosPage() {
  return <CasosManager />
}
