import { DocumentosManager } from "@/components/documentos/documentos-manager"

export default function DocumentosPage() {
  return <DocumentosManager />
}
