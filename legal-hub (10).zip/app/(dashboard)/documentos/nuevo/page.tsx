import { SimpleDocumentoEditor } from "@/components/documentos/simple-documento-editor"

export default function NuevoDocumentoPage() {
  return <SimpleDocumentoEditor />
}
