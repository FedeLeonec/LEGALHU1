"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Search, Plus, Eye, Pencil, Trash2, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Switch } from "@/components/ui/switch"
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth/auth-provider"
import { jsPDF } from "jspdf"
import autoTable from "jspdf-autotable"

interface Cliente {
  id: string
  nombre: string
  estado: boolean
  caso: string
  telefono: string
  email: string
  direccion: string
  notas: string
  empresa: string
  fechaCreacion: string
}

export function ClientesManager() {
  const { user } = useAuth()
  const [clients, setClients] = useState<Cliente[]>([])
  const [filterType, setFilterType] = useState("ID")
  const [searchQuery, setSearchQuery] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [isAddClientModalOpen, setIsAddClientModalOpen] = useState(false)
  const [isViewClientModalOpen, setIsViewClientModalOpen] = useState(false)
  const [isEditClientModalOpen, setIsEditClientModalOpen] = useState(false)
  const [currentClient, setCurrentClient] = useState<Cliente | null>(null)
  const { toast } = useToast()
  const itemsPerPage = 5

  // Nuevo cliente
  const [newClient, setNewClient] = useState<Omit<Cliente, "id" | "fechaCreacion">>({
    nombre: "",
    estado: true,
    caso: "",
    telefono: "",
    email: "",
    direccion: "",
    notas: "",
    empresa: user?.empresa || "",
  })

  // Cargar clientes al iniciar
  useEffect(() => {
    const storedClients = localStorage.getItem("clients")
    if (storedClients) {
      try {
        setClients(JSON.parse(storedClients))
      } catch (error) {
        console.error("Error al cargar clientes:", error)
      }
    } else {
      // No inicializamos con clientes de ejemplo para mantener la plataforma limpia
      setClients([])
      localStorage.setItem("clients", JSON.stringify([]))
    }
  }, [])

  // Guardar clientes cuando cambien
  useEffect(() => {
    if (clients.length > 0) {
      localStorage.setItem("clients", JSON.stringify(clients))
    }
  }, [clients])

  const toggleClientStatus = (clientId: string) => {
    setClients((currentClients) =>
      currentClients.map((client) => (client.id === clientId ? { ...client, estado: !client.estado } : client)),
    )
  }

  const handleAddClient = () => {
    setNewClient({
      nombre: "",
      estado: true,
      caso: "",
      telefono: "",
      email: "",
      direccion: "",
      notas: "",
      empresa: user?.empresa || "",
    })
    setIsAddClientModalOpen(true)
  }

  const handleViewClient = (client: Cliente) => {
    setCurrentClient(client)
    setIsViewClientModalOpen(true)
  }

  const handleEditClient = (client: Cliente) => {
    setCurrentClient(client)
    setIsEditClientModalOpen(true)
  }

  const handleDeleteClient = (clientId: string, clientName: string) => {
    if (
      window.confirm(`¿Está seguro que desea eliminar al cliente "${clientName}"? Esta acción no se puede deshacer.`)
    ) {
      setClients((currentClients) => currentClients.filter((client) => client.id !== clientId))
      toast({
        title: "Cliente eliminado",
        description: `El cliente ${clientName} ha sido eliminado`,
      })
    }
  }

  const handleClientSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validar datos
    if (!newClient.nombre || !newClient.telefono || !newClient.email) {
      toast({
        title: "Error",
        description: "Nombre, teléfono y email son obligatorios",
        variant: "destructive",
      })
      return
    }

    // Crear nuevo cliente
    const clientToAdd = {
      ...newClient,
      id: `CL-${Date.now()}`,
      fechaCreacion: new Date().toISOString(),
    }

    setClients((prev) => [...prev, clientToAdd])
    setIsAddClientModalOpen(false)

    toast({
      title: "Cliente creado",
      description: `El cliente ${newClient.nombre} ha sido creado con éxito`,
    })
  }

  const handleUpdateClient = (e: React.FormEvent) => {
    e.preventDefault()
    if (!currentClient) return

    // Validar datos
    if (!currentClient.nombre || !currentClient.telefono || !currentClient.email) {
      toast({
        title: "Error",
        description: "Nombre, teléfono y email son obligatorios",
        variant: "destructive",
      })
      return
    }

    // Actualizar cliente
    setClients((currentClients) =>
      currentClients.map((client) => (client.id === currentClient.id ? currentClient : client)),
    )

    setIsEditClientModalOpen(false)
    setCurrentClient(null)

    toast({
      title: "Cliente actualizado",
      description: `El cliente ${currentClient.nombre} ha sido actualizado con éxito`,
    })
  }

  const exportToPDF = () => {
    const doc = new jsPDF()

    // Título
    doc.setFontSize(18)
    doc.text("Listado de Clientes", 14, 22)

    // Fecha
    doc.setFontSize(11)
    doc.text(`Fecha: ${new Date().toLocaleDateString()}`, 14, 30)

    // Tabla
    autoTable(doc, {
      head: [["ID", "Nombre", "Caso", "Teléfono", "Email", "Estado"]],
      body: filteredClients.map((client) => [
        client.id,
        client.nombre,
        client.caso,
        client.telefono,
        client.email,
        client.estado ? "Activo" : "Inactivo",
      ]),
      startY: 35,
      theme: "striped",
      headStyles: { fillColor: [230, 126, 34] },
    })

    // Guardar PDF
    doc.save("listado-clientes.pdf")

    toast({
      title: "PDF generado",
      description: "El listado de clientes ha sido exportado a PDF",
    })
  }

  // Filtrar clientes según los criterios seleccionados y la empresa del usuario
  const filteredClients = clients.filter((client) => {
    // Filtrar por empresa del usuario actual (excepto SuperAdmin que ve todos)
    const matchesEmpresa = user?.role === "SuperAdmin" || client.empresa === user?.empresa

    // Aplicar búsqueda según el tipo de filtro
    let matchesSearch = true
    if (searchQuery) {
      switch (filterType) {
        case "ID":
          matchesSearch = client.id.toLowerCase().includes(searchQuery.toLowerCase())
          break
        case "Nombre":
          matchesSearch = client.nombre.toLowerCase().includes(searchQuery.toLowerCase())
          break
        case "Caso":
          matchesSearch = client.caso.toLowerCase().includes(searchQuery.toLowerCase())
          break
        case "Email":
          matchesSearch = client.email.toLowerCase().includes(searchQuery.toLowerCase())
          break
        default:
          matchesSearch =
            client.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
            client.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
            client.caso.toLowerCase().includes(searchQuery.toLowerCase()) ||
            client.email.toLowerCase().includes(searchQuery.toLowerCase())
      }
    }

    return matchesEmpresa && matchesSearch
  })

  // Paginación
  const totalPages = Math.ceil(filteredClients.length / itemsPerPage)
  const paginatedClients = filteredClients.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
          <div className="flex items-center border border-gray-300 rounded-md overflow-hidden focus-within:ring-1 focus-within:ring-orange-500 focus-within:border-orange-500 w-full sm:w-1/3">
            <span className="pl-3 pr-1 text-gray-400">
              <Search size={18} />
            </span>
            <Input
              type="text"
              placeholder="Buscar por nombre, ID, caso..."
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              className="bg-blue-500 text-white hover:bg-blue-600 border-blue-500"
              onClick={exportToPDF}
            >
              <FileText size={16} className="mr-2" />
              Exportar PDF
            </Button>
            <div className="flex items-center text-sm">
              <label htmlFor="filter-cliente-id" className="mr-2 text-gray-600">
                Filtrar:
              </label>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger id="filter-cliente-id" className="w-[120px]">
                  <SelectValue placeholder="ID" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ID">ID</SelectItem>
                  <SelectItem value="Nombre">Nombre</SelectItem>
                  <SelectItem value="Caso">Caso</SelectItem>
                  <SelectItem value="Email">Email</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleAddClient}>
              <Plus size={16} className="mr-2" />
              Cliente
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nombre</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Caso</TableHead>
                <TableHead>Teléfono</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>ID</TableHead>
                <TableHead className="text-center">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedClients.length > 0 ? (
                paginatedClients.map((client) => (
                  <TableRow key={client.id}>
                    <TableCell className="font-medium text-gray-900">{client.nombre}</TableCell>
                    <TableCell>
                      <Switch checked={client.estado} onCheckedChange={() => toggleClientStatus(client.id)} />
                    </TableCell>
                    <TableCell>{client.caso}</TableCell>
                    <TableCell>{client.telefono}</TableCell>
                    <TableCell>{client.email}</TableCell>
                    <TableCell>{client.id}</TableCell>
                    <TableCell className="text-center space-x-2">
                      <Button variant="ghost" size="icon" title="Ver" onClick={() => handleViewClient(client)}>
                        <Eye size={16} className="text-gray-400 hover:text-blue-600" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Editar" onClick={() => handleEditClient(client)}>
                        <Pencil size={16} className="text-gray-400 hover:text-green-600" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        title="Eliminar"
                        onClick={() => handleDeleteClient(client.id, client.nombre)}
                      >
                        <Trash2 size={16} className="text-gray-400 hover:text-red-600" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-4 text-gray-500 italic">
                    No hay clientes para mostrar.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {totalPages > 1 && (
          <Pagination className="mt-4">
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    if (currentPage > 1) setCurrentPage(currentPage - 1)
                  }}
                  className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                />
              </PaginationItem>
              {Array.from({ length: totalPages }).map((_, i) => (
                <PaginationItem key={i}>
                  <PaginationLink
                    href="#"
                    isActive={currentPage === i + 1}
                    onClick={(e) => {
                      e.preventDefault()
                      setCurrentPage(i + 1)
                    }}
                  >
                    {i + 1}
                  </PaginationLink>
                </PaginationItem>
              ))}
              <PaginationItem>
                <PaginationNext
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    if (currentPage < totalPages) setCurrentPage(currentPage + 1)
                  }}
                  className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        )}
      </CardContent>

      {/* Modal para añadir cliente */}
      <Dialog open={isAddClientModalOpen} onOpenChange={setIsAddClientModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Añadir Nuevo Cliente</DialogTitle>
            <DialogDescription>Complete los detalles para crear un nuevo cliente</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleClientSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="nombre">
                  Nombre completo <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="nombre"
                  value={newClient.nombre}
                  onChange={(e) => setNewClient({ ...newClient, nombre: e.target.value })}
                  required
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefono">
                    Teléfono <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="telefono"
                    value={newClient.telefono}
                    onChange={(e) => setNewClient({ ...newClient, telefono: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">
                    Email <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={newClient.email}
                    onChange={(e) => setNewClient({ ...newClient, email: e.target.value })}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="direccion">Dirección</Label>
                <Input
                  id="direccion"
                  value={newClient.direccion}
                  onChange={(e) => setNewClient({ ...newClient, direccion: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="caso">Caso/Asunto</Label>
                <Input
                  id="caso"
                  value={newClient.caso}
                  onChange={(e) => setNewClient({ ...newClient, caso: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="notas">Notas adicionales</Label>
                <Textarea
                  id="notas"
                  value={newClient.notas}
                  onChange={(e) => setNewClient({ ...newClient, notas: e.target.value })}
                  rows={3}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch
                  id="estado"
                  checked={newClient.estado}
                  onCheckedChange={(checked) => setNewClient({ ...newClient, estado: checked })}
                />
                <Label htmlFor="estado">Cliente activo</Label>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsAddClientModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
                Guardar Cliente
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Modal para ver cliente */}
      <Dialog open={isViewClientModalOpen} onOpenChange={setIsViewClientModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Detalles del Cliente</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <h3 className="font-semibold text-lg">{currentClient?.nombre}</h3>
              <p className="text-sm text-gray-500 mt-1">ID: {currentClient?.id}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-gray-500">Teléfono</p>
                <p>{currentClient?.telefono}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Email</p>
                <p>{currentClient?.email}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Dirección</p>
                <p>{currentClient?.direccion || "No especificada"}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Caso/Asunto</p>
                <p>{currentClient?.caso || "No especificado"}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Estado</p>
                <p>{currentClient?.estado ? "Activo" : "Inactivo"}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Fecha de creación</p>
                <p>
                  {currentClient?.fechaCreacion
                    ? new Date(currentClient.fechaCreacion).toLocaleDateString()
                    : "No disponible"}
                </p>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-gray-500">Notas</p>
              <p className="mt-1">{currentClient?.notas || "Sin notas adicionales"}</p>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsViewClientModalOpen(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para editar cliente */}
      <Dialog open={isEditClientModalOpen} onOpenChange={setIsEditClientModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Cliente</DialogTitle>
            <DialogDescription>Modifique los datos del cliente</DialogDescription>
          </DialogHeader>
          {currentClient && (
            <form onSubmit={handleUpdateClient}>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-nombre">
                    Nombre completo <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="edit-nombre"
                    value={currentClient.nombre}
                    onChange={(e) => setCurrentClient({ ...currentClient, nombre: e.target.value })}
                    required
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-telefono">
                      Teléfono <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="edit-telefono"
                      value={currentClient.telefono}
                      onChange={(e) => setCurrentClient({ ...currentClient, telefono: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-email">
                      Email <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="edit-email"
                      type="email"
                      value={currentClient.email}
                      onChange={(e) => setCurrentClient({ ...currentClient, email: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-direccion">Dirección</Label>
                  <Input
                    id="edit-direccion"
                    value={currentClient.direccion}
                    onChange={(e) => setCurrentClient({ ...currentClient, direccion: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-caso">Caso/Asunto</Label>
                  <Input
                    id="edit-caso"
                    value={currentClient.caso}
                    onChange={(e) => setCurrentClient({ ...currentClient, caso: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-notas">Notas adicionales</Label>
                  <Textarea
                    id="edit-notas"
                    value={currentClient.notas}
                    onChange={(e) => setCurrentClient({ ...currentClient, notas: e.target.value })}
                    rows={3}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="edit-estado"
                    checked={currentClient.estado}
                    onCheckedChange={(checked) => setCurrentClient({ ...currentClient, estado: checked })}
                  />
                  <Label htmlFor="edit-estado">Cliente activo</Label>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditClientModalOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
                  Guardar Cambios
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  )
}
