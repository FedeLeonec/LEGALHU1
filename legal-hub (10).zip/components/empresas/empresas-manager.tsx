"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Building, Search, Plus, Edit, Trash2, Eye, CheckCircle, XCircle } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { supabaseClient } from "@/lib/supabase"

export function EmpresasManager() {
  const { user, isSuperAdmin } = useAuth()
  const { toast } = useToast()
  const [empresas, setEmpresas] = useState([])
  const [busqueda, setBusqueda] = useState("")
  const [isCreatingEmpresa, setIsCreatingEmpresa] = useState(false)
  const [isEditingEmpresa, setIsEditingEmpresa] = useState(false)
  const [isViewingEmpresa, setIsViewingEmpresa] = useState(false)
  const [selectedEmpresa, setSelectedEmpresa] = useState(null)
  const [modulos, setModulos] = useState([
    { id: "dashboard", nombre: "Dashboard", activo: true },
    { id: "asistente", nombre: "Asistente Legal", activo: true },
    { id: "documentos", nombre: "Documentos", activo: true },
    { id: "correos", nombre: "Correos", activo: true },
    { id: "calendario", nombre: "Calendario", activo: true },
    { id: "tareas", nombre: "Tareas", activo: true },
    { id: "casos", nombre: "Casos", activo: true },
    { id: "clientes", nombre: "Clientes", activo: true },
    { id: "contactos", nombre: "Contactos", activo: true },
    { id: "contabilidad", nombre: "Contabilidad", activo: true },
    { id: "notificaciones", nombre: "Notificaciones", activo: true },
    { id: "archivos", nombre: "Archivos", activo: true },
    { id: "ajustes", nombre: "Ajustes", activo: true },
  ])

  // Formulario para nueva empresa
  const [nuevaEmpresa, setNuevaEmpresa] = useState({
    nombre: "",
    direccion: "",
    telefono: "",
    email: "",
    sitio_web: "",
    ruc: "",
    modulos: {},
    admin_nombre: "",
    admin_email: "",
    admin_password: "",
  })

  // Verificar si el usuario es SuperAdmin
  useEffect(() => {
    if (!isSuperAdmin()) {
      toast({
        title: "Acceso denegado",
        description: "No tienes permisos para acceder a esta página",
        variant: "destructive",
      })
      // Redirigir al dashboard
      window.location.href = "/dashboard"
    } else {
      cargarEmpresas()
    }
  }, [user])

  // Función para cargar empresas
  const cargarEmpresas = async () => {
    try {
      const { data, error } = await supabaseClient
        .from("empresas")
        .select("*")
        .order("created_at", { ascending: false })

      if (error) throw error

      setEmpresas(data || [])
    } catch (error) {
      console.error("Error al cargar empresas:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar las empresas",
        variant: "destructive",
      })
    }
  }

  // Función para crear una nueva empresa
  const crearEmpresa = async () => {
    try {
      // Validar campos obligatorios
      if (
        !nuevaEmpresa.nombre ||
        !nuevaEmpresa.admin_nombre ||
        !nuevaEmpresa.admin_email ||
        !nuevaEmpresa.admin_password
      ) {
        toast({
          title: "Error",
          description: "Por favor, completa todos los campos obligatorios",
          variant: "destructive",
        })
        return
      }

      // 1. Crear la empresa en la base de datos
      const modulosActivos = {}
      modulos.forEach((modulo) => {
        modulosActivos[modulo.id] = modulo.activo
      })

      const empresaData = {
        nombre: nuevaEmpresa.nombre,
        direccion: nuevaEmpresa.direccion,
        telefono: nuevaEmpresa.telefono,
        email: nuevaEmpresa.email,
        sitio_web: nuevaEmpresa.sitio_web,
        ruc: nuevaEmpresa.ruc,
        modulos: modulosActivos,
        created_at: new Date().toISOString(),
        created_by: user.id,
      }

      const { data: empresaCreada, error: empresaError } = await supabaseClient
        .from("empresas")
        .insert(empresaData)
        .select()

      if (empresaError) throw empresaError

      // 2. Crear el usuario administrador para la empresa
      // Para simplificar, usaremos localStorage para almacenar usuarios
      const users = JSON.parse(localStorage.getItem("users") || "[]")

      // Generar ID único para el usuario
      const userId = `user_${Date.now()}`

      const nuevoUsuario = {
        id: userId,
        nombre: nuevaEmpresa.admin_nombre,
        email: nuevaEmpresa.admin_email,
        password: nuevaEmpresa.admin_password,
        rol: "Admin",
        empresa: empresaCreada[0].id,
        empresa_nombre: empresaCreada[0].nombre,
        estado: true,
        permisos: {
          dashboard: "editar",
          asistente: "editar",
          documentos: "editar",
          correos: "editar",
          calendario: "editar",
          tareas: "editar",
          casos: "editar",
          clientes: "editar",
          contactos: "editar",
          contabilidad: "editar",
          notificaciones: "editar",
          archivos: "editar",
          ajustes: "editar",
          usuarios: "editar",
        },
        created_at: new Date().toISOString(),
      }

      users.push(nuevoUsuario)
      localStorage.setItem("users", JSON.stringify(users))

      toast({
        title: "Empresa creada",
        description: "La empresa y su administrador se han creado correctamente",
      })

      // Limpiar formulario y recargar empresas
      setNuevaEmpresa({
        nombre: "",
        direccion: "",
        telefono: "",
        email: "",
        sitio_web: "",
        ruc: "",
        modulos: {},
        admin_nombre: "",
        admin_email: "",
        admin_password: "",
      })

      // Resetear módulos
      setModulos(modulos.map((m) => ({ ...m, activo: true })))

      setIsCreatingEmpresa(false)
      cargarEmpresas()
    } catch (error) {
      console.error("Error al crear empresa:", error)
      toast({
        title: "Error",
        description: "No se pudo crear la empresa",
        variant: "destructive",
      })
    }
  }

  // Función para editar una empresa
  const editarEmpresa = async () => {
    try {
      // Validar campos obligatorios
      if (!selectedEmpresa.nombre) {
        toast({
          title: "Error",
          description: "El nombre de la empresa es obligatorio",
          variant: "destructive",
        })
        return
      }

      // Actualizar módulos
      const modulosActivos = {}
      modulos.forEach((modulo) => {
        modulosActivos[modulo.id] = modulo.activo
      })

      const empresaData = {
        nombre: selectedEmpresa.nombre,
        direccion: selectedEmpresa.direccion,
        telefono: selectedEmpresa.telefono,
        email: selectedEmpresa.email,
        sitio_web: selectedEmpresa.sitio_web,
        ruc: selectedEmpresa.ruc,
        modulos: modulosActivos,
        updated_at: new Date().toISOString(),
      }

      const { error } = await supabaseClient.from("empresas").update(empresaData).eq("id", selectedEmpresa.id)

      if (error) throw error

      // Actualizar nombre de empresa en usuarios
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const updatedUsers = users.map((user) => {
        if (user.empresa === selectedEmpresa.id) {
          return {
            ...user,
            empresa_nombre: selectedEmpresa.nombre,
          }
        }
        return user
      })

      localStorage.setItem("users", JSON.stringify(updatedUsers))

      toast({
        title: "Empresa actualizada",
        description: "La información de la empresa se ha actualizado correctamente",
      })

      setIsEditingEmpresa(false)
      cargarEmpresas()
    } catch (error) {
      console.error("Error al editar empresa:", error)
      toast({
        title: "Error",
        description: "No se pudo actualizar la empresa",
        variant: "destructive",
      })
    }
  }

  // Función para eliminar una empresa
  const eliminarEmpresa = async (empresa) => {
    if (!confirm(`¿Estás seguro de eliminar la empresa ${empresa.nombre}? Esta acción no se puede deshacer.`)) {
      return
    }

    try {
      // 1. Eliminar la empresa de la base de datos
      const { error } = await supabaseClient.from("empresas").delete().eq("id", empresa.id)

      if (error) throw error

      // 2. Eliminar usuarios asociados a la empresa
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const filteredUsers = users.filter((user) => user.empresa !== empresa.id)
      localStorage.setItem("users", JSON.stringify(filteredUsers))

      toast({
        title: "Empresa eliminada",
        description: "La empresa y sus usuarios asociados se han eliminado correctamente",
      })

      cargarEmpresas()
    } catch (error) {
      console.error("Error al eliminar empresa:", error)
      toast({
        title: "Error",
        description: "No se pudo eliminar la empresa",
        variant: "destructive",
      })
    }
  }

  // Función para ver detalles de una empresa
  const verEmpresa = (empresa) => {
    setSelectedEmpresa(empresa)

    // Configurar módulos según la empresa
    const empresaModulos = empresa.modulos || {}
    setModulos(
      modulos.map((m) => ({
        ...m,
        activo: empresaModulos[m.id] !== undefined ? empresaModulos[m.id] : true,
      })),
    )

    setIsViewingEmpresa(true)
  }

  // Función para preparar edición de empresa
  const prepararEdicion = (empresa) => {
    setSelectedEmpresa(empresa)

    // Configurar módulos según la empresa
    const empresaModulos = empresa.modulos || {}
    setModulos(
      modulos.map((m) => ({
        ...m,
        activo: empresaModulos[m.id] !== undefined ? empresaModulos[m.id] : true,
      })),
    )

    setIsEditingEmpresa(true)
  }

  // Filtrar empresas por búsqueda
  const empresasFiltradas = empresas.filter((empresa) => empresa.nombre.toLowerCase().includes(busqueda.toLowerCase()))

  return (
    <div className="space-y-4">
      {/* Barra de acciones */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar empresas..."
            className="pl-8"
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
          />
        </div>
        <Button onClick={() => setIsCreatingEmpresa(true)} className="bg-orange-500 hover:bg-orange-600">
          <Plus className="mr-2 h-4 w-4" /> Nueva Empresa
        </Button>
      </div>

      {/* Tabla de empresas */}
      {empresasFiltradas.length > 0 ? (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nombre</TableHead>
                <TableHead className="hidden md:table-cell">Email</TableHead>
                <TableHead className="hidden md:table-cell">Teléfono</TableHead>
                <TableHead className="hidden md:table-cell">Fecha de creación</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {empresasFiltradas.map((empresa) => (
                <TableRow key={empresa.id}>
                  <TableCell className="font-medium">{empresa.nombre}</TableCell>
                  <TableCell className="hidden md:table-cell">{empresa.email || "-"}</TableCell>
                  <TableCell className="hidden md:table-cell">{empresa.telefono || "-"}</TableCell>
                  <TableCell className="hidden md:table-cell">
                    {new Date(empresa.created_at).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" onClick={() => verEmpresa(empresa)} title="Ver detalles">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => prepararEdicion(empresa)} title="Editar">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => eliminarEmpresa(empresa)}
                        title="Eliminar"
                        className="text-red-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="text-center py-10 border rounded-lg">
          <Building className="h-12 w-12 mx-auto text-gray-400" />
          <h3 className="mt-4 text-lg font-medium">No hay empresas</h3>
          <p className="mt-1 text-gray-500">
            {busqueda ? "No se encontraron empresas con ese nombre" : "Crea una empresa para comenzar"}
          </p>
        </div>
      )}

      {/* Modal para crear empresa */}
      <Dialog open={isCreatingEmpresa} onOpenChange={setIsCreatingEmpresa}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Crear nueva empresa</DialogTitle>
            <DialogDescription>
              Ingresa la información para crear una nueva empresa y su administrador
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="empresa">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="empresa">Información de Empresa</TabsTrigger>
              <TabsTrigger value="admin">Administrador</TabsTrigger>
            </TabsList>
            <TabsContent value="empresa" className="space-y-4 py-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="nombre">Nombre de la empresa *</Label>
                  <Input
                    id="nombre"
                    value={nuevaEmpresa.nombre}
                    onChange={(e) => setNuevaEmpresa({ ...nuevaEmpresa, nombre: e.target.value })}
                    placeholder="Ej: Bufete Legal XYZ"
                    required
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={nuevaEmpresa.email}
                      onChange={(e) => setNuevaEmpresa({ ...nuevaEmpresa, email: e.target.value })}
                      placeholder="empresa@ejemplo.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="telefono">Teléfono</Label>
                    <Input
                      id="telefono"
                      value={nuevaEmpresa.telefono}
                      onChange={(e) => setNuevaEmpresa({ ...nuevaEmpresa, telefono: e.target.value })}
                      placeholder="+593 99 123 4567"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="direccion">Dirección</Label>
                  <Input
                    id="direccion"
                    value={nuevaEmpresa.direccion}
                    onChange={(e) => setNuevaEmpresa({ ...nuevaEmpresa, direccion: e.target.value })}
                    placeholder="Av. Principal 123"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="sitio_web">Sitio web</Label>
                    <Input
                      id="sitio_web"
                      value={nuevaEmpresa.sitio_web}
                      onChange={(e) => setNuevaEmpresa({ ...nuevaEmpresa, sitio_web: e.target.value })}
                      placeholder="www.ejemplo.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ruc">RUC</Label>
                    <Input
                      id="ruc"
                      value={nuevaEmpresa.ruc}
                      onChange={(e) => setNuevaEmpresa({ ...nuevaEmpresa, ruc: e.target.value })}
                      placeholder="1234567890001"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Módulos activos</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 border rounded-md p-3">
                    {modulos.map((modulo) => (
                      <div key={modulo.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`modulo-${modulo.id}`}
                          checked={modulo.activo}
                          onCheckedChange={(checked) => {
                            setModulos(
                              modulos.map((m) => (m.id === modulo.id ? { ...m, activo: checked === true } : m)),
                            )
                          }}
                        />
                        <label
                          htmlFor={`modulo-${modulo.id}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {modulo.nombre}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="admin" className="space-y-4 py-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="admin_nombre">Nombre del administrador *</Label>
                  <Input
                    id="admin_nombre"
                    value={nuevaEmpresa.admin_nombre}
                    onChange={(e) => setNuevaEmpresa({ ...nuevaEmpresa, admin_nombre: e.target.value })}
                    placeholder="Ej: Juan Pérez"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin_email">Email del administrador *</Label>
                  <Input
                    id="admin_email"
                    type="email"
                    value={nuevaEmpresa.admin_email}
                    onChange={(e) => setNuevaEmpresa({ ...nuevaEmpresa, admin_email: e.target.value })}
                    placeholder="admin@ejemplo.com"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin_password">Contraseña *</Label>
                  <Input
                    id="admin_password"
                    type="password"
                    value={nuevaEmpresa.admin_password}
                    onChange={(e) => setNuevaEmpresa({ ...nuevaEmpresa, admin_password: e.target.value })}
                    placeholder="Contraseña segura"
                    required
                  />
                </div>
                <div className="pt-2 text-sm text-gray-500">
                  <p>El administrador tendrá acceso completo a todos los módulos activos de la empresa.</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreatingEmpresa(false)}>
              Cancelar
            </Button>
            <Button onClick={crearEmpresa} className="bg-orange-500 hover:bg-orange-600">
              Crear empresa
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para editar empresa */}
      <Dialog open={isEditingEmpresa} onOpenChange={setIsEditingEmpresa}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Editar empresa</DialogTitle>
            <DialogDescription>Modifica la información de la empresa</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-nombre">Nombre de la empresa *</Label>
              <Input
                id="edit-nombre"
                value={selectedEmpresa?.nombre || ""}
                onChange={(e) => setSelectedEmpresa({ ...selectedEmpresa, nombre: e.target.value })}
                placeholder="Ej: Bufete Legal XYZ"
                required
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-email">Email</Label>
                <Input
                  id="edit-email"
                  type="email"
                  value={selectedEmpresa?.email || ""}
                  onChange={(e) => setSelectedEmpresa({ ...selectedEmpresa, email: e.target.value })}
                  placeholder="empresa@ejemplo.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-telefono">Teléfono</Label>
                <Input
                  id="edit-telefono"
                  value={selectedEmpresa?.telefono || ""}
                  onChange={(e) => setSelectedEmpresa({ ...selectedEmpresa, telefono: e.target.value })}
                  placeholder="+593 99 123 4567"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-direccion">Dirección</Label>
              <Input
                id="edit-direccion"
                value={selectedEmpresa?.direccion || ""}
                onChange={(e) => setSelectedEmpresa({ ...selectedEmpresa, direccion: e.target.value })}
                placeholder="Av. Principal 123"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-sitio_web">Sitio web</Label>
                <Input
                  id="edit-sitio_web"
                  value={selectedEmpresa?.sitio_web || ""}
                  onChange={(e) => setSelectedEmpresa({ ...selectedEmpresa, sitio_web: e.target.value })}
                  placeholder="www.ejemplo.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-ruc">RUC</Label>
                <Input
                  id="edit-ruc"
                  value={selectedEmpresa?.ruc || ""}
                  onChange={(e) => setSelectedEmpresa({ ...selectedEmpresa, ruc: e.target.value })}
                  placeholder="1234567890001"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Módulos activos</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 border rounded-md p-3">
                {modulos.map((modulo) => (
                  <div key={modulo.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`edit-modulo-${modulo.id}`}
                      checked={modulo.activo}
                      onCheckedChange={(checked) => {
                        setModulos(modulos.map((m) => (m.id === modulo.id ? { ...m, activo: checked === true } : m)))
                      }}
                    />
                    <label
                      htmlFor={`edit-modulo-${modulo.id}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {modulo.nombre}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditingEmpresa(false)}>
              Cancelar
            </Button>
            <Button onClick={editarEmpresa} className="bg-orange-500 hover:bg-orange-600">
              Guardar cambios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para ver detalles de empresa */}
      <Dialog open={isViewingEmpresa} onOpenChange={setIsViewingEmpresa}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Detalles de la empresa</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Nombre</h3>
                <p className="mt-1">{selectedEmpresa?.nombre || "-"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Email</h3>
                <p className="mt-1">{selectedEmpresa?.email || "-"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Teléfono</h3>
                <p className="mt-1">{selectedEmpresa?.telefono || "-"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Dirección</h3>
                <p className="mt-1">{selectedEmpresa?.direccion || "-"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Sitio web</h3>
                <p className="mt-1">{selectedEmpresa?.sitio_web || "-"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">RUC</h3>
                <p className="mt-1">{selectedEmpresa?.ruc || "-"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Fecha de creación</h3>
                <p className="mt-1">
                  {selectedEmpresa?.created_at ? new Date(selectedEmpresa.created_at).toLocaleDateString() : "-"}
                </p>
              </div>
            </div>
            <div className="pt-2">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Módulos activos</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {modulos.map((modulo) => (
                  <div key={modulo.id} className="flex items-center gap-2">
                    {modulo.activo ? (
                      <CheckCircle className="h-4 w-4 text-green-500" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-500" />
                    )}
                    <span className="text-sm">{modulo.nombre}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsViewingEmpresa(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
