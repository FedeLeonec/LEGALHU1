"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"

export function AjustesManager() {
  const [activeTab, setActiveTab] = useState("mi-cuenta")
  const [isTwoFactorEnabled, setIsTwoFactorEnabled] = useState(true)

  const settingsTabs = [
    { id: "mi-cuenta", label: "Mi Cuenta" },
    { id: "apariencia", label: "Apariencia" },
    { id: "seguridad", label: "Seguridad" },
    { id: "notificaciones", label: "Notificaciones" },
    { id: "idioma", label: "Idioma" },
  ]

  return (
    <div className="flex flex-col md:flex-row gap-8">
      <div className="w-full md:w-1/4 lg:w-1/5 flex-shrink-0">
        <Card className="bg-gray-50">
          <CardContent className="p-4">
            <nav className="space-y-1">
              {settingsTabs.map((tab) => (
                <Button
                  key={tab.id}
                  variant="ghost"
                  className={`w-full justify-start px-3 py-2 text-sm font-medium ${
                    activeTab === tab.id
                      ? "bg-gray-200 text-gray-900 font-semibold"
                      : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                  }`}
                  onClick={() => setActiveTab(tab.id)}
                >
                  {tab.label}
                </Button>
              ))}
            </nav>
          </CardContent>
        </Card>
        <div className="mt-6 text-xs text-gray-500">
          <a href="#" className="hover:underline">
            Contáctanos
          </a>
        </div>
      </div>

      <div className="flex-grow">
        {activeTab === "mi-cuenta" && (
          <Card>
            <CardHeader>
              <CardTitle>Mi cuenta</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label
                  htmlFor="username"
                  className="block text-xs font-medium text-gray-500 mb-1 uppercase tracking-wider"
                >
                  Usuario
                </label>
                <div className="flex items-center">
                  <Input
                    type="text"
                    id="username"
                    value="Matthew Parker"
                    readOnly
                    className="flex-grow border border-gray-300 rounded-l-md p-2 bg-gray-50 focus:outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 text-sm text-gray-700"
                  />
                  <Button className="bg-orange-500 text-white px-4 py-2 rounded-r-md hover:bg-orange-600 text-sm font-medium border border-orange-500">
                    Edit
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <label
                  htmlFor="email"
                  className="block text-xs font-medium text-gray-500 mb-1 uppercase tracking-wider"
                >
                  Email
                </label>
                <Input
                  type="email"
                  id="email"
                  value="info@legalhub.com"
                  readOnly
                  className="w-full border border-gray-300 rounded-md p-2 bg-gray-50 focus:outline-none text-sm text-gray-700"
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="role" className="block text-xs font-medium text-gray-500 mb-1 uppercase tracking-wider">
                  Rol
                </label>
                <Input
                  type="text"
                  id="role"
                  value="Administrador"
                  readOnly
                  className="w-full border border-gray-300 rounded-md p-2 bg-gray-50 focus:outline-none text-sm text-gray-700"
                />
              </div>

              <Button className="bg-orange-500 text-white px-4 py-2 rounded-md hover:bg-orange-600 text-sm font-medium mb-8 shadow-sm">
                Change Password
              </Button>

              <hr className="my-8 border-gray-200" />

              <div>
                <h4 className="text-md font-semibold text-gray-700 mb-1">Two-Factor Authentication</h4>
                <p className="text-xs text-gray-500 mb-4">Deseas deshabilitar esta opción</p>
                <div className="flex items-center justify-between">
                  <Switch checked={isTwoFactorEnabled} onCheckedChange={setIsTwoFactorEnabled} />
                  {!isTwoFactorEnabled && (
                    <Button variant="outline" className="bg-gray-100 text-gray-700 hover:bg-gray-200 border-gray-300">
                      Enable 2FA
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === "apariencia" && (
          <Card>
            <CardHeader>
              <CardTitle>Apariencia</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mt-4 text-sm">Ajustes de apariencia aquí...</p>
            </CardContent>
          </Card>
        )}

        {activeTab === "seguridad" && (
          <Card>
            <CardHeader>
              <CardTitle>Seguridad</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mt-4 text-sm">Ajustes de seguridad aquí...</p>
            </CardContent>
          </Card>
        )}

        {activeTab === "notificaciones" && (
          <Card>
            <CardHeader>
              <CardTitle>Notificaciones</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mt-4 text-sm">Ajustes de notificaciones aquí...</p>
            </CardContent>
          </Card>
        )}

        {activeTab === "idioma" && (
          <Card>
            <CardHeader>
              <CardTitle>Idioma</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mt-4 text-sm">Ajustes de idioma aquí...</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
