"use client"

import { useState, useEffect } from "react"
import { Search, Plus, Eye, Pencil, Copy, Share2, Trash2, FileText, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

interface Document {
  id: string
  nombre: string
  caso: string
  fecha: string
  type: string
  contenido?: string
}

export function DocumentosManager() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState("ID")
  const [documents, setDocuments] = useState<Document[]>([])
  const [isViewModalOpen, setIsViewModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [currentDocument, setCurrentDocument] = useState<Document | null>(null)
  const [editedDocument, setEditedDocument] = useState<Document | null>(null)

  const router = useRouter()
  const { toast } = useToast()

  // Cargar documentos al iniciar
  useEffect(() => {
    const storedDocuments = localStorage.getItem("documents")
    if (storedDocuments) {
      try {
        setDocuments(JSON.parse(storedDocuments))
      } catch (error) {
        console.error("Error al cargar documentos:", error)
      }
    } else {
      // Documentos de ejemplo si no hay guardados
      const initialDocuments = [
        {
          id: "001-32873",
          nombre: "Contrato de Arrendamiento Local Comercial",
          caso: "32873",
          fecha: "31-marzo-2025",
          type: "contract",
          contenido: "Este es un contrato de arrendamiento para un local comercial...",
        },
        {
          id: "002-11984",
          nombre: "Demanda Laboral - Despido Injustificado",
          caso: "11984",
          fecha: "28-marzo-2025",
          type: "demand",
          contenido: "DEMANDA LABORAL POR DESPIDO INJUSTIFICADO...",
        },
        {
          id: "003-56002",
          nombre: "Acuerdo de Confidencialidad Cliente Tech",
          caso: "56002",
          fecha: "25-marzo-2025",
          type: "agreement",
          contenido: "ACUERDO DE CONFIDENCIALIDAD...",
        },
        {
          id: "004-88721",
          nombre: "Poder General Amplio y Suficiente",
          caso: "88721",
          fecha: "20-marzo-2025",
          type: "power",
          contenido: "PODER GENERAL AMPLIO Y SUFICIENTE...",
        },
        {
          id: "005-32873",
          nombre: "Anexo I - Modificación Contrato Arrendamiento",
          caso: "32873",
          fecha: "15-marzo-2025",
          type: "annex",
          contenido: "ANEXO I - MODIFICACIÓN DE CONTRATO DE ARRENDAMIENTO...",
        },
      ]
      setDocuments(initialDocuments)
      localStorage.setItem("documents", JSON.stringify(initialDocuments))
    }
  }, [])

  // Guardar documentos cuando cambien
  useEffect(() => {
    if (documents.length > 0) {
      localStorage.setItem("documents", JSON.stringify(documents))
    }
  }, [documents])

  const handleCreateDocument = () => {
    router.push("/documentos/nuevo")
  }

  const handleViewDocument = (doc: Document) => {
    setCurrentDocument(doc)
    setIsViewModalOpen(true)
  }

  const handleEditDocument = (doc: Document) => {
    setCurrentDocument(doc)
    setEditedDocument({ ...doc })
    setIsEditModalOpen(true)
  }

  const handleSaveEdit = () => {
    if (!editedDocument) return

    const updatedDocuments = documents.map((doc) => (doc.id === editedDocument.id ? editedDocument : doc))

    setDocuments(updatedDocuments)
    localStorage.setItem("documents", JSON.stringify(updatedDocuments))

    setIsEditModalOpen(false)
    setCurrentDocument(null)
    setEditedDocument(null)

    toast({
      title: "Documento actualizado",
      description: "El documento ha sido actualizado correctamente",
    })
  }

  const handleDeleteDocument = (doc: Document) => {
    setCurrentDocument(doc)
    setIsDeleteModalOpen(true)
  }

  const confirmDelete = () => {
    if (!currentDocument) return

    const updatedDocuments = documents.filter((doc) => doc.id !== currentDocument.id)
    setDocuments(updatedDocuments)
    localStorage.setItem("documents", JSON.stringify(updatedDocuments))

    setIsDeleteModalOpen(false)
    setCurrentDocument(null)

    toast({
      title: "Documento eliminado",
      description: "El documento ha sido eliminado correctamente",
    })
  }

  const handleCopyDocument = (doc: Document) => {
    const newDoc = {
      ...doc,
      id: `${doc.id}-copy-${Date.now().toString().slice(-4)}`,
      nombre: `${doc.nombre} (Copia)`,
      fecha: new Date().toLocaleDateString("es-ES", {
        day: "2-digit",
        month: "long",
        year: "numeric",
      }),
    }

    setDocuments([...documents, newDoc])

    toast({
      title: "Documento copiado",
      description: "Se ha creado una copia del documento",
    })
  }

  const handleShareDocument = (doc: Document) => {
    // Simulación de compartir
    toast({
      title: "Compartir documento",
      description: `Se ha enviado un enlace para compartir el documento "${doc.nombre}"`,
    })
  }

  const getFileIcon = (docType: string) => {
    const iconColors = {
      contract: "text-blue-500",
      demand: "text-red-500",
      agreement: "text-green-500",
      power: "text-purple-500",
      annex: "text-yellow-500",
      default: "text-gray-500",
    }

    return <FileText size={16} className={iconColors[docType as keyof typeof iconColors] || iconColors.default} />
  }

  // Filtrar documentos según la búsqueda
  const filteredDocuments = documents.filter((doc) => {
    const searchLower = searchQuery.toLowerCase()

    switch (filterType) {
      case "ID":
        return doc.id.toLowerCase().includes(searchLower)
      case "Nombre":
        return doc.nombre.toLowerCase().includes(searchLower)
      case "Caso":
        return doc.caso.toLowerCase().includes(searchLower)
      case "Fecha":
        return doc.fecha.toLowerCase().includes(searchLower)
      default:
        return (
          doc.id.toLowerCase().includes(searchLower) ||
          doc.nombre.toLowerCase().includes(searchLower) ||
          doc.caso.toLowerCase().includes(searchLower) ||
          doc.fecha.toLowerCase().includes(searchLower)
        )
    }
  })

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <Input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Buscar con IA en documentos..."
          className="pl-10"
        />
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex flex-wrap justify-end items-center mb-6 gap-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center text-sm">
                <label htmlFor="filter-id-doc" className="mr-2 text-gray-600">
                  Filtrar:
                </label>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger id="filter-id-doc" className="w-[120px]">
                    <SelectValue placeholder="ID" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ID">ID</SelectItem>
                    <SelectItem value="Nombre">Nombre</SelectItem>
                    <SelectItem value="Caso">Caso</SelectItem>
                    <SelectItem value="Fecha">Fecha</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleCreateDocument}>
                <Plus size={16} className="mr-2" />
                Documento
              </Button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>NOMBRE</TableHead>
                  <TableHead>CASO</TableHead>
                  <TableHead>FECHA</TableHead>
                  <TableHead className="text-right">ACCIONES</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDocuments.length > 0 ? (
                  filteredDocuments.map((doc) => (
                    <TableRow key={doc.id}>
                      <TableCell className="font-medium text-gray-500">{doc.id}</TableCell>
                      <TableCell className="font-medium text-gray-800">
                        <div className="flex items-center gap-2">
                          {getFileIcon(doc.type)}
                          <span>{doc.nombre}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-gray-500">{doc.caso}</TableCell>
                      <TableCell className="text-gray-500 whitespace-nowrap">{doc.fecha}</TableCell>
                      <TableCell className="text-right space-x-2 whitespace-nowrap">
                        <Button variant="ghost" size="icon" title="Ver" onClick={() => handleViewDocument(doc)}>
                          <Eye size={16} className="text-gray-400 hover:text-blue-600" />
                        </Button>
                        <Button variant="ghost" size="icon" title="Editar" onClick={() => handleEditDocument(doc)}>
                          <Pencil size={16} className="text-gray-400 hover:text-green-600" />
                        </Button>
                        <Button variant="ghost" size="icon" title="Copiar" onClick={() => handleCopyDocument(doc)}>
                          <Copy size={16} className="text-gray-400 hover:text-gray-600" />
                        </Button>
                        <Button variant="ghost" size="icon" title="Compartir" onClick={() => handleShareDocument(doc)}>
                          <Share2 size={16} className="text-gray-400 hover:text-purple-600" />
                        </Button>
                        <Button variant="ghost" size="icon" title="Eliminar" onClick={() => handleDeleteDocument(doc)}>
                          <Trash2 size={16} className="text-gray-400 hover:text-red-600" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-gray-500">
                      No se encontraron documentos. Crea un nuevo documento para comenzar.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Modal para ver documento */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{currentDocument?.nombre}</DialogTitle>
            <DialogDescription>
              ID: {currentDocument?.id} | Caso: {currentDocument?.caso}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="bg-gray-50 p-4 rounded-md border border-gray-200 whitespace-pre-wrap">
              {currentDocument?.contenido || "No hay contenido disponible para este documento."}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsViewModalOpen(false)}>
              Cerrar
            </Button>
            <Button
              className="bg-orange-500 hover:bg-orange-600"
              onClick={() => {
                // Simulación de descarga
                toast({
                  title: "Documento descargado",
                  description: `El documento "${currentDocument?.nombre}" ha sido descargado.`,
                })
              }}
            >
              <Download size={16} className="mr-2" />
              Descargar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para editar documento */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Editar Documento</DialogTitle>
            <DialogDescription>Modifica los detalles del documento</DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-nombre">Nombre del documento</Label>
              <Input
                id="edit-nombre"
                value={editedDocument?.nombre || ""}
                onChange={(e) => setEditedDocument((prev) => (prev ? { ...prev, nombre: e.target.value } : null))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-caso">Caso relacionado</Label>
              <Input
                id="edit-caso"
                value={editedDocument?.caso || ""}
                onChange={(e) => setEditedDocument((prev) => (prev ? { ...prev, caso: e.target.value } : null))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-contenido">Contenido</Label>
              <Textarea
                id="edit-contenido"
                rows={10}
                value={editedDocument?.contenido || ""}
                onChange={(e) => setEditedDocument((prev) => (prev ? { ...prev, contenido: e.target.value } : null))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
              Cancelar
            </Button>
            <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleSaveEdit}>
              Guardar Cambios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para confirmar eliminación */}
      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar eliminación</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar el documento "{currentDocument?.nombre}"? Esta acción no se puede
              deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteModalOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmDelete}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
