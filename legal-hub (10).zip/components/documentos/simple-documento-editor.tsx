"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import { jsPDF } from "jspdf"
import FileSaver from "file-saver"

export function SimpleDocumentoEditor({ casoId = null }) {
  const [titulo, setTitulo] = useState("")
  const [contenido, setContenido] = useState("")
  const [tipo, setTipo] = useState("general")
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const handleSave = async () => {
    if (!titulo.trim()) {
      toast({
        title: "Error",
        description: "El título es obligatorio",
        variant: "destructive",
      })
      return
    }

    if (!contenido.trim()) {
      toast({
        title: "Error",
        description: "El contenido es obligatorio",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)

      // Crear nuevo documento
      const nuevoDocumento = {
        id: `DOC-${Date.now().toString().slice(-6)}`,
        nombre: titulo,
        contenido: contenido,
        type: tipo,
        caso: casoId || "General",
        fecha: new Date().toLocaleDateString("es-ES", {
          day: "2-digit",
          month: "long",
          year: "numeric",
        }),
      }

      // Obtener documentos existentes
      const existingDocs = JSON.parse(localStorage.getItem("documents") || "[]")

      // Añadir nuevo documento
      const updatedDocs = [...existingDocs, nuevoDocumento]

      // Guardar en localStorage
      localStorage.setItem("documents", JSON.stringify(updatedDocs))

      toast({
        title: "Documento guardado",
        description: "El documento se ha guardado correctamente",
      })

      // Redirigir a la página de documentos o a la página del caso
      if (casoId) {
        router.push(`/casos/${casoId}`)
      } else {
        router.push("/documentos")
      }
    } catch (error) {
      console.error("Error al guardar documento:", error)
      toast({
        title: "Error",
        description: "No se pudo guardar el documento",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleExportPDF = () => {
    try {
      const doc = new jsPDF()

      // Añadir título
      doc.setFontSize(16)
      doc.text(titulo, 20, 20)

      // Añadir contenido
      doc.setFontSize(12)
      const splitText = doc.splitTextToSize(contenido, 170)
      doc.text(splitText, 20, 30)

      // Guardar el PDF
      doc.save(`${titulo}.pdf`)

      toast({
        title: "PDF exportado",
        description: "El documento se ha exportado como PDF",
      })
    } catch (error) {
      console.error("Error al exportar PDF:", error)
      toast({
        title: "Error",
        description: "No se pudo exportar el documento como PDF",
        variant: "destructive",
      })
    }
  }

  const handleExportWord = () => {
    try {
      // Crear un blob con el contenido HTML
      const blob = new Blob(
        [
          `
        <html>
          <head>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              h1 { color: #333; }
              p { white-space: pre-wrap; }
            </style>
          </head>
          <body>
            <h1>${titulo}</h1>
            <p>${contenido}</p>
          </body>
        </html>
      `,
        ],
        { type: "application/msword" },
      )

      // Descargar como archivo .doc
      FileSaver.saveAs(blob, `${titulo}.doc`)

      toast({
        title: "Word exportado",
        description: "El documento se ha exportado como Word",
      })
    } catch (error) {
      console.error("Error al exportar Word:", error)
      toast({
        title: "Error",
        description: "No se pudo exportar el documento como Word",
        variant: "destructive",
      })
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Editor de Documentos</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="titulo">Título del documento</Label>
          <Input
            id="titulo"
            value={titulo}
            onChange={(e) => setTitulo(e.target.value)}
            placeholder="Ingrese el título del documento"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tipo">Tipo de documento</Label>
          <Select value={tipo} onValueChange={setTipo}>
            <SelectTrigger id="tipo">
              <SelectValue placeholder="Seleccione el tipo de documento" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="contract">Contrato</SelectItem>
              <SelectItem value="demand">Demanda</SelectItem>
              <SelectItem value="agreement">Acuerdo</SelectItem>
              <SelectItem value="power">Poder</SelectItem>
              <SelectItem value="annex">Anexo</SelectItem>
              <SelectItem value="general">General</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="contenido">Contenido</Label>
          <Textarea
            id="contenido"
            value={contenido}
            onChange={(e) => setContenido(e.target.value)}
            placeholder="Escriba el contenido del documento aquí..."
            className="min-h-[300px]"
            rows={12}
          />
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div>
          <Button variant="outline" onClick={() => router.back()} disabled={isLoading}>
            Cancelar
          </Button>
        </div>
        <div className="space-x-2">
          <Button variant="outline" onClick={handleExportPDF} disabled={isLoading}>
            Exportar PDF
          </Button>
          <Button variant="outline" onClick={handleExportWord} disabled={isLoading}>
            Exportar Word
          </Button>
          <Button onClick={handleSave} disabled={isLoading} className="bg-orange-500 hover:bg-orange-600">
            {isLoading ? "Guardando..." : "Guardar"}
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
