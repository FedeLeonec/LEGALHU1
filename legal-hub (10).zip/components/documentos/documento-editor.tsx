"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { createDocumento } from "@/app/actions/documentos"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import dynamic from "next/dynamic"
import { jsPDF } from "jspdf"
import FileSaver from "file-saver"

// Import React Quill dynamically with SSR disabled
const ReactQuill = dynamic(
  async () => {
    const { default: RQ } = await import("react-quill")
    return function comp({ forwardedRef, ...props }) {
      return <RQ ref={forwardedRef} {...props} />
    }
  },
  { ssr: false },
)

export function DocumentoEditor({ casoId = null }) {
  const [titulo, setTitulo] = useState("")
  const [contenido, setContenido] = useState("")
  const [tipo, setTipo] = useState("general")
  const [isLoading, setIsLoading] = useState(false)
  const [mounted, setMounted] = useState(false)
  const { toast } = useToast()
  const router = useRouter()
  const quillRef = useRef(null)

  // Set mounted state after component mounts
  useEffect(() => {
    setMounted(true)
  }, [])

  const handleSave = async () => {
    if (!titulo.trim()) {
      toast({
        title: "Error",
        description: "El título es obligatorio",
        variant: "destructive",
      })
      return
    }

    if (!contenido.trim()) {
      toast({
        title: "Error",
        description: "El contenido es obligatorio",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)

      const nuevoDocumento = {
        nombre: titulo,
        contenido: contenido,
        tipo: tipo,
        caso_id: casoId,
      }

      await createDocumento(nuevoDocumento)

      toast({
        title: "Documento guardado",
        description: "El documento se ha guardado correctamente",
      })

      // Redirigir a la página de documentos o a la página del caso
      if (casoId) {
        router.push(`/casos/${casoId}`)
      } else {
        router.push("/documentos")
      }
    } catch (error) {
      console.error("Error al guardar documento:", error)
      toast({
        title: "Error",
        description: "No se pudo guardar el documento",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleExportPDF = () => {
    try {
      const doc = new jsPDF()

      // Añadir título
      doc.setFontSize(16)
      doc.text(titulo, 20, 20)

      // Añadir contenido (eliminando etiquetas HTML)
      doc.setFontSize(12)
      const textContent = contenido.replace(/<[^>]*>/g, "")

      // Dividir el texto en líneas para que quepa en la página
      const splitText = doc.splitTextToSize(textContent, 170)
      doc.text(splitText, 20, 30)

      // Guardar el PDF
      doc.save(`${titulo}.pdf`)

      toast({
        title: "PDF exportado",
        description: "El documento se ha exportado como PDF",
      })
    } catch (error) {
      console.error("Error al exportar PDF:", error)
      toast({
        title: "Error",
        description: "No se pudo exportar el documento como PDF",
        variant: "destructive",
      })
    }
  }

  const handleExportWord = () => {
    try {
      // Crear un blob con el contenido HTML
      const blob = new Blob(
        [
          `
        <html>
          <head>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              h1 { color: #333; }
            </style>
          </head>
          <body>
            <h1>${titulo}</h1>
            ${contenido}
          </body>
        </html>
      `,
        ],
        { type: "application/msword" },
      )

      // Descargar como archivo .doc
      FileSaver.saveAs(blob, `${titulo}.doc`)

      toast({
        title: "Word exportado",
        description: "El documento se ha exportado como Word",
      })
    } catch (error) {
      console.error("Error al exportar Word:", error)
      toast({
        title: "Error",
        description: "No se pudo exportar el documento como Word",
        variant: "destructive",
      })
    }
  }

  const modules = {
    toolbar: [
      [{ header: [1, 2, 3, 4, 5, 6, false] }],
      ["bold", "italic", "underline", "strike"],
      [{ list: "ordered" }, { list: "bullet" }],
      [{ indent: "-1" }, { indent: "+1" }],
      [{ align: [] }],
      ["link"],
      ["clean"],
    ],
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Editor de Documentos</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="titulo">Título del documento</Label>
          <Input
            id="titulo"
            value={titulo}
            onChange={(e) => setTitulo(e.target.value)}
            placeholder="Ingrese el título del documento"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tipo">Tipo de documento</Label>
          <Select value={tipo} onValueChange={setTipo}>
            <SelectTrigger id="tipo">
              <SelectValue placeholder="Seleccione el tipo de documento" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="general">General</SelectItem>
              <SelectItem value="contrato">Contrato</SelectItem>
              <SelectItem value="demanda">Demanda</SelectItem>
              <SelectItem value="escrito">Escrito</SelectItem>
              <SelectItem value="poder">Poder</SelectItem>
              <SelectItem value="otro">Otro</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="contenido">Contenido</Label>
          <div className="min-h-[300px] border rounded-md">
            {mounted && (
              <div className="h-[250px]">
                <ReactQuill
                  forwardedRef={quillRef}
                  theme="snow"
                  value={contenido}
                  onChange={setContenido}
                  modules={modules}
                  placeholder="Escriba el contenido del documento aquí..."
                />
              </div>
            )}
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div>
          <Button variant="outline" onClick={() => router.back()} disabled={isLoading}>
            Cancelar
          </Button>
        </div>
        <div className="space-x-2">
          <Button variant="outline" onClick={handleExportPDF} disabled={isLoading}>
            Exportar PDF
          </Button>
          <Button variant="outline" onClick={handleExportWord} disabled={isLoading}>
            Exportar Word
          </Button>
          <Button onClick={handleSave} disabled={isLoading} className="bg-orange-500 hover:bg-orange-600">
            {isLoading ? "Guardando..." : "Guardar"}
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
