"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Send, Users, User, Shield } from "lucide-react"

export function NotificacionesManager() {
  const [destinatario, setDestinatario] = useState("todos")
  const [titulo, setTitulo] = useState("")
  const [mensaje, setMensaje] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleSendNotification = async () => {
    if (!titulo.trim()) {
      toast({
        title: "Error",
        description: "El título es obligatorio",
        variant: "destructive",
      })
      return
    }

    if (!mensaje.trim()) {
      toast({
        title: "Error",
        description: "El mensaje es obligatorio",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)
      // Aquí iría la lógica para enviar la notificación

      // Simulamos un retraso
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Notificación enviada",
        description: "La notificación se ha enviado correctamente",
      })

      // Limpiar formulario
      setTitulo("")
      setMensaje("")
    } catch (error) {
      console.error("Error al enviar notificación:", error)
      toast({
        title: "Error",
        description: "No se pudo enviar la notificación",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Gestión de Notificaciones</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="nueva">
            <TabsList className="mb-6">
              <TabsTrigger value="nueva">Nueva Notificación</TabsTrigger>
              <TabsTrigger value="historial">Historial</TabsTrigger>
              <TabsTrigger value="configuracion">Configuración</TabsTrigger>
            </TabsList>

            <TabsContent value="nueva" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="destinatario">Destinatario</Label>
                <Select value={destinatario} onValueChange={setDestinatario}>
                  <SelectTrigger id="destinatario">
                    <SelectValue placeholder="Seleccionar destinatario" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">
                      <div className="flex items-center">
                        <Users className="mr-2 h-4 w-4" />
                        <span>Todos los usuarios</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="clientes">
                      <div className="flex items-center">
                        <User className="mr-2 h-4 w-4" />
                        <span>Solo clientes</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="abogados">
                      <div className="flex items-center">
                        <Shield className="mr-2 h-4 w-4" />
                        <span>Solo abogados</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="administradores">
                      <div className="flex items-center">
                        <Shield className="mr-2 h-4 w-4" />
                        <span>Solo administradores</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="titulo">Título</Label>
                <Input
                  id="titulo"
                  value={titulo}
                  onChange={(e) => setTitulo(e.target.value)}
                  placeholder="Ingrese el título de la notificación"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="mensaje">Mensaje</Label>
                <Textarea
                  id="mensaje"
                  value={mensaje}
                  onChange={(e) => setMensaje(e.target.value)}
                  placeholder="Ingrese el mensaje de la notificación"
                  rows={5}
                />
              </div>

              <div className="flex justify-end">
                <Button
                  onClick={handleSendNotification}
                  disabled={isLoading}
                  className="bg-orange-500 hover:bg-orange-600"
                >
                  <Send className="mr-2 h-4 w-4" />
                  {isLoading ? "Enviando..." : "Enviar Notificación"}
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="historial">
              <div className="space-y-4">
                <div className="rounded-md border p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium">Actualización de sistema</h3>
                      <p className="text-sm text-gray-500">Enviado a: Todos los usuarios</p>
                      <p className="mt-2 text-sm">
                        El sistema estará en mantenimiento el día 15 de abril de 2025 de 2:00 AM a 4:00 AM.
                      </p>
                    </div>
                    <span className="text-xs text-gray-400">Hace 2 días</span>
                  </div>
                </div>

                <div className="rounded-md border p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium">Recordatorio de pago</h3>
                      <p className="text-sm text-gray-500">Enviado a: Solo clientes</p>
                      <p className="mt-2 text-sm">
                        Recordamos a nuestros clientes que el plazo para el pago de la mensualidad vence el 10 de abril.
                      </p>
                    </div>
                    <span className="text-xs text-gray-400">Hace 5 días</span>
                  </div>
                </div>

                <div className="rounded-md border p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium">Nueva funcionalidad</h3>
                      <p className="text-sm text-gray-500">Enviado a: Todos los usuarios</p>
                      <p className="mt-2 text-sm">
                        Hemos añadido nuevas funcionalidades de IA a la plataforma. Explora el asistente legal para
                        descubrirlas.
                      </p>
                    </div>
                    <span className="text-xs text-gray-400">Hace 1 semana</span>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="configuracion">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email-notificaciones">Email para notificaciones</Label>
                  <Input id="email-notificaciones" type="email" placeholder="correo@ejemplo.com" />
                </div>

                <div className="space-y-2">
                  <Label>Tipos de notificaciones</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="notif-sistema" className="rounded border-gray-300" defaultChecked />
                      <Label htmlFor="notif-sistema" className="font-normal">
                        Notificaciones del sistema
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="notif-tareas" className="rounded border-gray-300" defaultChecked />
                      <Label htmlFor="notif-tareas" className="font-normal">
                        Asignación de tareas
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="notif-casos" className="rounded border-gray-300" defaultChecked />
                      <Label htmlFor="notif-casos" className="font-normal">
                        Actualizaciones de casos
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="checkbox" id="notif-documentos" className="rounded border-gray-300" defaultChecked />
                      <Label htmlFor="notif-documentos" className="font-normal">
                        Nuevos documentos
                      </Label>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button className="bg-orange-500 hover:bg-orange-600">Guardar Configuración</Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
