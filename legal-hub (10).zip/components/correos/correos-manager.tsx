"use client"

import { useState, useCallback, useMemo } from "react"
import { Inbox, FileEdit, Wand2, Star, Reply, Archive, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export function CorreosManager() {
  const initialEmails = useMemo(
    () => [
      {
        id: 1,
        sender: "Juan Pérez (Cliente)",
        subject: "Consulta Urgente - Caso 11984",
        snippet: "Estimado/a, necesito aclarar una duda sobre el último escrito...",
        time: "Hoy, 8:15 AM",
        read: false,
        body: "Contenido completo del correo electrónico de Juan Pérez sobre la consulta urgente del caso 11984...\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      },
      {
        id: 2,
        sender: "Notificaciones Judiciales",
        subject: "Notificación Electrónica - Expediente 32873",
        snippet: "Se adjunta cédula de notificación electrónica correspondiente al e...",
        time: "Ayer, 4:30 PM",
        read: false,
        body: "Texto completo de la notificación judicial electrónica para el expediente 32873.\n\nUt enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
      },
      {
        id: 3,
        sender: "Ana López",
        subject: "Documentación Herencia",
        snippet: "Hola, te envío los documentos que me pediste para el caso de la h...",
        time: "Ayer, 10:00 AM",
        read: true,
        body: "Adjunto los documentos solicitados para el caso de la herencia.\n\nSaludos,\nAna.",
      },
      {
        id: 4,
        sender: "Colegio de Abogados",
        subject: "Recordatorio: Cuota Anual",
        snippet: "Le recordamos que el plazo para el pago de la cuota anual finaliza...",
        time: "Hace 3 días",
        read: true,
        body: "Recordatorio importante sobre el pago de la cuota anual del Colegio de Abogados.\n\nDuis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
      },
      {
        id: 5,
        sender: "Marketing Legal Today",
        subject: "Webinar Gratuito: IA para Bufetes",
        snippet: "Descubre cómo la inteligencia artificial puede transformar tu prácti...",
        time: "Hace 5 días",
        read: true,
        body: "Invitación al webinar gratuito sobre la aplicación de la Inteligencia Artificial en bufetes de abogados.\n\nExcepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
      },
    ],
    [],
  )

  const [emails, setEmails] = useState(initialEmails)
  const [selectedEmailId, setSelectedEmailId] = useState(emails[0]?.id || null)

  const selectedEmail = useMemo(() => {
    return emails.find((email) => email.id === selectedEmailId)
  }, [selectedEmailId, emails])

  const handleSelectEmail = useCallback((id) => {
    setSelectedEmailId(id)
    setEmails((currentEmails) => currentEmails.map((email) => (email.id === id ? { ...email, read: true } : email)))
  }, [])

  const handleAiReply = useCallback(() => {
    console.log("AI Reply for:", selectedEmail?.subject)
  }, [selectedEmail])

  const handleAiSummarize = useCallback(() => {
    console.log("AI Summarize for:", selectedEmail?.subject)
  }, [selectedEmail])

  const handleAiMarkImportant = useCallback(() => {
    console.log("AI Mark Important:", selectedEmail?.subject)
  }, [selectedEmail])

  return (
    <Card className="border-gray-200 overflow-hidden h-[calc(100vh-10rem)]">
      <div className="flex h-full">
        <div className="w-full md:w-1/3 lg:w-1/4 border-r border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200 flex justify-between items-center sticky top-0 bg-white z-10 flex-shrink-0">
            <h3 className="font-semibold text-gray-800 flex items-center gap-2">
              <Inbox size={18} /> Bandeja
            </h3>
            <Button variant="ghost" size="icon" className="text-gray-500 hover:text-orange-600">
              <FileEdit size={18} />
            </Button>
          </div>

          <div className="overflow-y-auto flex-grow">
            {emails.map((email) => (
              <div
                key={email.id}
                onClick={() => handleSelectEmail(email.id)}
                className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${
                  selectedEmailId === email.id ? "bg-blue-50" : ""
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className={`font-medium truncate pr-2 ${!email.read ? "text-gray-900" : "text-gray-600"}`}>
                    {email.sender}
                  </span>
                  <span className="text-xs text-gray-400 flex-shrink-0 ml-2 whitespace-nowrap">{email.time}</span>
                </div>
                <p className={`text-sm mb-1 truncate ${!email.read ? "text-gray-800 font-semibold" : "text-gray-600"}`}>
                  {email.subject}
                </p>
                <p className="text-xs text-gray-500 truncate">{email.snippet}</p>
              </div>
            ))}
            {emails.length === 0 && (
              <p className="p-4 text-center text-gray-500 italic">No hay correos en la bandeja.</p>
            )}
          </div>
        </div>

        <div className="w-full md:w-2/3 lg:w-3/4 flex flex-col overflow-hidden">
          {selectedEmail ? (
            <>
              <div className="p-3 border-b border-gray-200 bg-gray-50 sticky top-0 z-10 flex-shrink-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-semibold text-gray-600 mr-2 flex items-center gap-1">
                    <Wand2 size={14} /> Asistente IA:
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleAiReply}
                    className="bg-blue-100 text-blue-700 border-blue-200 hover:bg-blue-200 hover:text-blue-800"
                  >
                    Responder
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleAiSummarize}
                    className="bg-purple-100 text-purple-700 border-purple-200 hover:bg-purple-200 hover:text-purple-800"
                  >
                    Resumir
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleAiMarkImportant}
                    className="bg-yellow-100 text-yellow-700 border-yellow-200 hover:bg-yellow-200 hover:text-yellow-800 flex items-center gap-1"
                  >
                    <Star size={12} /> Marcar Importante
                  </Button>
                </div>
              </div>

              <div className="p-6 border-b border-gray-200 flex-shrink-0">
                <h2 className="text-lg font-semibold text-gray-800 mb-2">{selectedEmail.subject}</h2>
                <p className="text-xs text-gray-500">
                  De: <span className="text-gray-700">{selectedEmail.sender}</span>
                </p>
                <p className="text-xs text-gray-500">
                  Fecha: <span className="text-gray-700">{selectedEmail.time}</span>
                </p>
              </div>

              <div className="p-6 flex-grow overflow-y-auto">
                <p className="text-sm leading-relaxed text-gray-700 whitespace-pre-wrap">{selectedEmail.body}</p>
              </div>

              <div className="p-4 border-t border-gray-200 bg-white flex items-center space-x-3 justify-end sticky bottom-0 flex-shrink-0">
                <Button variant="outline" className="bg-blue-50 text-blue-600 border-blue-200 hover:bg-blue-100">
                  <Reply size={16} className="mr-2" /> Responder
                </Button>
                <Button variant="outline" className="bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200">
                  <Archive size={16} className="mr-2" /> Archivar
                </Button>
                <Button variant="outline" className="bg-red-100 text-red-600 border-red-200 hover:bg-red-200">
                  <Trash2 size={16} className="mr-2" /> Eliminar
                </Button>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500 italic p-8">
              Selecciona un correo para verlo.
            </div>
          )}
        </div>
      </div>
    </Card>
  )
}
