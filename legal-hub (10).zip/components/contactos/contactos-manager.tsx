"use client"

import { useState } from "react"
import {
  Search,
  Plus,
  Users,
  Landmark,
  Building2,
  Scale,
  Briefcase,
  Gavel,
  UsersRound,
  ArrowLeft,
  Eye,
  Pencil,
  Trash2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function ContactosManager() {
  const [view, setView] = useState("category")
  const [selectedCategory, setSelectedCategory] = useState(null)
  const [filterType, setFilterType] = useState("Nombre")
  const [searchQuery, setSearchQuery] = useState("")

  const categories = [
    { name: "Clientes", count: 3, icon: Users, color: "blue" },
    { name: "Ministerios", count: 2, icon: Landmark, color: "purple" },
    { name: "Superintendencias", count: 1, icon: Building2, color: "green" },
    { name: "Consejo de la Judicatura", count: 1, icon: Scale, color: "yellow" },
    { name: "Abogados", count: 2, icon: Briefcase, color: "indigo" },
    { name: "Corte de Justicia", count: 1, icon: Gavel, color: "red" },
    { name: "Otros", count: 0, icon: UsersRound, color: "gray" },
  ]

  const contactsData = {
    Clientes: [
      {
        nombre: "Maria González",
        telefono: "0981234567",
        email: "info1@cliente.com",
        detalles: "Cliente caso Divorcio",
      },
      {
        nombre: "Juan Rodriguez",
        telefono: "0991234568",
        email: "info2@cliente.com",
        detalles: "Cliente caso Reclamación",
      },
      { nombre: "Ana López", telefono: "0987654321", email: "ana.lopez@email.com", detalles: "Cliente caso Herencia" },
    ],
    Ministerios: [
      {
        nombre: "Ministerio de Justicia",
        telefono: "0223456789",
        email: "contacto@minjusticia.gob",
        detalles: "Contacto principal",
      },
      {
        nombre: "Ministerio de Trabajo",
        telefono: "0223456790",
        email: "contacto@mintrabajo.gob",
        detalles: "Departamento legal",
      },
    ],
    Superintendencias: [
      {
        nombre: "Superintendencia de Compañías",
        telefono: "0223456791",
        email: "info@supercias.gob",
        detalles: "Registro mercantil",
      },
    ],
    "Consejo de la Judicatura": [
      {
        nombre: "Secretaría General",
        telefono: "0223456792",
        email: "secretaria@cj.gob",
        detalles: "Trámites judiciales",
      },
    ],
    Abogados: [
      {
        nombre: "Dr. Carlos Mendoza",
        telefono: "0991234570",
        email: "cmendoza@abogados.com",
        detalles: "Especialista derecho laboral",
      },
      {
        nombre: "Dra. Patricia Vega",
        telefono: "0991234571",
        email: "pvega@abogados.com",
        detalles: "Especialista derecho civil",
      },
    ],
    "Corte de Justicia": [
      {
        nombre: "Secretaría Sala Civil",
        telefono: "0223456793",
        email: "salacivil@corte.gob",
        detalles: "Consulta de causas",
      },
    ],
    Otros: [],
  }

  const handleCategoryClick = (categoryName) => {
    setSelectedCategory(categoryName)
    setView("list")
  }

  const currentContacts = selectedCategory ? contactsData[selectedCategory] || [] : []

  return (
    <div className="space-y-6">
      {view === "category" && (
        <div id="contactos-category-view">
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <div className="flex items-center border border-gray-300 rounded-md overflow-hidden focus-within:ring-1 focus-within:ring-orange-500 focus-within:border-orange-500 w-full sm:w-1/3">
                  <span className="pl-3 pr-1 text-gray-400">
                    <Search size={18} />
                  </span>
                  <Input
                    type="text"
                    placeholder="Buscar categoría..."
                    className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Button className="bg-orange-500 hover:bg-orange-600">
                  <Plus size={16} className="mr-2" />
                  Categoría
                </Button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
                {categories.map((cat) => {
                  const Icon = cat.icon
                  return (
                    <div
                      key={cat.name}
                      onClick={() => handleCategoryClick(cat.name)}
                      className="bg-gray-50 border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer hover:border-orange-300"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Icon size={18} className={`text-${cat.color}-500`} />
                        <h4 className="font-semibold text-gray-800">{cat.name}</h4>
                      </div>
                      <p className="text-xs text-gray-500">{cat.count} Contactos</p>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {view === "list" && selectedCategory && (
        <div id="contactos-list-view">
          <Card>
            <CardContent className="p-6">
              <Button
                variant="link"
                onClick={() => setView("category")}
                className="text-orange-600 hover:text-orange-700 p-0 mb-4 flex items-center gap-1"
              >
                <ArrowLeft size={16} />
                Volver a Categorías
              </Button>

              <h3 className="text-lg font-semibold text-gray-800 mb-6">{selectedCategory}</h3>

              <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <div className="flex items-center border border-gray-300 rounded-md overflow-hidden focus-within:ring-1 focus-within:ring-orange-500 focus-within:border-orange-500 w-full sm:w-1/3">
                  <span className="pl-3 pr-1 text-gray-400">
                    <Search size={18} />
                  </span>
                  <Input
                    type="text"
                    placeholder={`Buscar en ${selectedCategory}...`}
                    className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center text-sm">
                    <label htmlFor="filter-contact-nombre" className="mr-2 text-gray-600">
                      Filtrar:
                    </label>
                    <Select value={filterType} onValueChange={setFilterType}>
                      <SelectTrigger id="filter-contact-nombre" className="w-[120px]">
                        <SelectValue placeholder="Nombre" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Nombre">Nombre</SelectItem>
                        <SelectItem value="Email">Email</SelectItem>
                        <SelectItem value="Teléfono">Teléfono</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button className="bg-orange-500 hover:bg-orange-600">
                    <Plus size={16} className="mr-2" />
                    Contacto
                  </Button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Teléfono</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Detalles</TableHead>
                      <TableHead className="text-center">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {currentContacts.length > 0 ? (
                      currentContacts.map((contact, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium text-gray-900 whitespace-nowrap">
                            {contact.nombre}
                          </TableCell>
                          <TableCell>{contact.telefono}</TableCell>
                          <TableCell>{contact.email}</TableCell>
                          <TableCell>{contact.detalles}</TableCell>
                          <TableCell className="text-center space-x-2">
                            <Button variant="ghost" size="icon" title="Ver">
                              <Eye size={16} className="text-gray-400 hover:text-blue-600" />
                            </Button>
                            <Button variant="ghost" size="icon" title="Editar">
                              <Pencil size={16} className="text-gray-400 hover:text-green-600" />
                            </Button>
                            <Button variant="ghost" size="icon" title="Eliminar">
                              <Trash2 size={16} className="text-gray-400 hover:text-red-600" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-4 text-gray-500 italic">
                          No hay contactos en esta categoría.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
