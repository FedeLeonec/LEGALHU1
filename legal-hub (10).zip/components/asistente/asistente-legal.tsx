"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { ChatAsistente } from "@/components/asistente/chat-asistente"
import { GeneradorDocumentos } from "@/components/asistente/generador-documentos"
import { ConsultasJuridicas } from "@/components/asistente/consultas-juridicas"

export function AsistenteLegal() {
  const [activeTab, setActiveTab] = useState("chat-asistente")

  return (
    <Card className="border-gray-200">
      <CardContent className="p-6 sm:p-8">
        <div className="bg-orange-500 text-white p-4 rounded-md mb-6">
          <p className="font-medium">¿En qué te puedo ayudar el día de hoy?</p>
        </div>

        <Tabs defaultValue="chat-asistente" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="chat-asistente">Chat Asistente</TabsTrigger>
            <TabsTrigger value="generador-documentos">Generador de Documentos</TabsTrigger>
            <TabsTrigger value="consultas-juridicas">Consultas Jurídicas</TabsTrigger>
          </TabsList>

          <TabsContent value="chat-asistente">
            <ChatAsistente />
          </TabsContent>

          <TabsContent value="generador-documentos">
            <GeneradorDocumentos />
          </TabsContent>

          <TabsContent value="consultas-juridicas">
            <ConsultasJuridicas />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
