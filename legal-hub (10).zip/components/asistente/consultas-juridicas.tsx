"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { UploadCloud, FileText, Trash2, FileQuestion } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { Textarea } from "@/components/ui/textarea"
import {
  analyzeLegalDocument,
  summarizeLegalDocument,
  reviewLegalDocument,
  answerQuestionsAboutDocument,
} from "@/lib/groq"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function ConsultasJuridicas() {
  const [file, setFile] = useState<File | null>(null)
  const [fileContent, setFileContent] = useState<string>("")
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<string>("")
  const [question, setQuestion] = useState<string>("")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0]

      // Verificar tamaño del archivo (máximo 10MB)
      if (selectedFile.size > 10 * 1024 * 1024) {
        toast({
          title: "Error",
          description: "El archivo es demasiado grande. El tamaño máximo permitido es 10MB.",
          variant: "destructive",
        })
        return
      }

      // Verificar tipo de archivo
      const validTypes = [
        "text/plain",
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      ]
      if (!validTypes.includes(selectedFile.type)) {
        toast({
          title: "Error",
          description: "Tipo de archivo no soportado. Por favor, sube un archivo PDF, DOC, DOCX o TXT.",
          variant: "destructive",
        })
        return
      }

      setFile(selectedFile)

      // Leer contenido del archivo
      const reader = new FileReader()
      reader.onload = async (event) => {
        if (event.target?.result) {
          let content = event.target.result.toString()

          // Si es un PDF, intentar extraer texto (simplificado)
          if (selectedFile.type === "application/pdf") {
            // En un entorno real, usaríamos una biblioteca como pdf.js
            // Aquí simplemente mostramos un mensaje
            content = "Contenido extraído del PDF: " + selectedFile.name
          }

          setFileContent(content)
          toast({
            title: "Archivo cargado",
            description: `El archivo ${selectedFile.name} ha sido cargado correctamente.`,
          })
        }
      }

      reader.onerror = () => {
        toast({
          title: "Error",
          description: "No se pudo leer el archivo. Inténtalo de nuevo.",
          variant: "destructive",
        })
      }

      if (selectedFile.type === "text/plain") {
        reader.readAsText(selectedFile)
      } else {
        // Para otros tipos, simulamos la lectura
        setTimeout(() => {
          reader.onload?.({ target: { result: `Contenido simulado del archivo ${selectedFile.name}` } } as any)
        }, 500)
      }
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0]

      // Simular el cambio de archivo
      const dataTransfer = new DataTransfer()
      dataTransfer.items.add(droppedFile)

      if (fileInputRef.current) {
        fileInputRef.current.files = dataTransfer.files
        const event = new Event("change", { bubbles: true })
        fileInputRef.current.dispatchEvent(event)
      }
    }
  }

  const handleRemoveFile = () => {
    setFile(null)
    setFileContent("")
    setResult("")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleAnalyze = async () => {
    if (!fileContent) {
      toast({
        title: "Error",
        description: "Primero debes cargar un documento para analizarlo.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    setResult("")

    try {
      const analysis = await analyzeLegalDocument(fileContent)
      setResult(analysis)
    } catch (error) {
      console.error("Error al analizar documento:", error)
      toast({
        title: "Error",
        description: "No se pudo analizar el documento. Inténtalo de nuevo más tarde.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSummarize = async () => {
    if (!fileContent) {
      toast({
        title: "Error",
        description: "Primero debes cargar un documento para resumirlo.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    setResult("")

    try {
      const summary = await summarizeLegalDocument(fileContent)
      setResult(summary)
    } catch (error) {
      console.error("Error al resumir documento:", error)
      toast({
        title: "Error",
        description: "No se pudo resumir el documento. Inténtalo de nuevo más tarde.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleReview = async () => {
    if (!fileContent) {
      toast({
        title: "Error",
        description: "Primero debes cargar un documento para revisarlo.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    setResult("")

    try {
      const review = await reviewLegalDocument(fileContent)
      setResult(review)
    } catch (error) {
      console.error("Error al revisar documento:", error)
      toast({
        title: "Error",
        description: "No se pudo revisar el documento. Inténtalo de nuevo más tarde.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAsk = async () => {
    if (!fileContent) {
      toast({
        title: "Error",
        description: "Primero debes cargar un documento para hacer preguntas sobre él.",
        variant: "destructive",
      })
      return
    }

    if (!question.trim()) {
      toast({
        title: "Error",
        description: "Por favor, escribe una pregunta sobre el documento.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    setResult("")

    try {
      const answer = await answerQuestionsAboutDocument(fileContent, question)
      setResult(answer)
    } catch (error) {
      console.error("Error al responder pregunta:", error)
      toast({
        title: "Error",
        description: "No se pudo responder a tu pregunta. Inténtalo de nuevo más tarde.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Consultas sobre Documentos</h3>

      <p className="text-sm text-gray-600 mb-6">
        Sube un documento para que la IA lo analice, resuma, revise y corrija, o responda tus preguntas.
      </p>

      {!file ? (
        <div
          className="flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-12 text-center mb-6 hover:border-orange-400 transition-colors"
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <UploadCloud size={56} className="text-gray-400 mb-4" />
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept=".pdf,.doc,.docx,.txt"
          />
          <Button className="bg-orange-500 hover:bg-orange-600 mb-2" onClick={() => fileInputRef.current?.click()}>
            Seleccionar Archivo
          </Button>
          <p className="text-xs text-gray-500">PDF, DOC, DOCX, TXT (Max 10MB)</p>
          <p className="text-xs text-gray-500 mt-2">O arrastra y suelta un archivo aquí</p>
        </div>
      ) : (
        <div className="mb-6">
          <div className="flex items-center justify-between bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="flex items-center">
              <FileText size={24} className="text-orange-500 mr-3" />
              <div>
                <p className="font-medium">{file.name}</p>
                <p className="text-xs text-gray-500">{(file.size / 1024).toFixed(2)} KB</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={handleRemoveFile}>
              <Trash2 size={16} className="text-gray-400 hover:text-red-600" />
            </Button>
          </div>

          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2">
            <Button
              variant="outline"
              className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 hover:text-orange-800"
              size="sm"
              onClick={handleAnalyze}
              disabled={isLoading}
            >
              Analizar
            </Button>
            <Button
              variant="outline"
              className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 hover:text-orange-800"
              size="sm"
              onClick={handleSummarize}
              disabled={isLoading}
            >
              Resumir
            </Button>
            <Button
              variant="outline"
              className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 hover:text-orange-800"
              size="sm"
              onClick={handleReview}
              disabled={isLoading}
            >
              Revisar
            </Button>
            <Button
              variant="outline"
              className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 hover:text-orange-800"
              size="sm"
              onClick={() => {
                document.getElementById("question-section")?.scrollIntoView({ behavior: "smooth" })
              }}
              disabled={isLoading}
            >
              Preguntar
            </Button>
          </div>

          <div id="question-section" className="mt-4">
            <div className="flex gap-2 mb-4">
              <Textarea
                placeholder="Escribe una pregunta sobre el documento..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                className="flex-grow"
                disabled={isLoading}
              />
              <Button className="bg-orange-500 hover:bg-orange-600 self-end" onClick={handleAsk} disabled={isLoading}>
                <FileQuestion size={20} />
              </Button>
            </div>
          </div>

          {isLoading && (
            <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200 text-center">
              <div className="animate-pulse flex flex-col items-center">
                <div className="h-12 w-12 rounded-full bg-orange-200 mb-4"></div>
                <div className="h-4 w-3/4 bg-orange-200 rounded mb-2"></div>
                <div className="h-4 w-1/2 bg-orange-200 rounded"></div>
                <p className="mt-4 text-gray-500">Procesando documento...</p>
              </div>
            </div>
          )}

          {result && (
            <Card className="mt-4">
              <CardHeader>
                <CardTitle className="text-lg">Resultado</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="whitespace-pre-wrap text-sm">{result}</div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      <p className="text-xs text-gray-400 mt-4 text-right">¿No encuentras lo que buscas? Contáctanos</p>
    </div>
  )
}
