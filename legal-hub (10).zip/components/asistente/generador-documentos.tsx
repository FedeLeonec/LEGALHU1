"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { ChevronDown, Download, Save, Edit } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { generateLegalDocument } from "@/lib/groq"
import { useToast } from "@/components/ui/use-toast"
import { jsPDF } from "jspdf"
import FileSaver from "file-saver"
import { useRouter } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

// Plantillas predefinidas
const documentTemplates = {
  Contrato: `CONTRATO DE [TIPO DE CONTRATO]

ENTRE:
[NOMBRE DE LA PARTE 1], con domicilio en [DIRECCIÓN], representado por [REPRESENTANTE], en adelante "LA PARTE 1"

Y

[NOMBRE DE LA PARTE 2], con domicilio en [DIRECCIÓN], representado por [REPRESENTANTE], en adelante "LA PARTE 2"

CLÁUSULAS:

PRIMERA - OBJETO DEL CONTRATO
[Descripción detallada del objeto del contrato]

SEGUNDA - PLAZO
El presente contrato tendrá una duración de [DURACIÓN], comenzando el [FECHA INICIO] y finalizando el [FECHA FIN].

TERCERA - PRECIO Y FORMA DE PAGO
[Detalles sobre el precio y la forma de pago]

CUARTA - OBLIGACIONES DE LAS PARTES
LA PARTE 1 se obliga a:
- [Obligación 1]
- [Obligación 2]

LA PARTE 2 se obliga a:
- [Obligación 1]
- [Obligación 2]

QUINTA - RESOLUCIÓN DE CONFLICTOS
[Cláusula de resolución de conflictos]

SEXTA - LEY APLICABLE
El presente contrato se regirá por las leyes de [JURISDICCIÓN].

En prueba de conformidad, se firman dos ejemplares de un mismo tenor y a un solo efecto, en [LUGAR], a los [DÍA] días del mes de [MES] de [AÑO].

_______________________
[NOMBRE DE LA PARTE 1]

_______________________
[NOMBRE DE LA PARTE 2]`,

  Poder: `PODER GENERAL AMPLIO Y SUFICIENTE

En [CIUDAD], a los [DÍA] días del mes de [MES] de [AÑO], yo, [NOMBRE DEL PODERDANTE], [ESTADO CIVIL], [PROFESIÓN], con domicilio en [DIRECCIÓN], titular del documento de identidad número [NÚMERO DE DOCUMENTO], por medio del presente instrumento otorgo PODER GENERAL AMPLIO Y SUFICIENTE a favor de [NOMBRE DEL APODERADO], [ESTADO CIVIL], [PROFESIÓN], con domicilio en [DIRECCIÓN], titular del documento de identidad número [NÚMERO DE DOCUMENTO], para que en mi nombre y representación realice los siguientes actos:

1. [FACULTAD 1]
2. [FACULTAD 2]
3. [FACULTAD 3]
4. [FACULTAD 4]
5. [FACULTAD 5]

El apoderado queda facultado para realizar todos los actos necesarios para el cumplimiento de este mandato, pudiendo firmar documentos públicos y privados, presentar y retirar documentación, percibir sumas de dinero, y en general, realizar cualquier acto jurídico que fuere necesario para el mejor desempeño de este poder.

El presente poder tendrá vigencia hasta [FECHA DE VENCIMIENTO] o hasta que sea expresamente revocado por el poderdante.

_______________________
[NOMBRE DEL PODERDANTE]
[NÚMERO DE DOCUMENTO]`,

  Demanda: `AL JUZGADO [NÚMERO] DE [JURISDICCIÓN]

[NOMBRE DEL DEMANDANTE], mayor de edad, [ESTADO CIVIL], [PROFESIÓN], con domicilio en [DIRECCIÓN], y con documento de identidad número [NÚMERO DE DOCUMENTO], representado por el abogado [NOMBRE DEL ABOGADO], colegiado número [NÚMERO DE COLEGIADO], ante el Juzgado comparezco y como mejor proceda en Derecho, DIGO:

Que por medio del presente escrito interpongo DEMANDA DE [TIPO DE DEMANDA] contra [NOMBRE DEL DEMANDADO], con domicilio en [DIRECCIÓN DEL DEMANDADO], en base a los siguientes:

HECHOS

PRIMERO.- [Descripción del primer hecho]

SEGUNDO.- [Descripción del segundo hecho]

TERCERO.- [Descripción del tercer hecho]

A estos hechos son de aplicación los siguientes:

FUNDAMENTOS DE DERECHO

I. COMPETENCIA: [Fundamento de la competencia]

II. LEGITIMACIÓN: [Fundamento de la legitimación]

III. FONDO: [Fundamentos jurídicos de fondo]

Por lo expuesto,

SOLICITO AL JUZGADO: Que tenga por presentado este escrito con sus copias y documentos acompañados, se sirva admitirlo, me tenga por comparecido y parte en la representación que ostento, y previos los trámites legales oportunos, dicte Sentencia por la que:

1. [Petición 1]
2. [Petición 2]
3. [Petición 3]

Es justicia que pido en [LUGAR], a [DÍA] de [MES] de [AÑO].

_______________________
[NOMBRE DEL ABOGADO]
Colegiado Nº [NÚMERO]`,

  Escrito: `AL JUZGADO [NÚMERO] DE [JURISDICCIÓN]

[NOMBRE], Procurador de los Tribunales, en nombre y representación de [NOMBRE DEL REPRESENTADO], según tengo acreditado en los autos de [TIPO DE PROCEDIMIENTO] nº [NÚMERO DE PROCEDIMIENTO], ante el Juzgado comparezco y como mejor proceda en Derecho, DIGO:

[CUERPO DEL ESCRITO]

Por lo expuesto,

SOLICITO AL JUZGADO: [PETICIÓN]

Es justicia que pido en [LUGAR], a [DÍA] de [MES] de [AÑO].

_______________________
[NOMBRE]
Procurador`,

  Acuerdo: `ACUERDO DE [TIPO DE ACUERDO]

En [CIUDAD], a [DÍA] de [MES] de [AÑO]

REUNIDOS

De una parte, [NOMBRE DE LA PARTE 1], [DATOS DE IDENTIFICACIÓN], en adelante "PARTE 1".

Y de otra parte, [NOMBRE DE LA PARTE 2], [DATOS DE IDENTIFICACIÓN], en adelante "PARTE 2".

Ambas partes se reconocen mutuamente la capacidad legal necesaria para la firma del presente Acuerdo y a tal efecto,

EXPONEN

I. Que [ANTECEDENTES]

II. Que [MOTIVOS DEL ACUERDO]

Y por lo expuesto, las partes han convenido celebrar el presente Acuerdo que se regirá por las siguientes:

CLÁUSULAS

PRIMERA.- [CONTENIDO DE LA CLÁUSULA]

SEGUNDA.- [CONTENIDO DE LA CLÁUSULA]

TERCERA.- [CONTENIDO DE LA CLÁUSULA]

Y en prueba de conformidad, firman el presente documento por duplicado y a un solo efecto en el lugar y fecha indicados en el encabezamiento.

_______________________
[NOMBRE DE LA PARTE 1]

_______________________
[NOMBRE DE LA PARTE 2]`,

  Otro: `[TÍTULO DEL DOCUMENTO]

[CONTENIDO DEL DOCUMENTO]

[LUGAR], [FECHA]

_______________________
[FIRMA]
[NOMBRE]
[CARGO/POSICIÓN]`,
}

export function GeneradorDocumentos() {
  const [selectedDocType, setSelectedDocType] = useState("Contrato")
  const [documentDetails, setDocumentDetails] = useState("")
  const [generatedDocument, setGeneratedDocument] = useState("")
  const [documentTitle, setDocumentTitle] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const docTypes = ["Contrato", "Poder", "Demanda", "Escrito", "Acuerdo", "Otro"]

  // Cargar la plantilla cuando cambie el tipo de documento
  useEffect(() => {
    setGeneratedDocument("")
    setDocumentTitle("")
  }, [selectedDocType])

  const handleGenerate = async () => {
    if (!documentDetails.trim()) {
      toast({
        title: "Error",
        description: "Por favor, proporciona los detalles necesarios para generar el documento",
        variant: "destructive",
      })
      return
    }

    try {
      setIsGenerating(true)

      // Generar título basado en el tipo de documento
      const defaultTitle = `${selectedDocType} - ${new Date().toLocaleDateString()}`
      setDocumentTitle(defaultTitle)

      // Usar la plantilla correspondiente
      const template = documentTemplates[selectedDocType] || ""

      // Intentar personalizar la plantilla con IA
      try {
        const generatedText = await generateLegalDocument(selectedDocType, documentDetails)
        if (generatedText && generatedText.length > 100) {
          // Si la IA generó un texto suficientemente largo, usarlo
          setGeneratedDocument(generatedText)
        } else {
          // Si no, usar la plantilla con algunos reemplazos básicos
          setGeneratedDocument(template)
        }
      } catch (error) {
        console.error("Error al generar con IA, usando plantilla:", error)
        setGeneratedDocument(template)
      }

      toast({
        title: "Documento generado",
        description: `Se ha generado un ${selectedDocType.toLowerCase()} con éxito`,
      })
    } catch (error) {
      console.error("Error al generar documento:", error)
      toast({
        title: "Error",
        description: "No se pudo generar el documento. Inténtalo de nuevo más tarde.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleEditDocument = () => {
    setIsEditModalOpen(true)
  }

  const handleSaveEdit = () => {
    setIsEditModalOpen(false)
    toast({
      title: "Documento actualizado",
      description: "Los cambios han sido guardados",
    })
  }

  const handleExportPDF = () => {
    if (!generatedDocument) {
      toast({
        title: "Error",
        description: "Primero debes generar un documento",
        variant: "destructive",
      })
      return
    }

    try {
      const doc = new jsPDF()

      // Título
      doc.setFontSize(16)
      doc.text(documentTitle || selectedDocType, 20, 20)

      // Contenido
      doc.setFontSize(12)
      const splitText = doc.splitTextToSize(generatedDocument, 170)
      doc.text(splitText, 20, 30)

      // Guardar el PDF
      doc.save(`${documentTitle || selectedDocType}.pdf`)

      toast({
        title: "PDF exportado",
        description: "El documento se ha exportado como PDF",
      })
    } catch (error) {
      console.error("Error al exportar PDF:", error)
      toast({
        title: "Error",
        description: "No se pudo exportar el documento como PDF",
        variant: "destructive",
      })
    }
  }

  const handleExportWord = () => {
    if (!generatedDocument) {
      toast({
        title: "Error",
        description: "Primero debes generar un documento",
        variant: "destructive",
      })
      return
    }

    try {
      // Crear contenido HTML
      const htmlContent = `
        <html>
          <head>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              h1 { color: #333; }
            </style>
          </head>
          <body>
            <h1>${documentTitle || selectedDocType}</h1>
            <div>${generatedDocument.replace(/\n/g, "<br>")}</div>
          </body>
        </html>
      `

      // Crear blob y descargar
      const blob = new Blob([htmlContent], { type: "application/msword" })
      FileSaver.saveAs(blob, `${documentTitle || selectedDocType}.doc`)

      toast({
        title: "Word exportado",
        description: "El documento se ha exportado como Word",
      })
    } catch (error) {
      console.error("Error al exportar Word:", error)
      toast({
        title: "Error",
        description: "No se pudo exportar el documento como Word",
        variant: "destructive",
      })
    }
  }

  const handleSave = async () => {
    if (!generatedDocument) {
      toast({
        title: "Error",
        description: "Primero debes generar un documento",
        variant: "destructive",
      })
      return
    }

    try {
      // Crear nuevo documento
      const nuevoDocumento = {
        id: `DOC-${Date.now().toString().slice(-6)}`,
        nombre: documentTitle || `${selectedDocType} - ${new Date().toLocaleDateString()}`,
        contenido: generatedDocument,
        type: selectedDocType.toLowerCase(),
        caso: "General",
        fecha: new Date().toLocaleDateString("es-ES", {
          day: "2-digit",
          month: "long",
          year: "numeric",
        }),
      }

      // Obtener documentos existentes
      const existingDocs = JSON.parse(localStorage.getItem("documents") || "[]")

      // Añadir nuevo documento
      const updatedDocs = [...existingDocs, nuevoDocumento]

      // Guardar en localStorage
      localStorage.setItem("documents", JSON.stringify(updatedDocs))

      toast({
        title: "Documento guardado",
        description: "El documento se ha guardado correctamente",
      })

      // Redirigir a la página de documentos
      router.push("/documentos")
    } catch (error) {
      console.error("Error al guardar documento:", error)
      toast({
        title: "Error",
        description: "No se pudo guardar el documento",
        variant: "destructive",
      })
    }
  }

  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Asistente Jurídico IA</h3>

      <div className="flex justify-between items-center mb-4">
        <p className="text-sm text-gray-600">Selecciona el tipo y proporciona detalles para generar documentos.</p>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="flex items-center gap-2">
              {selectedDocType}
              <ChevronDown size={16} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent>
            {docTypes.map((type) => (
              <DropdownMenuItem key={type} onClick={() => setSelectedDocType(type)}>
                {type}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {!generatedDocument ? (
        <>
          <Textarea
            value={documentDetails}
            onChange={(e) => setDocumentDetails(e.target.value)}
            placeholder={`Has seleccionado ${selectedDocType}. Por favor, proporciona los detalles necesarios...`}
            rows={10}
            className="mb-4"
          />

          <div className="flex justify-end mb-4">
            <Button className="bg-orange-500 hover:bg-orange-600" onClick={handleGenerate} disabled={isGenerating}>
              {isGenerating ? "Generando..." : "Generar"}
            </Button>
          </div>
        </>
      ) : (
        <>
          <div className="mb-4">
            <Label htmlFor="document-title">Título del documento</Label>
            <Input
              id="document-title"
              value={documentTitle}
              onChange={(e) => setDocumentTitle(e.target.value)}
              className="mb-2"
            />
          </div>

          <div className="border border-gray-200 rounded-md p-4 mb-4 bg-gray-50 max-h-60 overflow-y-auto">
            <pre className="whitespace-pre-wrap text-sm">{generatedDocument}</pre>
          </div>

          <div className="flex justify-end space-x-2 mb-4">
            <Button
              variant="outline"
              className="bg-blue-100 text-blue-700 border-blue-200 hover:bg-blue-200 hover:text-blue-800"
              onClick={handleEditDocument}
            >
              <Edit size={16} className="mr-2" />
              Editar
            </Button>
            <Button
              className="bg-orange-500 hover:bg-orange-600"
              onClick={() => {
                setGeneratedDocument("")
                setDocumentDetails("")
              }}
            >
              Nuevo Documento
            </Button>
          </div>
        </>
      )}

      {generatedDocument && (
        <div className="mt-4 flex space-x-2">
          <Button
            variant="outline"
            className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 hover:text-orange-800"
            size="sm"
            onClick={handleExportPDF}
            disabled={!generatedDocument}
          >
            <Download size={16} className="mr-2" />
            PDF
          </Button>
          <Button
            variant="outline"
            className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 hover:text-orange-800"
            size="sm"
            onClick={handleExportWord}
            disabled={!generatedDocument}
          >
            <Download size={16} className="mr-2" />
            Word
          </Button>
          <Button
            variant="outline"
            className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 hover:text-orange-800"
            size="sm"
            onClick={handleSave}
            disabled={!generatedDocument}
          >
            <Save size={16} className="mr-2" />
            Guardar
          </Button>
        </div>
      )}

      {/* Modal para editar documento */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Editar Documento</DialogTitle>
            <DialogDescription>Realiza los cambios necesarios en el documento</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="edit-title">Título del documento</Label>
            <Input
              id="edit-title"
              value={documentTitle}
              onChange={(e) => setDocumentTitle(e.target.value)}
              className="mb-4"
            />
            <Label htmlFor="edit-content">Contenido</Label>
            <Textarea
              id="edit-content"
              value={generatedDocument}
              onChange={(e) => setGeneratedDocument(e.target.value)}
              rows={15}
              className="font-mono text-sm"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveEdit} className="bg-orange-500 hover:bg-orange-600">
              Guardar Cambios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <p className="text-xs text-gray-400 mt-4 text-right">¿No encuentras lo que buscas? Contáctanos</p>
    </div>
  )
}
