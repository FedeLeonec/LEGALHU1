"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, Paperclip, Download, Trash } from "lucide-react"
import { generateLegalResponse } from "@/lib/groq"
import { useToast } from "@/components/ui/use-toast"
import { jsPDF } from "jspdf"
import FileSaver from "file-saver"

type Message = {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

export function ChatAsistente() {
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content:
        "Hola, ¿en qué puedo ayudarte hoy? Puedes preguntarme sobre leyes, procedimientos o buscar información en tus documentos.",
      role: "assistant",
      timestamp: new Date(),
    },
  ])
  const [isLoading, setIsLoading] = useState(false)
  const [retryCount, setRetryCount] = useState(0)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const { toast } = useToast()

  // Cargar mensajes del localStorage al iniciar
  useEffect(() => {
    const savedMessages = localStorage.getItem("chatMessages")
    if (savedMessages) {
      try {
        const parsedMessages = JSON.parse(savedMessages)
        setMessages(parsedMessages)
      } catch (error) {
        console.error("Error al cargar mensajes guardados:", error)
      }
    }
  }, [])

  // Guardar mensajes en localStorage cuando cambien
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem("chatMessages", JSON.stringify(messages))
    }
  }, [messages])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = async () => {
    if (message.trim() && !isLoading) {
      // Añadir mensaje del usuario
      const userMessage: Message = {
        id: Date.now().toString(),
        content: message,
        role: "user",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, userMessage])
      setMessage("")
      setIsLoading(true)

      try {
        // Generar respuesta con IA
        const response = await generateLegalResponse(message)

        // Modificar la respuesta para hacerla más natural
        const naturalResponse = response
          .replace(/como asistente legal/gi, "")
          .replace(/como asistente/gi, "")
          .replace(/soy un asistente/gi, "")
          .replace(/soy un modelo de lenguaje/gi, "")
          .replace(/como modelo de lenguaje/gi, "")
          .replace(/no puedo/gi, "no es posible")
          .trim()

        // Añadir respuesta del asistente
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: naturalResponse,
          role: "assistant",
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, assistantMessage])
        setRetryCount(0) // Resetear contador de intentos
      } catch (error) {
        console.error("Error al generar respuesta:", error)

        // Incrementar contador de intentos
        setRetryCount((prev) => prev + 1)

        // Mensaje de error personalizado basado en el número de intentos
        let errorMessage = "No se pudo generar una respuesta. Inténtalo de nuevo más tarde."

        if (retryCount > 2) {
          errorMessage =
            "Estamos experimentando problemas con el servicio. Por favor, intenta más tarde o contacta a soporte."
        }

        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        })

        // Añadir mensaje de error como respuesta del asistente
        const errorAssistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: "No pude procesar tu consulta en este momento. Por favor, intenta de nuevo más tarde.",
          role: "assistant",
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, errorAssistantMessage])
      } finally {
        setIsLoading(false)
      }
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const clearChat = () => {
    if (window.confirm("¿Estás seguro de que deseas borrar toda la conversación?")) {
      setMessages([
        {
          id: "1",
          content:
            "Hola, ¿en qué puedo ayudarte hoy? Puedes preguntarme sobre leyes, procedimientos o buscar información en tus documentos.",
          role: "assistant",
          timestamp: new Date(),
        },
      ])
      localStorage.removeItem("chatMessages")
      toast({
        title: "Chat borrado",
        description: "La conversación ha sido borrada",
      })
    }
  }

  const exportToPDF = () => {
    try {
      const doc = new jsPDF()

      // Título
      doc.setFontSize(16)
      doc.text("Conversación con Asistente Legal", 20, 20)

      // Contenido
      doc.setFontSize(12)
      let y = 30

      messages.forEach((msg) => {
        const prefix = msg.role === "user" ? "Tú: " : "Respuesta: "
        const text = `${prefix}${msg.content}`

        // Dividir el texto en líneas para que quepa en la página
        const splitText = doc.splitTextToSize(text, 170)

        // Verificar si necesitamos una nueva página
        if (y + splitText.length * 7 > 280) {
          doc.addPage()
          y = 20
        }

        doc.text(splitText, 20, y)
        y += splitText.length * 7 + 5
      })

      // Guardar el PDF
      doc.save("conversacion-legal.pdf")

      toast({
        title: "PDF exportado",
        description: "La conversación se ha exportado como PDF",
      })
    } catch (error) {
      console.error("Error al exportar PDF:", error)
      toast({
        title: "Error",
        description: "No se pudo exportar la conversación como PDF",
        variant: "destructive",
      })
    }
  }

  const exportToWord = () => {
    try {
      // Crear contenido HTML
      let htmlContent = `
        <html>
          <head>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              h1 { color: #333; }
              .message { margin-bottom: 10px; }
              .user { color: #0066cc; }
              .assistant { color: #009933; }
            </style>
          </head>
          <body>
            <h1>Conversación Legal</h1>
      `

      // Añadir mensajes
      messages.forEach((msg) => {
        const role = msg.role === "user" ? "Tú" : "Respuesta"
        const className = msg.role === "user" ? "user" : "assistant"

        htmlContent += `
          <div class="message">
            <strong class="${className}">${role}:</strong> ${msg.content}
          </div>
        `
      })

      htmlContent += `
          </body>
        </html>
      `

      // Crear blob y descargar
      const blob = new Blob([htmlContent], { type: "application/msword" })
      FileSaver.saveAs(blob, "conversacion-legal.doc")

      toast({
        title: "Word exportado",
        description: "La conversación se ha exportado como Word",
      })
    } catch (error) {
      console.error("Error al exportar Word:", error)
      toast({
        title: "Error",
        description: "No se pudo exportar la conversación como Word",
        variant: "destructive",
      })
    }
  }

  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Asistente Jurídico</h3>

      <div className="border border-gray-200 rounded-lg p-4 h-64 overflow-y-auto bg-gray-50 mb-4">
        <p className="text-sm text-gray-600 mb-2">
          <strong>Chat General:</strong> Habla con el asistente, pregúntale o busca información en los documentos.
        </p>

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`p-3 rounded-lg my-2 max-w-xs ${
              msg.role === "assistant"
                ? "bg-orange-100 text-orange-800 inline-block"
                : "bg-blue-100 text-blue-800 inline-block ml-auto"
            }`}
          >
            <p className="text-sm">{msg.content}</p>
          </div>
        ))}

        {isLoading && (
          <div className="bg-orange-100 p-3 rounded-lg inline-block max-w-xs">
            <p className="text-sm text-orange-800">Escribiendo respuesta...</p>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="flex items-center gap-2">
        <Input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Escribe tu consulta aquí..."
          className="flex-grow"
          onKeyDown={handleKeyDown}
          disabled={isLoading}
        />
        <Button onClick={handleSendMessage} className="bg-orange-500 hover:bg-orange-600" disabled={isLoading}>
          <Send size={20} />
        </Button>
        <Button variant="outline" disabled={isLoading}>
          <Paperclip size={20} />
        </Button>
      </div>

      <div className="mt-4 flex space-x-2">
        <Button
          variant="outline"
          className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 hover:text-orange-800"
          size="sm"
          onClick={exportToPDF}
        >
          <Download size={16} className="mr-2" />
          PDF
        </Button>
        <Button
          variant="outline"
          className="bg-orange-100 text-orange-700 border-orange-200 hover:bg-orange-200 hover:text-orange-800"
          size="sm"
          onClick={exportToWord}
        >
          <Download size={16} className="mr-2" />
          Word
        </Button>
        <Button
          variant="outline"
          className="bg-red-100 text-red-700 border-red-200 hover:bg-red-200 hover:text-red-800"
          size="sm"
          onClick={clearChat}
        >
          <Trash size={16} className="mr-2" />
          Borrar Chat
        </Button>
      </div>

      <p className="text-xs text-gray-400 mt-4 text-right">¿No encuentras lo que buscas? Contáctanos</p>
    </div>
  )
}
