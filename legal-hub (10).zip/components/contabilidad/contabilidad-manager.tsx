"use client"

import { useState } from "react"
import {
  Search,
  Plus,
  Receipt,
  FileBarChart2,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Eye,
  Pencil,
  Download,
  Trash2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export function ContabilidadManager() {
  const [filterType, setFilterType] = useState("Todos")
  const [searchQuery, setSearchQuery] = useState("")

  const transactions = [
    {
      id: 1,
      fecha: "2025-04-10",
      descripcion: "Honorarios Caso #11984",
      tipo: "Ingreso",
      monto: 1500.0,
      estado: "Pagado",
    },
    {
      id: 2,
      fecha: "2025-04-08",
      descripcion: "Pago servicio de mensajería",
      tipo: "Egreso",
      monto: -45.5,
      estado: "Pagado",
    },
    {
      id: 3,
      fecha: "2025-04-05",
      descripcion: "Factura #F001 - Cliente Tech Solutions",
      tipo: "Factura",
      monto: 2500.0,
      estado: "Pendiente",
    },
    {
      id: 4,
      fecha: "2025-04-02",
      descripcion: "Compra papelería oficina",
      tipo: "Egreso",
      monto: -120.0,
      estado: "Pagado",
    },
    {
      id: 5,
      fecha: "2025-04-01",
      descripcion: "Anticipo Caso #91034",
      tipo: "Ingreso",
      monto: 800.0,
      estado: "Pagado",
    },
    {
      id: 6,
      fecha: "2025-03-28",
      descripcion: "Pago alquiler oficina Marzo",
      tipo: "Egreso",
      monto: -950.0,
      estado: "Pagado",
    },
  ]

  const ingresosMes = transactions
    .filter((t) => t.tipo === "Ingreso" && t.fecha.startsWith("2025-04"))
    .reduce((sum, t) => sum + t.monto, 0)

  const egresosMes = transactions
    .filter((t) => t.tipo === "Egreso" && t.fecha.startsWith("2025-04"))
    .reduce((sum, t) => sum + t.monto, 0)

  const saldoActual = transactions.reduce((sum, t) => sum + (t.tipo !== "Factura" ? t.monto : 0), 0)

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("es-EC", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center text-green-700 mb-1">
                <TrendingUp size={18} className="mr-2" />
                <h4 className="font-semibold">Ingresos del Mes (Abril)</h4>
              </div>
              <p className="text-2xl font-bold text-green-700">{formatCurrency(ingresosMes)}</p>
            </CardContent>
          </Card>

          <Card className="bg-red-50 border-red-200">
            <CardContent className="p-4">
              <div className="flex items-center text-red-700 mb-1">
                <TrendingDown size={18} className="mr-2" />
                <h4 className="font-semibold">Egresos del Mes (Abril)</h4>
              </div>
              <p className="text-2xl font-bold text-red-700">{formatCurrency(egresosMes)}</p>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center text-blue-700 mb-1">
                <DollarSign size={18} className="mr-2" />
                <h4 className="font-semibold">Saldo Actual (Aprox.)</h4>
              </div>
              <p className="text-2xl font-bold text-blue-700">{formatCurrency(saldoActual)}</p>
            </CardContent>
          </Card>
        </div>

        <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
          <div className="flex flex-wrap gap-3">
            <Button className="bg-orange-500 hover:bg-orange-600">
              <Plus size={16} className="mr-2" />
              Registrar Ingreso/Egreso
            </Button>
            <Button className="bg-orange-500 hover:bg-orange-600">
              <Receipt size={16} className="mr-2" />
              Crear Factura
            </Button>
            <Button variant="outline" className="border-gray-300">
              <FileBarChart2 size={16} className="mr-2" />
              Generar Reporte
            </Button>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center border border-gray-300 rounded-md overflow-hidden focus-within:ring-1 focus-within:ring-orange-500 focus-within:border-orange-500">
              <span className="pl-3 pr-1 text-gray-400">
                <Search size={18} />
              </span>
              <Input
                type="text"
                placeholder="Buscar transacción..."
                className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center text-sm">
              <label htmlFor="filter-contabilidad-tipo" className="mr-2 text-gray-600">
                Filtrar:
              </label>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger id="filter-contabilidad-tipo" className="w-[120px]">
                  <SelectValue placeholder="Todos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Todos">Todos</SelectItem>
                  <SelectItem value="Ingresos">Ingresos</SelectItem>
                  <SelectItem value="Egresos">Egresos</SelectItem>
                  <SelectItem value="Facturas">Facturas</SelectItem>
                  <SelectItem value="Pagos">Pagos</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <h3 className="text-lg font-semibold text-gray-800 mb-4">Últimas Transacciones</h3>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Fecha</TableHead>
                <TableHead>Descripción</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead className="text-right">Monto</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead className="text-center">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.map((t) => (
                <TableRow key={t.id}>
                  <TableCell className="whitespace-nowrap">{t.fecha}</TableCell>
                  <TableCell>{t.descripcion}</TableCell>
                  <TableCell>
                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                        t.tipo === "Ingreso"
                          ? "bg-green-100 text-green-700"
                          : t.tipo === "Egreso"
                            ? "bg-red-100 text-red-700"
                            : t.tipo === "Factura"
                              ? "bg-blue-100 text-blue-700"
                              : "bg-gray-100 text-gray-700"
                      }`}
                    >
                      {t.tipo}
                    </span>
                  </TableCell>
                  <TableCell className={`text-right font-medium ${t.monto >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {formatCurrency(t.monto)}
                  </TableCell>
                  <TableCell>
                    <span
                      className={`px-2.5 py-1 rounded-full text-xs font-medium ${
                        t.estado === "Pagado"
                          ? "bg-green-100 text-green-700"
                          : t.estado === "Pendiente"
                            ? "bg-yellow-100 text-yellow-700"
                            : "bg-gray-100 text-gray-700"
                      }`}
                    >
                      {t.estado}
                    </span>
                  </TableCell>
                  <TableCell className="text-center space-x-2">
                    <Button variant="ghost" size="icon" title="Ver Detalles">
                      <Eye size={16} className="text-gray-400 hover:text-blue-600" />
                    </Button>
                    <Button variant="ghost" size="icon" title="Editar">
                      <Pencil size={16} className="text-gray-400 hover:text-green-600" />
                    </Button>
                    {t.tipo === "Factura" && (
                      <Button variant="ghost" size="icon" title="Descargar PDF">
                        <Download size={16} className="text-gray-400 hover:text-purple-600" />
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" title="Eliminar">
                      <Trash2 size={16} className="text-gray-400 hover:text-red-600" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="flex items-center justify-between pt-4">
          <span className="text-xs font-normal text-gray-500">
            Mostrando <span className="font-semibold text-gray-900">1-{transactions.length}</span> de{" "}
            <span className="font-semibold text-gray-900">50</span>
          </span>
        </div>
      </CardContent>
    </Card>
  )
}
