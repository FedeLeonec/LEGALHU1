"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, Search, Edit, Trash2, Eye, CheckCircle, XCircle, UserPlus } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { supabaseClient } from "@/lib/supabase"

export function UsuariosManager() {
  const { user, isSuperAdmin } = useAuth()
  const { toast } = useToast()
  const [usuarios, setUsuarios] = useState([])
  const [empresas, setEmpresas] = useState([])
  const [roles, setRoles] = useState([])
  const [busqueda, setBusqueda] = useState("")
  const [isCreatingUser, setIsCreatingUser] = useState(false)
  const [isEditingUser, setIsEditingUser] = useState(false)
  const [isViewingUser, setIsViewingUser] = useState(false)
  const [isEditingRoles, setIsEditingRoles] = useState(false)
  const [selectedUser, setSelectedUser] = useState(null)
  const [selectedRole, setSelectedRole] = useState(null)

  // Módulos para permisos
  const [modulos, setModulos] = useState([
    { id: "dashboard", nombre: "Dashboard", permiso: "editar" },
    { id: "asistente", nombre: "Asistente Legal", permiso: "editar" },
    { id: "documentos", nombre: "Documentos", permiso: "editar" },
    { id: "correos", nombre: "Correos", permiso: "editar" },
    { id: "calendario", nombre: "Calendario", permiso: "editar" },
    { id: "tareas", nombre: "Tareas", permiso: "editar" },
    { id: "casos", nombre: "Casos", permiso: "editar" },
    { id: "clientes", nombre: "Clientes", permiso: "editar" },
    { id: "contactos", nombre: "Contactos", permiso: "editar" },
    { id: "contabilidad", nombre: "Contabilidad", permiso: "editar" },
    { id: "notificaciones", nombre: "Notificaciones", permiso: "editar" },
    { id: "archivos", nombre: "Archivos", permiso: "editar" },
    { id: "ajustes", nombre: "Ajustes", permiso: "editar" },
    { id: "usuarios", nombre: "Usuarios", permiso: "editar" },
    { id: "empresas", nombre: "Empresas", permiso: "ocultar" },
  ])

  // Formulario para nuevo usuario
  const [nuevoUsuario, setNuevoUsuario] = useState({
    nombre: "",
    email: "",
    password: "",
    rol: "",
    empresa: "",
    estado: true,
  })

  // Cargar datos iniciales
  useEffect(() => {
    cargarUsuarios()
    cargarEmpresas()
    cargarRoles()
  }, [user])

  // Función para cargar usuarios
  const cargarUsuarios = () => {
    try {
      // Obtener usuarios desde localStorage
      const storedUsers = JSON.parse(localStorage.getItem("users") || "[]")

      // Filtrar por empresa si no es SuperAdmin
      let filteredUsers = storedUsers
      if (user && !isSuperAdmin()) {
        filteredUsers = storedUsers.filter((u) => u.empresa === user.empresa)
      }

      setUsuarios(filteredUsers)
    } catch (error) {
      console.error("Error al cargar usuarios:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar los usuarios",
        variant: "destructive",
      })
    }
  }

  // Función para cargar empresas
  const cargarEmpresas = async () => {
    try {
      const { data, error } = await supabaseClient.from("empresas").select("*").order("nombre", { ascending: true })

      if (error) throw error

      setEmpresas(data || [])
    } catch (error) {
      console.error("Error al cargar empresas:", error)
    }
  }

  // Función para cargar roles
  const cargarRoles = async () => {
    try {
      // Roles predefinidos
      const rolesData = [
        {
          id: "admin",
          nombre: "Administrador",
          descripcion: "Acceso completo a todas las funciones",
          permisos: {
            dashboard: "editar",
            asistente: "editar",
            documentos: "editar",
            correos: "editar",
            calendario: "editar",
            tareas: "editar",
            casos: "editar",
            clientes: "editar",
            contactos: "editar",
            contabilidad: "editar",
            notificaciones: "editar",
            archivos: "editar",
            ajustes: "editar",
            usuarios: "editar",
            empresas: "ocultar",
          },
        },
        {
          id: "abogado",
          nombre: "Abogado",
          descripcion: "Acceso a casos, clientes y documentos",
          permisos: {
            dashboard: "editar",
            asistente: "editar",
            documentos: "editar",
            correos: "editar",
            calendario: "editar",
            tareas: "editar",
            casos: "editar",
            clientes: "editar",
            contactos: "editar",
            contabilidad: "ver",
            notificaciones: "editar",
            archivos: "editar",
            ajustes: "ver",
            usuarios: "ver",
            empresas: "ocultar",
          },
        },
        {
          id: "asistente",
          nombre: "Asistente",
          descripcion: "Acceso limitado a tareas administrativas",
          permisos: {
            dashboard: "ver",
            asistente: "ver",
            documentos: "ver",
            correos: "editar",
            calendario: "editar",
            tareas: "editar",
            casos: "ver",
            clientes: "ver",
            contactos: "editar",
            contabilidad: "ocultar",
            notificaciones: "ver",
            archivos: "ver",
            ajustes: "ocultar",
            usuarios: "ocultar",
            empresas: "ocultar",
          },
        },
        {
          id: "contador",
          nombre: "Contador",
          descripcion: "Acceso a contabilidad y finanzas",
          permisos: {
            dashboard: "ver",
            asistente: "ocultar",
            documentos: "ver",
            correos: "ver",
            calendario: "ver",
            tareas: "ver",
            casos: "ocultar",
            clientes: "ver",
            contactos: "ocultar",
            contabilidad: "editar",
            notificaciones: "ver",
            archivos: "ver",
            ajustes: "ocultar",
            usuarios: "ocultar",
            empresas: "ocultar",
          },
        },
      ]

      // Guardar roles en localStorage si no existen
      const storedRoles = localStorage.getItem("roles")
      if (!storedRoles) {
        localStorage.setItem("roles", JSON.stringify(rolesData))
      }

      // Cargar roles
      const roles = JSON.parse(localStorage.getItem("roles") || JSON.stringify(rolesData))
      setRoles(roles)
    } catch (error) {
      console.error("Error al cargar roles:", error)
    }
  }

  // Función para crear un nuevo usuario
  const crearUsuario = () => {
    try {
      // Validar campos obligatorios
      if (!nuevoUsuario.nombre || !nuevoUsuario.email || !nuevoUsuario.password || !nuevoUsuario.rol) {
        toast({
          title: "Error",
          description: "Por favor, completa todos los campos obligatorios",
          variant: "destructive",
        })
        return
      }

      // Verificar si el email ya existe
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      if (users.some((u) => u.email === nuevoUsuario.email)) {
        toast({
          title: "Error",
          description: "Ya existe un usuario con ese email",
          variant: "destructive",
        })
        return
      }

      // Obtener permisos del rol seleccionado
      const rolSeleccionado = roles.find((r) => r.id === nuevoUsuario.rol)
      if (!rolSeleccionado) {
        toast({
          title: "Error",
          description: "Rol no válido",
          variant: "destructive",
        })
        return
      }

      // Obtener nombre de la empresa
      let empresaNombre = ""
      if (isSuperAdmin()) {
        const empresaSeleccionada = empresas.find((e) => e.id === nuevoUsuario.empresa)
        empresaNombre = empresaSeleccionada ? empresaSeleccionada.nombre : ""
      } else {
        empresaNombre = user.empresa_nombre
      }

      // Generar ID único para el usuario
      const userId = `user_${Date.now()}`

      // Crear nuevo usuario
      const userData = {
        id: userId,
        nombre: nuevoUsuario.nombre,
        email: nuevoUsuario.email,
        password: nuevoUsuario.password,
        rol: rolSeleccionado.nombre,
        empresa: isSuperAdmin() ? nuevoUsuario.empresa : user.empresa,
        empresa_nombre: empresaNombre,
        estado: nuevoUsuario.estado,
        permisos: rolSeleccionado.permisos,
        created_at: new Date().toISOString(),
        created_by: user.id,
      }

      // Guardar usuario
      users.push(userData)
      localStorage.setItem("users", JSON.stringify(users))

      toast({
        title: "Usuario creado",
        description: "El usuario se ha creado correctamente",
      })

      // Limpiar formulario y recargar usuarios
      setNuevoUsuario({
        nombre: "",
        email: "",
        password: "",
        rol: "",
        empresa: "",
        estado: true,
      })

      setIsCreatingUser(false)
      cargarUsuarios()
    } catch (error) {
      console.error("Error al crear usuario:", error)
      toast({
        title: "Error",
        description: "No se pudo crear el usuario",
        variant: "destructive",
      })
    }
  }

  // Función para editar un usuario
  const editarUsuario = () => {
    try {
      // Validar campos obligatorios
      if (!selectedUser.nombre || !selectedUser.email || !selectedUser.rol) {
        toast({
          title: "Error",
          description: "Por favor, completa todos los campos obligatorios",
          variant: "destructive",
        })
        return
      }

      // Verificar si el email ya existe (excepto el propio usuario)
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      if (users.some((u) => u.email === selectedUser.email && u.id !== selectedUser.id)) {
        toast({
          title: "Error",
          description: "Ya existe otro usuario con ese email",
          variant: "destructive",
        })
        return
      }

      // Obtener permisos del rol seleccionado
      const rolSeleccionado = roles.find((r) => r.id === selectedUser.rol)
      if (!rolSeleccionado) {
        toast({
          title: "Error",
          description: "Rol no válido",
          variant: "destructive",
        })
        return
      }

      // Actualizar usuario
      const updatedUsers = users.map((u) => {
        if (u.id === selectedUser.id) {
          return {
            ...u,
            nombre: selectedUser.nombre,
            email: selectedUser.email,
            password: selectedUser.password || u.password,
            rol: rolSeleccionado.nombre,
            estado: selectedUser.estado,
            permisos: selectedUser.permisos || rolSeleccionado.permisos,
            updated_at: new Date().toISOString(),
          }
        }
        return u
      })

      localStorage.setItem("users", JSON.stringify(updatedUsers))

      toast({
        title: "Usuario actualizado",
        description: "El usuario se ha actualizado correctamente",
      })

      setIsEditingUser(false)
      cargarUsuarios()
    } catch (error) {
      console.error("Error al editar usuario:", error)
      toast({
        title: "Error",
        description: "No se pudo actualizar el usuario",
        variant: "destructive",
      })
    }
  }

  // Función para eliminar un usuario
  const eliminarUsuario = (usuario) => {
    if (!confirm(`¿Estás seguro de eliminar al usuario ${usuario.nombre}? Esta acción no se puede deshacer.`)) {
      return
    }

    try {
      // Eliminar usuario
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const filteredUsers = users.filter((u) => u.id !== usuario.id)
      localStorage.setItem("users", JSON.stringify(filteredUsers))

      toast({
        title: "Usuario eliminado",
        description: "El usuario se ha eliminado correctamente",
      })

      cargarUsuarios()
    } catch (error) {
      console.error("Error al eliminar usuario:", error)
      toast({
        title: "Error",
        description: "No se pudo eliminar el usuario",
        variant: "destructive",
      })
    }
  }

  // Función para ver detalles de un usuario
  const verUsuario = (usuario) => {
    setSelectedUser(usuario)
    setIsViewingUser(true)
  }

  // Función para preparar edición de usuario
  const prepararEdicion = (usuario) => {
    // Encontrar el ID del rol
    const rolId = roles.find((r) => r.nombre === usuario.rol)?.id || ""

    setSelectedUser({
      ...usuario,
      rol: rolId,
      password: "", // No mostrar la contraseña actual
    })

    setIsEditingUser(true)
  }

  // Función para editar un rol
  const editarRol = () => {
    try {
      // Validar que el rol exista
      if (!selectedRole) {
        toast({
          title: "Error",
          description: "Rol no válido",
          variant: "destructive",
        })
        return
      }

      // Crear objeto de permisos
      const permisos = {}
      modulos.forEach((modulo) => {
        permisos[modulo.id] = modulo.permiso
      })

      // Actualizar rol
      const updatedRoles = roles.map((r) => {
        if (r.id === selectedRole.id) {
          return {
            ...r,
            permisos,
          }
        }
        return r
      })

      localStorage.setItem("roles", JSON.stringify(updatedRoles))

      // Actualizar usuarios con este rol
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const updatedUsers = users.map((u) => {
        if (u.rol === selectedRole.nombre) {
          return {
            ...u,
            permisos,
          }
        }
        return u
      })

      localStorage.setItem("users", JSON.stringify(updatedUsers))

      toast({
        title: "Rol actualizado",
        description: "Los permisos del rol se han actualizado correctamente",
      })

      setIsEditingRoles(false)
      setRoles(updatedRoles)
      cargarUsuarios()
    } catch (error) {
      console.error("Error al editar rol:", error)
      toast({
        title: "Error",
        description: "No se pudieron actualizar los permisos del rol",
        variant: "destructive",
      })
    }
  }

  // Función para preparar edición de rol
  const prepararEdicionRol = (rol) => {
    setSelectedRole(rol)

    // Configurar módulos según los permisos del rol
    const rolPermisos = rol.permisos || {}
    setModulos(
      modulos.map((m) => ({
        ...m,
        permiso: rolPermisos[m.id] || "ocultar",
      })),
    )

    setIsEditingRoles(true)
  }

  // Filtrar usuarios por búsqueda
  const usuariosFiltrados = usuarios.filter(
    (usuario) =>
      usuario.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
      usuario.email.toLowerCase().includes(busqueda.toLowerCase()) ||
      usuario.rol.toLowerCase().includes(busqueda.toLowerCase()),
  )

  return (
    <div className="space-y-4">
      <Tabs defaultValue="usuarios">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="usuarios">Usuarios</TabsTrigger>
          <TabsTrigger value="roles">Roles y Permisos</TabsTrigger>
        </TabsList>

        {/* Pestaña de Usuarios */}
        <TabsContent value="usuarios" className="space-y-4">
          {/* Barra de acciones */}
          <div className="flex flex-col sm:flex-row gap-4 justify-between">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar usuarios..."
                className="pl-8"
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
              />
            </div>
            <Button onClick={() => setIsCreatingUser(true)} className="bg-orange-500 hover:bg-orange-600">
              <UserPlus className="mr-2 h-4 w-4" /> Nuevo Usuario
            </Button>
          </div>

          {/* Tabla de usuarios */}
          {usuariosFiltrados.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nombre</TableHead>
                    <TableHead className="hidden md:table-cell">Email</TableHead>
                    <TableHead className="hidden md:table-cell">Rol</TableHead>
                    <TableHead className="hidden md:table-cell">Empresa</TableHead>
                    <TableHead className="hidden md:table-cell">Estado</TableHead>
                    <TableHead className="text-right">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {usuariosFiltrados.map((usuario) => (
                    <TableRow key={usuario.id}>
                      <TableCell className="font-medium">{usuario.nombre}</TableCell>
                      <TableCell className="hidden md:table-cell">{usuario.email}</TableCell>
                      <TableCell className="hidden md:table-cell">{usuario.rol}</TableCell>
                      <TableCell className="hidden md:table-cell">{usuario.empresa_nombre || "-"}</TableCell>
                      <TableCell className="hidden md:table-cell">
                        {usuario.estado ? (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Activo
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            Inactivo
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => verUsuario(usuario)} title="Ver detalles">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => prepararEdicion(usuario)} title="Editar">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => eliminarUsuario(usuario)}
                            title="Eliminar"
                            className="text-red-500"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-10 border rounded-lg">
              <Users className="h-12 w-12 mx-auto text-gray-400" />
              <h3 className="mt-4 text-lg font-medium">No hay usuarios</h3>
              <p className="mt-1 text-gray-500">
                {busqueda ? "No se encontraron usuarios con esa búsqueda" : "Crea un usuario para comenzar"}
              </p>
            </div>
          )}
        </TabsContent>

        {/* Pestaña de Roles */}
        <TabsContent value="roles" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {roles.map((rol) => (
              <Card key={rol.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="p-4">
                    <h3 className="text-lg font-semibold">{rol.nombre}</h3>
                    <p className="text-sm text-gray-500 mt-1">{rol.descripcion}</p>
                  </div>
                  <div className="border-t p-4 bg-gray-50">
                    <Button
                      onClick={() => prepararEdicionRol(rol)}
                      className="w-full bg-orange-500 hover:bg-orange-600"
                    >
                      Configurar permisos
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Modal para crear usuario */}
      <Dialog open={isCreatingUser} onOpenChange={setIsCreatingUser}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Crear nuevo usuario</DialogTitle>
            <DialogDescription>Ingresa la información para crear un nuevo usuario</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="nombre">Nombre completo *</Label>
              <Input
                id="nombre"
                value={nuevoUsuario.nombre}
                onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, nombre: e.target.value })}
                placeholder="Ej: Juan Pérez"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={nuevoUsuario.email}
                onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, email: e.target.value })}
                placeholder="usuario@ejemplo.com"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Contraseña *</Label>
              <Input
                id="password"
                type="password"
                value={nuevoUsuario.password}
                onChange={(e) => setNuevoUsuario({ ...nuevoUsuario, password: e.target.value })}
                placeholder="Contraseña segura"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rol">Rol *</Label>
              <Select
                value={nuevoUsuario.rol}
                onValueChange={(value) => setNuevoUsuario({ ...nuevoUsuario, rol: value })}
              >
                <SelectTrigger id="rol">
                  <SelectValue placeholder="Seleccionar rol" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((rol) => (
                    <SelectItem key={rol.id} value={rol.id}>
                      {rol.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {isSuperAdmin() && (
              <div className="space-y-2">
                <Label htmlFor="empresa">Empresa *</Label>
                <Select
                  value={nuevoUsuario.empresa}
                  onValueChange={(value) => setNuevoUsuario({ ...nuevoUsuario, empresa: value })}
                >
                  <SelectTrigger id="empresa">
                    <SelectValue placeholder="Seleccionar empresa" />
                  </SelectTrigger>
                  <SelectContent>
                    {empresas.map((empresa) => (
                      <SelectItem key={empresa.id} value={empresa.id}>
                        {empresa.nombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="flex items-center space-x-2">
              <Checkbox
                id="estado"
                checked={nuevoUsuario.estado}
                onCheckedChange={(checked) => setNuevoUsuario({ ...nuevoUsuario, estado: checked === true })}
              />
              <label
                htmlFor="estado"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Usuario activo
              </label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreatingUser(false)}>
              Cancelar
            </Button>
            <Button onClick={crearUsuario} className="bg-orange-500 hover:bg-orange-600">
              Crear usuario
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para editar usuario */}
      <Dialog open={isEditingUser} onOpenChange={setIsEditingUser}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Editar usuario</DialogTitle>
            <DialogDescription>Modifica la información del usuario</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-nombre">Nombre completo *</Label>
              <Input
                id="edit-nombre"
                value={selectedUser?.nombre || ""}
                onChange={(e) => setSelectedUser({ ...selectedUser, nombre: e.target.value })}
                placeholder="Ej: Juan Pérez"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-email">Email *</Label>
              <Input
                id="edit-email"
                type="email"
                value={selectedUser?.email || ""}
                onChange={(e) => setSelectedUser({ ...selectedUser, email: e.target.value })}
                placeholder="usuario@ejemplo.com"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-password">Contraseña (dejar en blanco para mantener la actual)</Label>
              <Input
                id="edit-password"
                type="password"
                value={selectedUser?.password || ""}
                onChange={(e) => setSelectedUser({ ...selectedUser, password: e.target.value })}
                placeholder="Nueva contraseña"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-rol">Rol *</Label>
              <Select
                value={selectedUser?.rol || ""}
                onValueChange={(value) => setSelectedUser({ ...selectedUser, rol: value })}
              >
                <SelectTrigger id="edit-rol">
                  <SelectValue placeholder="Seleccionar rol" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((rol) => (
                    <SelectItem key={rol.id} value={rol.id}>
                      {rol.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="edit-estado"
                checked={selectedUser?.estado}
                onCheckedChange={(checked) => setSelectedUser({ ...selectedUser, estado: checked === true })}
              />
              <label
                htmlFor="edit-estado"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Usuario activo
              </label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditingUser(false)}>
              Cancelar
            </Button>
            <Button onClick={editarUsuario} className="bg-orange-500 hover:bg-orange-600">
              Guardar cambios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para ver detalles de usuario */}
      <Dialog open={isViewingUser} onOpenChange={setIsViewingUser}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Detalles del usuario</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Nombre</h3>
                <p className="mt-1">{selectedUser?.nombre || "-"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Email</h3>
                <p className="mt-1">{selectedUser?.email || "-"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Rol</h3>
                <p className="mt-1">{selectedUser?.rol || "-"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Empresa</h3>
                <p className="mt-1">{selectedUser?.empresa_nombre || "-"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Estado</h3>
                <p className="mt-1">
                  {selectedUser?.estado ? (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Activo
                    </span>
                  ) : (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                      Inactivo
                    </span>
                  )}
                </p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Fecha de creación</h3>
                <p className="mt-1">
                  {selectedUser?.created_at ? new Date(selectedUser.created_at).toLocaleDateString() : "-"}
                </p>
              </div>
            </div>
            <div className="pt-2">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Permisos</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 border rounded-md p-3">
                {selectedUser?.permisos &&
                  Object.entries(selectedUser.permisos).map(([modulo, permiso]) => (
                    <div key={modulo} className="flex items-center gap-2">
                      {permiso === "editar" ? (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      ) : permiso === "ver" ? (
                        <Eye className="h-4 w-4 text-blue-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                      <span className="text-sm capitalize">
                        {modulo}: {permiso}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsViewingUser(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para editar permisos de rol */}
      <Dialog open={isEditingRoles} onOpenChange={setIsEditingRoles}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Configurar permisos: {selectedRole?.nombre}</DialogTitle>
            <DialogDescription>Define los permisos para cada módulo del sistema</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between mb-2">
                <Label>Módulo</Label>
                <Label>Permiso</Label>
              </div>
              <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                {modulos.map((modulo) => (
                  <div key={modulo.id} className="flex items-center justify-between border-b pb-2">
                    <span className="text-sm font-medium">{modulo.nombre}</span>
                    <Select
                      value={modulo.permiso}
                      onValueChange={(value) => {
                        setModulos(modulos.map((m) => (m.id === modulo.id ? { ...m, permiso: value } : m)))
                      }}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Seleccionar" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="editar">Editar</SelectItem>
                        <SelectItem value="ver">Ver</SelectItem>
                        <SelectItem value="ocultar">Ocultar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditingRoles(false)}>
              Cancelar
            </Button>
            <Button onClick={editarRol} className="bg-orange-500 hover:bg-orange-600">
              Guardar permisos
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
