"use client"

import { useState } from "react"
import { Search, Plus, Folder, ArrowLeft, Eye, Download, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function CasosManager() {
  const [view, setView] = useState("list")
  const [selectedCase, setSelectedCase] = useState(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [filterType, setFilterType] = useState("Nombre")

  const casesData = [
    { id: "11984", name: "Despido Injustif...", cliente: "Juan Rodriguez", status: "Activo" },
    { id: "32873", name: "Arrendamiento...", cliente: "Maria Sanchez", status: "Activo" },
    { id: "56002", name: "Acuerdo Confid...", cliente: "Tech Solutions", status: "Activo" },
    { id: "88721", name: "Poder General", cliente: "Laura Fernandez", status: "Cerrado" },
    { id: "91034", name: "Divorcio Conten...", cliente: "Mario Gomez", status: "Activo" },
    { id: "77542", name: "Reclamación De...", cliente: "Dimitri Petrenko", status: "Activo" },
  ]

  const caseDetails = {
    "11984": {
      escritos: [
        { name: "Demanda inicial.docx", icon: FileText, color: "blue" },
        { name: "Cálculo indemnización.xlsx", icon: FileText, color: "blue" },
      ],
      pruebas: [
        { name: "Contrato Laboral.pdf", icon: FileText, color: "purple" },
        { name: "Captura Burofax.png", icon: FileText, color: "purple" },
      ],
    },
    "32873": {
      escritos: [
        { name: "Contrato Arrendamiento.docx", icon: FileText, color: "blue" },
        { name: "Anexo Modificacion.docx", icon: FileText, color: "blue" },
      ],
      pruebas: [{ name: "Fotos Local.zip", icon: FileText, color: "purple" }],
    },
  }

  const handleViewCase = (caseData) => {
    setSelectedCase({
      ...caseData,
      details: caseDetails[caseData.id] || { escritos: [], pruebas: [] },
    })
    setView("detail")
  }

  const handleCreateCaseSubmit = (event) => {
    event.preventDefault()
    console.log("Creating case...")
    setIsModalOpen(false)
  }

  return (
    <div className="space-y-6">
      {view === "list" && (
        <div id="casos-list-view">
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <div className="flex items-center border border-gray-300 rounded-md overflow-hidden focus-within:ring-1 focus-within:ring-orange-500 focus-within:border-orange-500 w-full sm:w-1/3">
                  <span className="pl-3 pr-1 text-gray-400">
                    <Search size={18} />
                  </span>
                  <Input
                    type="text"
                    placeholder="Buscar en casos..."
                    className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                  />
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center text-sm">
                    <label htmlFor="filter-nombre-caso" className="mr-2 text-gray-600">
                      Filtrar:
                    </label>
                    <Select value={filterType} onValueChange={setFilterType}>
                      <SelectTrigger id="filter-nombre-caso" className="w-[120px]">
                        <SelectValue placeholder="Nombre" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Nombre">Nombre</SelectItem>
                        <SelectItem value="Cliente">Cliente</SelectItem>
                        <SelectItem value="ID">ID</SelectItem>
                        <SelectItem value="Estado">Estado</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-orange-500 hover:bg-orange-600">
                        <Plus size={16} className="mr-2" />
                        Crear Caso
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Crear Nuevo Caso</DialogTitle>
                        <DialogDescription>Complete los detalles para crear un nuevo caso</DialogDescription>
                      </DialogHeader>
                      <form onSubmit={handleCreateCaseSubmit}>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="case-name">Nombre del Caso:</Label>
                            <Input id="case-name" required />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="client-name">Nombre del Cliente:</Label>
                            <Input id="client-name" required />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="case-id-input">ID del Caso:</Label>
                            <Input id="case-id-input" required />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>
                            Cancelar
                          </Button>
                          <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
                            Guardar Caso
                          </Button>
                        </DialogFooter>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5">
                {casesData.map((caseItem) => (
                  <div
                    key={caseItem.id}
                    onClick={() => handleViewCase(caseItem)}
                    className="bg-gray-50 border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer hover:border-orange-300"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <Folder size={18} className="text-orange-500 flex-shrink-0" />
                      <h4 className="font-semibold text-gray-800 truncate text-sm">{caseItem.name}</h4>
                    </div>
                    <p className="text-xs text-gray-500 mb-1 truncate">Cliente: {caseItem.cliente}</p>
                    <p className="text-xs text-gray-500 mb-2">ID: {caseItem.id}</p>
                    <span
                      className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${
                        caseItem.status === "Activo" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"
                      }`}
                    >
                      {caseItem.status}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {view === "detail" && selectedCase && (
        <div id="casos-detail-view">
          <Card>
            <CardContent className="p-6">
              <Button
                variant="link"
                onClick={() => setView("list")}
                className="text-orange-600 hover:text-orange-700 p-0 mb-4 flex items-center gap-1"
              >
                <ArrowLeft size={16} />
                Volver
              </Button>

              <h3 className="text-lg font-semibold text-gray-800 mb-6">
                Caso: {selectedCase.name} ({selectedCase.id})
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-700 mb-3 border-b border-gray-200 pb-2">
                    Escritos Presentados
                  </h4>
                  <ul className="space-y-2">
                    {selectedCase.details.escritos.map((doc, index) => {
                      const Icon = doc.icon
                      return (
                        <li
                          key={`escrito-${index}`}
                          className="flex items-center justify-between bg-gray-50 p-2.5 rounded hover:bg-gray-100 border border-gray-200"
                        >
                          <div className="flex items-center gap-2 text-sm">
                            <Icon size={16} className={`text-${doc.color}-500`} />
                            <span className="text-gray-700">{doc.name}</span>
                          </div>
                          <div className="space-x-1">
                            <Button variant="ghost" size="icon">
                              <Eye size={16} className="text-gray-400 hover:text-blue-600" />
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Download size={16} className="text-gray-400 hover:text-green-600" />
                            </Button>
                          </div>
                        </li>
                      )
                    })}
                    {selectedCase.details.escritos.length === 0 && (
                      <p className="text-sm text-gray-500 italic">No hay escritos.</p>
                    )}
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-700 mb-3 border-b border-gray-200 pb-2">
                    Pruebas Documentales
                  </h4>
                  <ul className="space-y-2">
                    {selectedCase.details.pruebas.map((doc, index) => {
                      const Icon = doc.icon
                      return (
                        <li
                          key={`prueba-${index}`}
                          className="flex items-center justify-between bg-gray-50 p-2.5 rounded hover:bg-gray-100 border border-gray-200"
                        >
                          <div className="flex items-center gap-2 text-sm">
                            <Icon size={16} className={`text-${doc.color}-500`} />
                            <span className="text-gray-700">{doc.name}</span>
                          </div>
                          <div className="space-x-1">
                            <Button variant="ghost" size="icon">
                              <Eye size={16} className="text-gray-400 hover:text-blue-600" />
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Download size={16} className="text-gray-400 hover:text-green-600" />
                            </Button>
                          </div>
                        </li>
                      )
                    })}
                    {selectedCase.details.pruebas.length === 0 && (
                      <p className="text-sm text-gray-500 italic">No hay pruebas.</p>
                    )}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
