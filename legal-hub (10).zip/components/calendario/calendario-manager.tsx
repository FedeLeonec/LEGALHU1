"use client"

import { useState, useEffect } from "react"
import { Search, Plus, ChevronLeft, ChevronRight, Bot, CalendarPlus, Clock, Trash2, Edit } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

interface Event {
  id: string
  title: string
  date: string
  time: string
  type: string
  description: string
  color: string
}

export function CalendarioManager() {
  const [currentMonth, setCurrentMonth] = useState<number>(new Date().getMonth())
  const [currentYear, setCurrentYear] = useState<number>(new Date().getFullYear())
  const [filterType, setFilterType] = useState("Fecha")
  const [events, setEvents] = useState<Event[]>([])
  const [isAddEventModalOpen, setIsAddEventModalOpen] = useState(false)
  const [isEditEventModalOpen, setIsEditEventModalOpen] = useState(false)
  const [isDeleteEventModalOpen, setIsDeleteEventModalOpen] = useState(false)
  const [selectedDate, setSelectedDate] = useState<string>("")
  const [currentEvent, setCurrentEvent] = useState<Event | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const { toast } = useToast()

  // Formulario para nuevo evento
  const [newEvent, setNewEvent] = useState<Omit<Event, "id">>({
    title: "",
    date: "",
    time: "",
    type: "Reunión",
    description: "",
    color: "blue",
  })

  // Cargar eventos del localStorage al iniciar
  useEffect(() => {
    const storedEvents = localStorage.getItem("calendarEvents")
    if (storedEvents) {
      try {
        setEvents(JSON.parse(storedEvents))
      } catch (error) {
        console.error("Error al cargar eventos guardados:", error)
      }
    } else {
      // Eventos de ejemplo si no hay guardados
      const initialEvents = [
        {
          id: "1",
          title: "Audiencia Preliminar - Caso #1892",
          date: "2025-04-16",
          time: "10:00",
          type: "Audiencia",
          description: "Audiencia preliminar para el caso de divorcio #1892",
          color: "red",
        },
        {
          id: "2",
          title: "Reunión Cliente Ana Lopez",
          date: "2025-04-17",
          time: "11:30",
          type: "Reunión",
          description: "Reunión para discutir avances en el caso de herencia",
          color: "green",
        },
        {
          id: "3",
          title: "Entrega Documentación - Caso #3201",
          date: "2025-04-18",
          time: "17:00",
          type: "Tarea",
          description: "Entregar documentación para el caso de propiedad intelectual",
          color: "indigo",
        },
        {
          id: "4",
          title: "Vencimiento Plazo - Pago Tasas #7789",
          date: "2025-04-21",
          time: "23:59",
          type: "Plazo",
          description: "Último día para pagar tasas judiciales del caso #7789",
          color: "yellow",
        },
        {
          id: "5",
          title: "Llamada Seguimiento - Caso #11984",
          date: "2025-04-25",
          time: "14:00",
          type: "Llamada",
          description: "Llamada de seguimiento con el cliente para actualizar estado del caso",
          color: "blue",
        },
      ]
      setEvents(initialEvents)
      localStorage.setItem("calendarEvents", JSON.stringify(initialEvents))
    }
  }, [])

  // Guardar eventos en localStorage cuando cambien
  useEffect(() => {
    if (events.length > 0) {
      localStorage.setItem("calendarEvents", JSON.stringify(events))
    }
  }, [events])

  // Obtener días del mes actual
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate()
  }

  // Obtener el día de la semana del primer día del mes (0 = Domingo, 6 = Sábado)
  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay()
  }

  // Generar array de días para el calendario
  const generateCalendarDays = () => {
    const daysInMonth = getDaysInMonth(currentYear, currentMonth)
    const firstDayOfMonth = getFirstDayOfMonth(currentYear, currentMonth)

    // Días del mes anterior para completar la primera semana
    const daysFromPrevMonth = firstDayOfMonth

    // Días del mes siguiente para completar la última semana
    const daysFromNextMonth = 42 - (daysFromPrevMonth + daysInMonth) // 42 = 6 semanas * 7 días

    const days = []

    // Añadir días del mes anterior
    const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1
    const prevMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear
    const daysInPrevMonth = getDaysInMonth(prevMonthYear, prevMonth)

    for (let i = daysInPrevMonth - daysFromPrevMonth + 1; i <= daysInPrevMonth; i++) {
      days.push({
        day: i,
        month: prevMonth,
        year: prevMonthYear,
        isCurrentMonth: false,
      })
    }

    // Añadir días del mes actual
    for (let i = 1; i <= daysInMonth; i++) {
      days.push({
        day: i,
        month: currentMonth,
        year: currentYear,
        isCurrentMonth: true,
      })
    }

    // Añadir días del mes siguiente
    const nextMonth = currentMonth === 11 ? 0 : currentMonth + 1
    const nextMonthYear = currentMonth === 11 ? currentYear + 1 : currentYear

    for (let i = 1; i <= daysFromNextMonth; i++) {
      days.push({
        day: i,
        month: nextMonth,
        year: nextMonthYear,
        isCurrentMonth: false,
      })
    }

    return days
  }

  // Obtener nombre del mes
  const getMonthName = (month: number) => {
    const monthNames = [
      "enero",
      "febrero",
      "marzo",
      "abril",
      "mayo",
      "junio",
      "julio",
      "agosto",
      "septiembre",
      "octubre",
      "noviembre",
      "diciembre",
    ]
    return monthNames[month]
  }

  // Navegar al mes anterior
  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11)
      setCurrentYear(currentYear - 1)
    } else {
      setCurrentMonth(currentMonth - 1)
    }
  }

  // Navegar al mes siguiente
  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0)
      setCurrentYear(currentYear + 1)
    } else {
      setCurrentMonth(currentMonth + 1)
    }
  }

  // Ir al mes actual
  const goToToday = () => {
    const today = new Date()
    setCurrentMonth(today.getMonth())
    setCurrentYear(today.getFullYear())
  }

  // Abrir modal para añadir evento
  const handleAddEvent = (date: { day: number; month: number; year: number }) => {
    const formattedDate = `${date.year}-${String(date.month + 1).padStart(2, "0")}-${String(date.day).padStart(2, "0")}`
    setSelectedDate(formattedDate)
    setNewEvent({
      ...newEvent,
      date: formattedDate,
      time: "09:00",
    })
    setIsAddEventModalOpen(true)
  }

  // Guardar nuevo evento
  const handleSaveEvent = () => {
    if (!newEvent.title.trim()) {
      toast({
        title: "Error",
        description: "El título del evento es obligatorio",
        variant: "destructive",
      })
      return
    }

    const eventId = currentEvent ? currentEvent.id : `event-${Date.now()}`

    const eventToSave: Event = {
      id: eventId,
      title: newEvent.title,
      date: newEvent.date,
      time: newEvent.time,
      type: newEvent.type,
      description: newEvent.description,
      color: newEvent.color,
    }

    if (currentEvent) {
      // Actualizar evento existente
      const updatedEvents = events.map((event) => (event.id === currentEvent.id ? eventToSave : event))
      setEvents(updatedEvents)
      toast({
        title: "Evento actualizado",
        description: "El evento ha sido actualizado correctamente",
      })
      setIsEditEventModalOpen(false)
    } else {
      // Crear nuevo evento
      setEvents([...events, eventToSave])
      toast({
        title: "Evento creado",
        description: "El evento ha sido creado correctamente",
      })
      setIsAddEventModalOpen(false)
    }

    // Resetear formulario
    setNewEvent({
      title: "",
      date: "",
      time: "",
      type: "Reunión",
      description: "",
      color: "blue",
    })
    setCurrentEvent(null)
  }

  // Abrir modal para editar evento
  const handleEditEvent = (event: Event) => {
    setCurrentEvent(event)
    setNewEvent({
      title: event.title,
      date: event.date,
      time: event.time,
      type: event.type,
      description: event.description,
      color: event.color,
    })
    setIsEditEventModalOpen(true)
  }

  // Abrir modal para eliminar evento
  const handleDeleteEvent = (event: Event) => {
    setCurrentEvent(event)
    setIsDeleteEventModalOpen(true)
  }

  // Confirmar eliminación de evento
  const confirmDeleteEvent = () => {
    if (!currentEvent) return

    const updatedEvents = events.filter((event) => event.id !== currentEvent.id)
    setEvents(updatedEvents)

    toast({
      title: "Evento eliminado",
      description: "El evento ha sido eliminado correctamente",
    })

    setIsDeleteEventModalOpen(false)
    setCurrentEvent(null)
  }

  // Obtener eventos para un día específico
  const getEventsForDay = (day: number, month: number, year: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
    return events.filter((event) => event.date === dateStr)
  }

  // Filtrar eventos próximos
  const getUpcomingEvents = () => {
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    return events
      .filter((event) => {
        const eventDate = new Date(event.date)
        eventDate.setHours(0, 0, 0, 0)
        return eventDate >= today
      })
      .sort((a, b) => {
        const dateA = new Date(`${a.date}T${a.time}`)
        const dateB = new Date(`${b.date}T${b.time}`)
        return dateA.getTime() - dateB.getTime()
      })
      .slice(0, 5) // Mostrar solo los próximos 5 eventos
  }

  // Filtrar eventos según búsqueda
  const filteredUpcomingEvents = getUpcomingEvents().filter((event) => {
    const searchLower = searchQuery.toLowerCase()

    switch (filterType) {
      case "Fecha":
        return (
          event.date.includes(searchLower) ||
          new Date(event.date).toLocaleDateString().toLowerCase().includes(searchLower)
        )
      case "Tipo Evento":
        return event.type.toLowerCase().includes(searchLower)
      case "Caso":
        return event.title.toLowerCase().includes(searchLower) || event.description.toLowerCase().includes(searchLower)
      default:
        return (
          event.title.toLowerCase().includes(searchLower) ||
          event.description.toLowerCase().includes(searchLower) ||
          event.date.includes(searchLower) ||
          event.type.toLowerCase().includes(searchLower)
        )
    }
  })

  // Verificar si un día es hoy
  const isToday = (day: number, month: number, year: number) => {
    const today = new Date()
    return day === today.getDate() && month === today.getMonth() && year === today.getFullYear()
  }

  // Obtener color de evento
  const getEventColor = (color: string) => {
    const colorMap: Record<string, string> = {
      red: "bg-red-100 text-red-800 border-red-200",
      blue: "bg-blue-100 text-blue-800 border-blue-200",
      green: "bg-green-100 text-green-800 border-green-200",
      yellow: "bg-yellow-100 text-yellow-800 border-yellow-200",
      purple: "bg-purple-100 text-purple-800 border-purple-200",
      indigo: "bg-indigo-100 text-indigo-800 border-indigo-200",
      pink: "bg-pink-100 text-pink-800 border-pink-200",
      gray: "bg-gray-100 text-gray-800 border-gray-200",
    }

    return colorMap[color] || colorMap.blue
  }

  // Formatear fecha para mostrar
  const formatDate = (dateStr: string, timeStr: string) => {
    const date = new Date(dateStr)
    const day = date.getDate()
    const month = getMonthName(date.getMonth())
    const year = date.getFullYear()

    return `${day} de ${month} de ${year} - ${timeStr}`
  }

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <Input
          placeholder="Buscar eventos..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="flex flex-wrap justify-end items-center mb-6 gap-4">
        <div className="flex items-center space-x-4">
          <div className="flex items-center text-sm">
            <label htmlFor="filter-fecha-cal" className="mr-2 text-gray-600">
              Filtrar:
            </label>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger id="filter-fecha-cal" className="w-[120px]">
                <SelectValue placeholder="Fecha" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Fecha">Fecha</SelectItem>
                <SelectItem value="Tipo Evento">Tipo Evento</SelectItem>
                <SelectItem value="Caso">Caso</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button
            className="bg-orange-500 hover:bg-orange-600"
            onClick={() => {
              const today = new Date()
              const formattedDate = today.toISOString().split("T")[0]
              setSelectedDate(formattedDate)
              setNewEvent({
                ...newEvent,
                date: formattedDate,
                time: "09:00",
              })
              setIsAddEventModalOpen(true)
            }}
          >
            <Plus size={16} className="mr-2" />
            Evento
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Bot size={18} />
              Asistente de Calendario IA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-gray-500 mb-4">Gestiona tu calendario usando lenguaje natural.</p>
            <div className="space-y-2">
              <Button
                onClick={() => {
                  const today = new Date()
                  const formattedDate = today.toISOString().split("T")[0]
                  setSelectedDate(formattedDate)
                  setNewEvent({
                    ...newEvent,
                    date: formattedDate,
                    time: "09:00",
                  })
                  setIsAddEventModalOpen(true)
                }}
                className="w-full bg-blue-100 text-blue-700 hover:bg-blue-200 border-blue-200"
              >
                <CalendarPlus size={14} className="mr-2" />
                Agendar Cita
              </Button>
              <Button
                onClick={() => {
                  toast({
                    title: "Disponibilidad encontrada",
                    description: "Tienes horarios disponibles mañana entre 10:00 y 12:00",
                  })
                }}
                className="w-full bg-purple-100 text-purple-700 hover:bg-purple-200 border-purple-200"
              >
                <Search size={14} className="mr-2" />
                Buscar Disponibilidad
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Próximos Eventos</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredUpcomingEvents.length > 0 ? (
              <ul className="space-y-3 max-h-48 overflow-y-auto">
                {filteredUpcomingEvents.map((event) => (
                  <li
                    key={event.id}
                    className="flex items-center justify-between pb-2 border-b border-gray-100 last:border-b-0 pr-2"
                  >
                    <div className="flex items-center gap-3">
                      <span className={`w-2 h-2 rounded-full flex-shrink-0 bg-${event.color}-500`}></span>
                      <div>
                        <p className="font-medium text-gray-700">{event.title}</p>
                        <p className="text-xs text-gray-500">{formatDate(event.date, event.time)}</p>
                      </div>
                    </div>
                    <div className="flex space-x-1">
                      <Button variant="ghost" size="icon" onClick={() => handleEditEvent(event)} className="h-7 w-7">
                        <Edit size={14} className="text-gray-400 hover:text-blue-600" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteEvent(event)} className="h-7 w-7">
                        <Trash2 size={14} className="text-gray-400 hover:text-red-600" />
                      </Button>
                    </div>
                    <span
                      className={`${getEventColor(event.color)} px-2.5 py-0.5 rounded-full text-xs font-semibold flex-shrink-0 ml-2`}
                    >
                      {event.type}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-center text-gray-500 italic">No hay eventos próximos.</p>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <Button variant="ghost" size="icon" onClick={prevMonth}>
                <ChevronLeft />
              </Button>
              <h3 className="text-lg font-semibold text-gray-800 mx-3">
                {getMonthName(currentMonth)} de {currentYear}
              </h3>
              <Button variant="ghost" size="icon" onClick={nextMonth}>
                <ChevronRight />
              </Button>
            </div>
            <Button
              variant="outline"
              className="text-sm font-medium text-orange-600 bg-orange-100 hover:bg-orange-200 border-orange-200"
              onClick={goToToday}
            >
              Hoy
            </Button>
          </div>

          <div className="grid grid-cols-7 border-t border-l border-gray-200">
            {/* Day Headers */}
            {["D", "L", "M", "M", "J", "V", "S"].map((day) => (
              <div
                key={day}
                className="text-center font-semibold p-2 text-xs text-gray-500 border-r border-b border-gray-200 bg-gray-50"
              >
                {day}
              </div>
            ))}

            {/* Day Cells */}
            {generateCalendarDays().map((dayInfo, index) => {
              const dayEvents = getEventsForDay(dayInfo.day, dayInfo.month, dayInfo.year)
              const isTodayFlag = isToday(dayInfo.day, dayInfo.month, dayInfo.year)

              // Apply border classes to each cell for grid lines
              const borderClass = "border-r border-b border-gray-200"

              // Corrected className logic for the day number span
              let dayNumberClasses = `absolute top-1 right-1.5 text-xs `
              if (isTodayFlag) {
                dayNumberClasses += "text-orange-600 font-bold"
              } else if (dayInfo.isCurrentMonth) {
                dayNumberClasses += "text-gray-500"
              } else {
                dayNumberClasses += "text-gray-400"
              }

              return (
                <div
                  key={`day-${index}`}
                  className={`relative p-2 min-h-[100px] ${borderClass} ${
                    !dayInfo.isCurrentMonth ? "bg-gray-50" : "bg-white"
                  } ${isTodayFlag ? "bg-orange-50" : ""} cursor-pointer hover:bg-gray-50`}
                  onClick={() => handleAddEvent(dayInfo)}
                >
                  <span className={dayNumberClasses}>{dayInfo.day}</span>
                  <div className="mt-5 space-y-1">
                    {dayEvents.map((event, idx) => (
                      <div
                        key={idx}
                        className={`p-1 rounded text-xs ${getEventColor(event.color)} overflow-hidden text-ellipsis whitespace-nowrap cursor-pointer hover:opacity-80`}
                        onClick={(e) => {
                          e.stopPropagation()
                          handleEditEvent(event)
                        }}
                      >
                        <div className="flex items-center">
                          <Clock size={10} className="mr-1" />
                          <span>{event.time}</span>
                        </div>
                        {event.title}
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Modal para añadir evento */}
      <Dialog open={isAddEventModalOpen} onOpenChange={setIsAddEventModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Añadir Evento</DialogTitle>
            <DialogDescription>Completa los detalles para crear un nuevo evento</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="event-title">Título del evento</Label>
              <Input
                id="event-title"
                value={newEvent.title}
                onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                placeholder="Ej: Reunión con cliente"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="event-date">Fecha</Label>
                <Input
                  id="event-date"
                  type="date"
                  value={newEvent.date}
                  onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="event-time">Hora</Label>
                <Input
                  id="event-time"
                  type="time"
                  value={newEvent.time}
                  onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="event-type">Tipo de evento</Label>
                <Select value={newEvent.type} onValueChange={(value) => setNewEvent({ ...newEvent, type: value })}>
                  <SelectTrigger id="event-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Reunión">Reunión</SelectItem>
                    <SelectItem value="Audiencia">Audiencia</SelectItem>
                    <SelectItem value="Tarea">Tarea</SelectItem>
                    <SelectItem value="Plazo">Plazo</SelectItem>
                    <SelectItem value="Llamada">Llamada</SelectItem>
                    <SelectItem value="Otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="event-color">Color</Label>
                <Select value={newEvent.color} onValueChange={(value) => setNewEvent({ ...newEvent, color: value })}>
                  <SelectTrigger id="event-color">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="blue">Azul</SelectItem>
                    <SelectItem value="red">Rojo</SelectItem>
                    <SelectItem value="green">Verde</SelectItem>
                    <SelectItem value="yellow">Amarillo</SelectItem>
                    <SelectItem value="purple">Morado</SelectItem>
                    <SelectItem value="indigo">Índigo</SelectItem>
                    <SelectItem value="pink">Rosa</SelectItem>
                    <SelectItem value="gray">Gris</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="event-description">Descripción</Label>
              <Textarea
                id="event-description"
                value={newEvent.description}
                onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                placeholder="Detalles adicionales del evento..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddEventModalOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveEvent} className="bg-orange-500 hover:bg-orange-600">
              Guardar Evento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para editar evento */}
      <Dialog open={isEditEventModalOpen} onOpenChange={setIsEditEventModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Evento</DialogTitle>
            <DialogDescription>Modifica los detalles del evento</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-event-title">Título del evento</Label>
              <Input
                id="edit-event-title"
                value={newEvent.title}
                onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-event-date">Fecha</Label>
                <Input
                  id="edit-event-date"
                  type="date"
                  value={newEvent.date}
                  onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-event-time">Hora</Label>
                <Input
                  id="edit-event-time"
                  type="time"
                  value={newEvent.time}
                  onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-event-type">Tipo de evento</Label>
                <Select value={newEvent.type} onValueChange={(value) => setNewEvent({ ...newEvent, type: value })}>
                  <SelectTrigger id="edit-event-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Reunión">Reunión</SelectItem>
                    <SelectItem value="Audiencia">Audiencia</SelectItem>
                    <SelectItem value="Tarea">Tarea</SelectItem>
                    <SelectItem value="Plazo">Plazo</SelectItem>
                    <SelectItem value="Llamada">Llamada</SelectItem>
                    <SelectItem value="Otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-event-color">Color</Label>
                <Select value={newEvent.color} onValueChange={(value) => setNewEvent({ ...newEvent, color: value })}>
                  <SelectTrigger id="edit-event-color">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="blue">Azul</SelectItem>
                    <SelectItem value="red">Rojo</SelectItem>
                    <SelectItem value="green">Verde</SelectItem>
                    <SelectItem value="yellow">Amarillo</SelectItem>
                    <SelectItem value="purple">Morado</SelectItem>
                    <SelectItem value="indigo">Índigo</SelectItem>
                    <SelectItem value="pink">Rosa</SelectItem>
                    <SelectItem value="gray">Gris</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-event-description">Descripción</Label>
              <Textarea
                id="edit-event-description"
                value={newEvent.description}
                onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditEventModalOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveEvent} className="bg-orange-500 hover:bg-orange-600">
              Guardar Cambios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para confirmar eliminación */}
      <Dialog open={isDeleteEventModalOpen} onOpenChange={setIsDeleteEventModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar eliminación</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar el evento "{currentEvent?.title}"? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteEventModalOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmDeleteEvent}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
