"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { useRouter } from "next/navigation"

// Definir el tipo de contexto
type AuthContextType = {
  user: any | null
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  hasPermission: (module: string, level: "ver" | "editar") => boolean
  isSuperAdmin: () => boolean
}

// Crear el contexto
const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Hook para usar el contexto
export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth debe ser usado dentro de un AuthProvider")
  }
  return context
}

// Proveedor de autenticación
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<any | null>(null)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Verificar autenticación al cargar
  useEffect(() => {
    const checkAuth = () => {
      const storedAuth = localStorage.getItem("isAuthenticated")
      const storedUser = localStorage.getItem("user")

      if (storedAuth === "true" && storedUser) {
        setUser(JSON.parse(storedUser))
        setIsAuthenticated(true)

        // Establecer cookie para el middleware
        document.cookie = `isAuthenticated=true; path=/; max-age=${60 * 60 * 24 * 7}` // 7 días
      } else {
        setUser(null)
        setIsAuthenticated(false)

        // Eliminar cookie
        document.cookie = "isAuthenticated=false; path=/; max-age=0"
      }

      setIsLoading(false)
    }

    checkAuth()
  }, [])

  // Función para verificar si el usuario es super admin
  const isSuperAdmin = (): boolean => {
    return user?.role === "SuperAdmin" || user?.role === "Master"
  }

  // Función para verificar permisos
  const hasPermission = (module: string, level: "ver" | "editar"): boolean => {
    // Si no hay usuario autenticado, no tiene permisos
    if (!user) return false

    // El usuario SuperAdmin o Master tiene todos los permisos
    if (user.role === "SuperAdmin" || user.role === "Master") return true

    // Verificar permisos específicos del usuario
    const permission = user.permisos?.[module]

    if (!permission) return false

    // Si el nivel requerido es "ver", cualquier permiso es suficiente
    if (level === "ver") {
      return permission === "ver" || permission === "editar"
    }

    // Si el nivel requerido es "editar", solo el permiso "editar" es suficiente
    return permission === "editar"
  }

  // Función de login
  const login = async (email: string, password: string): Promise<boolean> => {
    // Verificar usuario master
    const MASTER_USER = {
      email: "admin@legalhub.com",
      password: "master123",
      role: "SuperAdmin",
      name: "Administrador Master",
    }

    if (email === MASTER_USER.email && password === MASTER_USER.password) {
      const userData = {
        email: MASTER_USER.email,
        name: MASTER_USER.name,
        role: MASTER_USER.role,
        permisos: {}, // El SuperAdmin tiene todos los permisos implícitamente
      }

      // Guardar en localStorage
      localStorage.setItem("isAuthenticated", "true")
      localStorage.setItem("user", JSON.stringify(userData))

      // Establecer cookie para el middleware
      document.cookie = `isAuthenticated=true; path=/; max-age=${60 * 60 * 24 * 7}` // 7 días

      // Actualizar estado
      setUser(userData)
      setIsAuthenticated(true)

      return true
    }

    // Verificar otros usuarios
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const user = users.find((u: any) => u.email === email && u.password === password)

    if (user) {
      // Verificar si el usuario está activo
      if (!user.estado) {
        return false
      }

      const userData = {
        id: user.id,
        email: user.email,
        name: user.nombre,
        role: user.rol,
        empresa: user.empresa,
        permisos: user.permisos || {},
      }

      // Actualizar último acceso
      const updatedUsers = users.map((u: any) => {
        if (u.email === email) {
          return {
            ...u,
            ultimoAcceso: new Date().toISOString(),
          }
        }
        return u
      })
      localStorage.setItem("users", JSON.stringify(updatedUsers))

      // Guardar en localStorage
      localStorage.setItem("isAuthenticated", "true")
      localStorage.setItem("user", JSON.stringify(userData))

      // Establecer cookie para el middleware
      document.cookie = `isAuthenticated=true; path=/; max-age=${60 * 60 * 24 * 7}` // 7 días

      // Actualizar estado
      setUser(userData)
      setIsAuthenticated(true)

      return true
    }

    return false
  }

  // Función de logout
  const logout = () => {
    // Limpiar localStorage
    localStorage.removeItem("isAuthenticated")
    localStorage.removeItem("user")

    // Eliminar cookie
    document.cookie = "isAuthenticated=false; path=/; max-age=0"

    // Actualizar estado
    setUser(null)
    setIsAuthenticated(false)

    // Redirigir al login
    router.push("/login")
  }

  // Valor del contexto
  const value = {
    user,
    isAuthenticated,
    login,
    logout,
    hasPermission,
    isSuperAdmin,
  }

  // Si está cargando, mostrar nada
  if (isLoading) {
    return null
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
