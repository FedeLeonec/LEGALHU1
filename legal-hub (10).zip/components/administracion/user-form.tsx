"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"

export function UserForm({ isOpen, onClose, onUserAdded }) {
  const [formData, setFormData] = useState({
    nombre: "",
    email: "",
    password: "",
    rol: "Abogado",
  })
  const { toast } = useToast()

  const handleChange = (e) => {
    const { id, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [id]: value,
    }))
  }

  const handleRoleChange = (value) => {
    setFormData((prev) => ({
      ...prev,
      rol: value,
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    // Validar datos
    if (!formData.nombre || !formData.email || !formData.password || !formData.rol) {
      toast({
        title: "Error",
        description: "Todos los campos son obligatorios",
        variant: "destructive",
      })
      return
    }

    // Obtener usuarios existentes
    const existingUsers = JSON.parse(localStorage.getItem("users") || "[]")

    // Verificar si el email ya existe
    if (existingUsers.some((user) => user.email === formData.email)) {
      toast({
        title: "Error",
        description: "Ya existe un usuario con ese correo electrónico",
        variant: "destructive",
      })
      return
    }

    // Obtener permisos para el rol seleccionado
    const rolePermissions = JSON.parse(localStorage.getItem("rolePermissions") || "{}")
    const userPermissions = rolePermissions[formData.rol] || {}

    // Crear nuevo usuario
    const newUser = {
      id: Date.now(),
      nombre: formData.nombre,
      email: formData.email,
      password: formData.password,
      rol: formData.rol,
      estado: true,
      ultimoAcceso: new Date().toISOString(),
      permisos: userPermissions,
    }

    // Guardar usuario
    const updatedUsers = [...existingUsers, newUser]
    localStorage.setItem("users", JSON.stringify(updatedUsers))

    // Notificar éxito
    toast({
      title: "Usuario creado",
      description: "El usuario ha sido creado exitosamente",
    })

    // Limpiar formulario
    setFormData({
      nombre: "",
      email: "",
      password: "",
      rol: "Abogado",
    })

    // Cerrar modal y notificar al componente padre
    onUserAdded(newUser)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Añadir Nuevo Usuario</DialogTitle>
          <DialogDescription>Complete los detalles para crear un nuevo usuario</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="nombre">Nombre completo</Label>
              <Input id="nombre" value={formData.nombre} onChange={handleChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={formData.email} onChange={handleChange} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="rol">Rol</Label>
              <Select value={formData.rol} onValueChange={handleRoleChange}>
                <SelectTrigger id="rol">
                  <SelectValue placeholder="Seleccionar rol" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Administrador">Administrador</SelectItem>
                  <SelectItem value="Socio">Socio</SelectItem>
                  <SelectItem value="Abogado">Abogado</SelectItem>
                  <SelectItem value="Contador">Contador</SelectItem>
                  <SelectItem value="Pasante">Pasante</SelectItem>
                  <SelectItem value="Cliente">Cliente</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Contraseña</Label>
              <Input id="password" type="password" value={formData.password} onChange={handleChange} required />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
              Guardar Usuario
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
