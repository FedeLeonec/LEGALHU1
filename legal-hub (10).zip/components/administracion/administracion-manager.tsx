"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Search, UserPlus, ShieldAlert, Edit, Power, Trash2, Save, Building } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"
import { Checkbox } from "@/components/ui/checkbox"
import { useAuth } from "@/components/auth/auth-provider"

// Definir la estructura de un usuario
interface User {
  id: number
  nombre: string
  email: string
  password?: string
  rol: string
  estado: boolean
  empresa: string
  ultimoAcceso: string
  permisos?: Record<string, string>
}

// Definir la estructura de una empresa
interface Empresa {
  id: number
  nombre: string
  direccion: string
  telefono: string
  email: string
  estado: boolean
  fechaCreacion: string
}

// Definir la estructura de los permisos de roles
interface RolePermissions {
  [role: string]: {
    [module: string]: string
  }
}

export function AdministracionManager() {
  const { user, isSuperAdmin } = useAuth()
  const [activeTab, setActiveTab] = useState("usuarios")
  const [users, setUsers] = useState<User[]>([])
  const [empresas, setEmpresas] = useState<Empresa[]>([])
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false)
  const [isAddEmpresaModalOpen, setIsAddEmpresaModalOpen] = useState(false)
  const [isManageRolesModalOpen, setIsManageRolesModalOpen] = useState(false)
  const [isEditUserModalOpen, setIsEditUserModalOpen] = useState(false)
  const [isEditEmpresaModalOpen, setIsEditEmpresaModalOpen] = useState(false)
  const [currentEditUser, setCurrentEditUser] = useState<User | null>(null)
  const [currentEditEmpresa, setCurrentEditEmpresa] = useState<Empresa | null>(null)
  const [filterRol, setFilterRol] = useState("Todos")
  const [filterEstado, setFilterEstado] = useState("Todos")
  const [filterEmpresa, setFilterEmpresa] = useState("Todas")
  const [searchQuery, setSearchQuery] = useState("")
  const [searchEmpresaQuery, setSearchEmpresaQuery] = useState("")
  const { toast } = useToast()

  // Nuevo usuario
  const [newUser, setNewUser] = useState<Omit<User, "id" | "ultimoAcceso" | "permisos">>({
    nombre: "",
    email: "",
    password: "",
    rol: "Administrador",
    estado: true,
    empresa: "",
  })

  // Nueva empresa
  const [newEmpresa, setNewEmpresa] = useState<Omit<Empresa, "id" | "fechaCreacion">>({
    nombre: "",
    direccion: "",
    telefono: "",
    email: "",
    estado: true,
  })

  // Estado para los permisos de roles
  const [rolePermissions, setRolePermissions] = useState<RolePermissions>({
    Administrador: {},
    Socio: {},
    Abogado: {},
    Contador: {},
    Pasante: {},
    Cliente: {},
  })

  // Lista de módulos del sistema
  const systemModules = [
    "Dashboard",
    "Asistente Legal",
    "Documentos",
    "Correos",
    "Calendario",
    "Tareas",
    "Casos",
    "Clientes",
    "Contactos",
    "Contabilidad",
    "Notificaciones",
    "Ajustes",
    "Administración",
  ]

  // Cargar usuarios, empresas y permisos desde localStorage al iniciar
  useEffect(() => {
    // Cargar empresas
    const storedEmpresas = JSON.parse(localStorage.getItem("empresas") || "[]")
    if (storedEmpresas.length > 0) {
      setEmpresas(storedEmpresas)
    } else {
      // Crear empresa por defecto si no hay ninguna
      const defaultEmpresa = {
        id: 1,
        nombre: "Legal Hub",
        direccion: "Av. Principal 123",
        telefono: "123-456-7890",
        email: "info@legalhub.com",
        estado: true,
        fechaCreacion: new Date().toISOString(),
      }
      setEmpresas([defaultEmpresa])
      localStorage.setItem("empresas", JSON.stringify([defaultEmpresa]))
    }

    // Cargar usuarios
    const storedUsers = JSON.parse(localStorage.getItem("users") || "[]")
    setUsers(storedUsers)

    // Cargar permisos de roles
    const storedPermissions = JSON.parse(localStorage.getItem("rolePermissions") || "{}")

    // Inicializar permisos por defecto si no existen
    if (Object.keys(storedPermissions).length > 0) {
      setRolePermissions(storedPermissions)
    } else {
      // Inicializar permisos por defecto si no existen
      const defaultPermissions: RolePermissions = {
        Administrador: {},
        Socio: {},
        Abogado: {},
        Contador: {},
        Pasante: {},
        Cliente: {},
      }

      // Establecer permisos predeterminados
      systemModules.forEach((module) => {
        defaultPermissions.Administrador[module] = "editar"
        defaultPermissions.Socio[module] = "editar"
        defaultPermissions.Abogado[module] = "ver"
        defaultPermissions.Contador[module] = "ver"
        defaultPermissions.Pasante[module] = "ver"
        defaultPermissions.Cliente[module] = "ver"
      })

      // Restricciones específicas
      defaultPermissions.Abogado["Administración"] = "no"
      defaultPermissions.Contador["Administración"] = "no"
      defaultPermissions.Pasante["Administración"] = "no"
      defaultPermissions.Cliente["Administración"] = "no"
      defaultPermissions.Cliente["Contabilidad"] = "no"

      setRolePermissions(defaultPermissions)
      localStorage.setItem("rolePermissions", JSON.stringify(defaultPermissions))
    }
  }, [])

  // Guardar usuarios en localStorage cuando cambien
  useEffect(() => {
    if (users.length > 0) {
      localStorage.setItem("users", JSON.stringify(users))
    }
  }, [users])

  // Guardar empresas en localStorage cuando cambien
  useEffect(() => {
    if (empresas.length > 0) {
      localStorage.setItem("empresas", JSON.stringify(empresas))
    }
  }, [empresas])

  // Verificar si el usuario actual es SuperAdmin
  const isUserSuperAdmin = isSuperAdmin()

  // Funciones para gestionar usuarios
  const toggleUserStatus = (userId: number) => {
    setUsers((currentUsers) =>
      currentUsers.map((user) => (user.id === userId ? { ...user, estado: !user.estado } : user)),
    )
  }

  const deleteUser = (userId: number, userName: string) => {
    if (window.confirm(`¿Está seguro que desea eliminar al usuario "${userName}"? Esta acción no se puede deshacer.`)) {
      setUsers((currentUsers) => currentUsers.filter((user) => user.id !== userId))
      toast({
        title: "Usuario eliminado",
        description: `El usuario ${userName} ha sido eliminado`,
      })
    }
  }

  const handleAddUser = () => {
    setNewUser({
      nombre: "",
      email: "",
      password: "",
      rol: "Administrador",
      estado: true,
      empresa: empresas.length > 0 ? empresas[0].nombre : "",
    })
    setIsAddUserModalOpen(true)
  }

  const handleUserSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validar datos
    if (!newUser.nombre || !newUser.email || !newUser.password || !newUser.rol || !newUser.empresa) {
      toast({
        title: "Error",
        description: "Todos los campos son obligatorios",
        variant: "destructive",
      })
      return
    }

    // Verificar si el email ya existe
    if (users.some((user) => user.email === newUser.email)) {
      toast({
        title: "Error",
        description: "Ya existe un usuario con ese correo electrónico",
        variant: "destructive",
      })
      return
    }

    // Obtener permisos para el rol seleccionado
    const userPermissions = rolePermissions[newUser.rol] || {}

    // Crear nuevo usuario
    const userToAdd = {
      id: Date.now(),
      nombre: newUser.nombre,
      email: newUser.email,
      password: newUser.password,
      rol: newUser.rol,
      empresa: newUser.empresa,
      estado: newUser.estado,
      ultimoAcceso: "Nunca",
      permisos: userPermissions,
    }

    setUsers((prev) => [...prev, userToAdd])
    setIsAddUserModalOpen(false)

    toast({
      title: "Usuario creado",
      description: `El usuario ${newUser.nombre} ha sido creado con éxito`,
    })
  }

  const handleEditUser = (userId: number) => {
    const userToEdit = users.find((user) => user.id === userId)
    if (userToEdit) {
      setCurrentEditUser(userToEdit)
      setIsEditUserModalOpen(true)
    }
  }

  const handleUpdateUser = (e: React.FormEvent) => {
    e.preventDefault()
    if (!currentEditUser) return

    // Validar datos
    if (!currentEditUser.nombre || !currentEditUser.email || !currentEditUser.rol || !currentEditUser.empresa) {
      toast({
        title: "Error",
        description: "Nombre, email, rol y empresa son obligatorios",
        variant: "destructive",
      })
      return
    }

    // Verificar si el email ya existe en otro usuario
    const emailExists = users.some((user) => user.email === currentEditUser.email && user.id !== currentEditUser.id)
    if (emailExists) {
      toast({
        title: "Error",
        description: "Ya existe otro usuario con ese correo electrónico",
        variant: "destructive",
      })
      return
    }

    // Obtener permisos para el rol seleccionado
    const userPermissions = rolePermissions[currentEditUser.rol] || {}

    // Actualizar usuario
    const updatedUser = {
      ...currentEditUser,
      permisos: userPermissions,
    }

    setUsers((currentUsers) => currentUsers.map((user) => (user.id === updatedUser.id ? updatedUser : user)))

    setIsEditUserModalOpen(false)
    setCurrentEditUser(null)

    toast({
      title: "Usuario actualizado",
      description: `El usuario ${updatedUser.nombre} ha sido actualizado con éxito`,
    })
  }

  // Funciones para gestionar empresas
  const toggleEmpresaStatus = (empresaId: number) => {
    setEmpresas((currentEmpresas) =>
      currentEmpresas.map((empresa) => (empresa.id === empresaId ? { ...empresa, estado: !empresa.estado } : empresa)),
    )
  }

  const deleteEmpresa = (empresaId: number, empresaNombre: string) => {
    // Verificar si hay usuarios asociados a esta empresa
    const hasUsers = users.some((user) => user.empresa === empresaNombre)
    if (hasUsers) {
      toast({
        title: "No se puede eliminar",
        description: "Existen usuarios asociados a esta empresa. Elimine los usuarios primero.",
        variant: "destructive",
      })
      return
    }

    if (
      window.confirm(`¿Está seguro que desea eliminar la empresa "${empresaNombre}"? Esta acción no se puede deshacer.`)
    ) {
      setEmpresas((currentEmpresas) => currentEmpresas.filter((empresa) => empresa.id !== empresaId))
      toast({
        title: "Empresa eliminada",
        description: `La empresa ${empresaNombre} ha sido eliminada`,
      })
    }
  }

  const handleAddEmpresa = () => {
    setNewEmpresa({
      nombre: "",
      direccion: "",
      telefono: "",
      email: "",
      estado: true,
    })
    setIsAddEmpresaModalOpen(true)
  }

  const handleEmpresaSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validar datos
    if (!newEmpresa.nombre || !newEmpresa.direccion || !newEmpresa.telefono || !newEmpresa.email) {
      toast({
        title: "Error",
        description: "Todos los campos son obligatorios",
        variant: "destructive",
      })
      return
    }

    // Verificar si el nombre ya existe
    if (empresas.some((empresa) => empresa.nombre === newEmpresa.nombre)) {
      toast({
        title: "Error",
        description: "Ya existe una empresa con ese nombre",
        variant: "destructive",
      })
      return
    }

    // Crear nueva empresa
    const empresaToAdd = {
      id: Date.now(),
      nombre: newEmpresa.nombre,
      direccion: newEmpresa.direccion,
      telefono: newEmpresa.telefono,
      email: newEmpresa.email,
      estado: newEmpresa.estado,
      fechaCreacion: new Date().toISOString(),
    }

    setEmpresas((prev) => [...prev, empresaToAdd])
    setIsAddEmpresaModalOpen(false)

    toast({
      title: "Empresa creada",
      description: `La empresa ${newEmpresa.nombre} ha sido creada con éxito`,
    })
  }

  const handleEditEmpresa = (empresaId: number) => {
    const empresaToEdit = empresas.find((empresa) => empresa.id === empresaId)
    if (empresaToEdit) {
      setCurrentEditEmpresa(empresaToEdit)
      setIsEditEmpresaModalOpen(true)
    }
  }

  const handleUpdateEmpresa = (e: React.FormEvent) => {
    e.preventDefault()
    if (!currentEditEmpresa) return

    // Validar datos
    if (
      !currentEditEmpresa.nombre ||
      !currentEditEmpresa.direccion ||
      !currentEditEmpresa.telefono ||
      !currentEditEmpresa.email
    ) {
      toast({
        title: "Error",
        description: "Todos los campos son obligatorios",
        variant: "destructive",
      })
      return
    }

    // Verificar si el nombre ya existe en otra empresa
    const nombreExists = empresas.some(
      (empresa) => empresa.nombre === currentEditEmpresa.nombre && empresa.id !== currentEditEmpresa.id,
    )
    if (nombreExists) {
      toast({
        title: "Error",
        description: "Ya existe otra empresa con ese nombre",
        variant: "destructive",
      })
      return
    }

    // Actualizar empresa
    setEmpresas((currentEmpresas) =>
      currentEmpresas.map((empresa) => (empresa.id === currentEditEmpresa.id ? currentEditEmpresa : empresa)),
    )

    // Si se cambió el nombre de la empresa, actualizar los usuarios asociados
    const oldName = empresas.find((empresa) => empresa.id === currentEditEmpresa.id)?.nombre
    if (oldName && oldName !== currentEditEmpresa.nombre) {
      setUsers((currentUsers) =>
        currentUsers.map((user) => (user.empresa === oldName ? { ...user, empresa: currentEditEmpresa.nombre } : user)),
      )
    }

    setIsEditEmpresaModalOpen(false)
    setCurrentEditEmpresa(null)

    toast({
      title: "Empresa actualizada",
      description: `La empresa ${currentEditEmpresa.nombre} ha sido actualizada con éxito`,
    })
  }

  const handleManageRoles = () => {
    setIsManageRolesModalOpen(true)
  }

  const handlePermissionChange = (role: string, module: string, permission: string) => {
    setRolePermissions((prev) => ({
      ...prev,
      [role]: {
        ...prev[role],
        [module]: permission,
      },
    }))
  }

  const saveRolePermissions = () => {
    localStorage.setItem("rolePermissions", JSON.stringify(rolePermissions))

    // Actualizar permisos para usuarios existentes
    const updatedUsers = users.map((user) => {
      return {
        ...user,
        permisos: rolePermissions[user.rol] || {},
      }
    })

    setUsers(updatedUsers)
    localStorage.setItem("users", JSON.stringify(updatedUsers))

    setIsManageRolesModalOpen(false)

    toast({
      title: "Permisos guardados",
      description: "La configuración de roles y permisos ha sido guardada con éxito",
    })
  }

  const getRoleClass = (role: string) => {
    switch (role?.toLowerCase()) {
      case "superadmin":
      case "master":
        return "bg-red-100 text-red-700 border-red-300"
      case "administrador":
        return "bg-blue-100 text-blue-700 border-blue-300"
      case "socio":
        return "bg-purple-100 text-purple-700 border-purple-300"
      case "abogado":
        return "bg-indigo-100 text-indigo-700 border-indigo-300"
      case "contador":
        return "bg-pink-100 text-pink-700 border-pink-300"
      case "pasante":
        return "bg-teal-100 text-teal-700 border-teal-300"
      case "cliente":
        return "bg-green-100 text-green-700 border-green-300"
      default:
        return "bg-gray-100 text-gray-700 border-gray-300"
    }
  }

  // Filtrar usuarios según los criterios seleccionados
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesRole = filterRol === "Todos" || user.rol === filterRol

    const matchesStatus =
      filterEstado === "Todos" ||
      (filterEstado === "Activo" && user.estado) ||
      (filterEstado === "Inactivo" && !user.estado)

    const matchesEmpresa = filterEmpresa === "Todas" || user.empresa === filterEmpresa

    return matchesSearch && matchesRole && matchesStatus && matchesEmpresa
  })

  // Filtrar empresas según la búsqueda
  const filteredEmpresas = empresas.filter((empresa) =>
    empresa.nombre.toLowerCase().includes(searchEmpresaQuery.toLowerCase()),
  )

  return (
    <Card>
      <CardContent className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex justify-between items-center mb-6">
            <TabsList>
              <TabsTrigger value="usuarios">Usuarios</TabsTrigger>
              {isUserSuperAdmin && <TabsTrigger value="empresas">Empresas</TabsTrigger>}
              <TabsTrigger value="roles">Roles y Permisos</TabsTrigger>
            </TabsList>
            <div className="flex space-x-3">
              {activeTab === "usuarios" && (
                <Button onClick={handleAddUser} className="bg-orange-500 hover:bg-orange-600">
                  <UserPlus size={16} className="mr-2" />
                  Añadir Usuario
                </Button>
              )}
              {activeTab === "empresas" && isUserSuperAdmin && (
                <Button onClick={handleAddEmpresa} className="bg-orange-500 hover:bg-orange-600">
                  <Building size={16} className="mr-2" />
                  Añadir Empresa
                </Button>
              )}
              {activeTab === "roles" && (
                <Button onClick={handleManageRoles} className="bg-indigo-500 hover:bg-indigo-600">
                  <ShieldAlert size={16} className="mr-2" />
                  Gestionar Roles
                </Button>
              )}
            </div>
          </div>

          <TabsContent value="usuarios" className="mt-0">
            <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
              <div className="flex items-center border border-gray-300 rounded-md overflow-hidden focus-within:ring-1 focus-within:ring-orange-500 focus-within:border-orange-500 w-full sm:w-1/3">
                <span className="pl-3 pr-1 text-gray-400">
                  <Search size={18} />
                </span>
                <Input
                  type="text"
                  placeholder="Buscar por nombre o email..."
                  className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center text-sm">
                  <label htmlFor="filter-admin-rol" className="mr-2 text-gray-600">
                    Rol:
                  </label>
                  <Select value={filterRol} onValueChange={setFilterRol}>
                    <SelectTrigger id="filter-admin-rol" className="w-[150px]">
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Todos">Todos</SelectItem>
                      {isUserSuperAdmin && <SelectItem value="Administrador">Administrador</SelectItem>}
                      <SelectItem value="Socio">Socio</SelectItem>
                      <SelectItem value="Abogado">Abogado</SelectItem>
                      <SelectItem value="Contador">Contador</SelectItem>
                      <SelectItem value="Pasante">Pasante</SelectItem>
                      <SelectItem value="Cliente">Cliente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center text-sm">
                  <label htmlFor="filter-admin-estado" className="mr-2 text-gray-600">
                    Estado:
                  </label>
                  <Select value={filterEstado} onValueChange={setFilterEstado}>
                    <SelectTrigger id="filter-admin-estado" className="w-[120px]">
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Todos">Todos</SelectItem>
                      <SelectItem value="Activo">Activo</SelectItem>
                      <SelectItem value="Inactivo">Inactivo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {isUserSuperAdmin && (
                  <div className="flex items-center text-sm">
                    <label htmlFor="filter-admin-empresa" className="mr-2 text-gray-600">
                      Empresa:
                    </label>
                    <Select value={filterEmpresa} onValueChange={setFilterEmpresa}>
                      <SelectTrigger id="filter-admin-empresa" className="w-[150px]">
                        <SelectValue placeholder="Todas" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Todas">Todas</SelectItem>
                        {empresas.map((empresa) => (
                          <SelectItem key={empresa.id} value={empresa.nombre}>
                            {empresa.nombre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </div>

            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nombre</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Rol</TableHead>
                    {isUserSuperAdmin && <TableHead>Empresa</TableHead>}
                    <TableHead>Estado</TableHead>
                    <TableHead>Último Acceso</TableHead>
                    <TableHead className="text-center">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.length > 0 ? (
                    filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium text-gray-900 whitespace-nowrap">{user.nombre}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <span
                            className={`px-2.5 py-1 rounded-full text-xs font-medium border ${getRoleClass(user.rol)}`}
                          >
                            {user.rol}
                          </span>
                        </TableCell>
                        {isUserSuperAdmin && <TableCell>{user.empresa}</TableCell>}
                        <TableCell>
                          <span
                            className={`px-2.5 py-1 rounded-full text-xs font-medium border ${
                              user.estado
                                ? "bg-green-100 text-green-800 border-green-300"
                                : "bg-gray-100 text-gray-800 border-gray-300"
                            }`}
                          >
                            {user.estado ? "Activo" : "Inactivo"}
                          </span>
                        </TableCell>
                        <TableCell className="text-gray-500 whitespace-nowrap">
                          {user.ultimoAcceso || "Nunca"}
                        </TableCell>
                        <TableCell className="text-center space-x-2 whitespace-nowrap">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEditUser(user.id)}
                            title="Editar Usuario"
                          >
                            <Edit size={16} className="text-gray-400 hover:text-blue-600" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => toggleUserStatus(user.id)}
                            title={user.estado ? "Desactivar Usuario" : "Activar Usuario"}
                          >
                            <Power
                              size={16}
                              className={`text-gray-400 ${
                                user.estado ? "hover:text-yellow-600" : "hover:text-green-600"
                              }`}
                            />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteUser(user.id, user.nombre)}
                            title="Eliminar Usuario"
                          >
                            <Trash2 size={16} className="text-gray-400 hover:text-red-600" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={isUserSuperAdmin ? 7 : 6} className="text-center py-4 text-gray-500">
                        No se encontraron usuarios con los filtros seleccionados.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="empresas" className="mt-0">
            {isUserSuperAdmin && (
              <>
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center border border-gray-300 rounded-md overflow-hidden focus-within:ring-1 focus-within:ring-orange-500 focus-within:border-orange-500 w-full sm:w-1/3">
                    <span className="pl-3 pr-1 text-gray-400">
                      <Search size={18} />
                    </span>
                    <Input
                      type="text"
                      placeholder="Buscar por nombre..."
                      className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
                      value={searchEmpresaQuery}
                      onChange={(e) => setSearchEmpresaQuery(e.target.value)}
                    />
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nombre</TableHead>
                        <TableHead>Dirección</TableHead>
                        <TableHead>Teléfono</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Estado</TableHead>
                        <TableHead>Fecha Creación</TableHead>
                        <TableHead className="text-center">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredEmpresas.length > 0 ? (
                        filteredEmpresas.map((empresa) => (
                          <TableRow key={empresa.id}>
                            <TableCell className="font-medium text-gray-900">{empresa.nombre}</TableCell>
                            <TableCell>{empresa.direccion}</TableCell>
                            <TableCell>{empresa.telefono}</TableCell>
                            <TableCell>{empresa.email}</TableCell>
                            <TableCell>
                              <span
                                className={`px-2.5 py-1 rounded-full text-xs font-medium border ${
                                  empresa.estado
                                    ? "bg-green-100 text-green-800 border-green-300"
                                    : "bg-gray-100 text-gray-800 border-gray-300"
                                }`}
                              >
                                {empresa.estado ? "Activa" : "Inactiva"}
                              </span>
                            </TableCell>
                            <TableCell>
                              {new Date(empresa.fechaCreacion).toLocaleDateString("es-ES", {
                                year: "numeric",
                                month: "short",
                                day: "numeric",
                              })}
                            </TableCell>
                            <TableCell className="text-center space-x-2 whitespace-nowrap">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEditEmpresa(empresa.id)}
                                title="Editar Empresa"
                              >
                                <Edit size={16} className="text-gray-400 hover:text-blue-600" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => toggleEmpresaStatus(empresa.id)}
                                title={empresa.estado ? "Desactivar Empresa" : "Activar Empresa"}
                              >
                                <Power
                                  size={16}
                                  className={`text-gray-400 ${
                                    empresa.estado ? "hover:text-yellow-600" : "hover:text-green-600"
                                  }`}
                                />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => deleteEmpresa(empresa.id, empresa.nombre)}
                                title="Eliminar Empresa"
                              >
                                <Trash2 size={16} className="text-gray-400 hover:text-red-600" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-4 text-gray-500">
                            No se encontraron empresas.
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </>
            )}
          </TabsContent>

          <TabsContent value="roles" className="mt-0">
            <div className="py-4 overflow-x-auto">
              <Table className="border-collapse">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-1/6">Módulo</TableHead>
                    <TableHead className="w-1/6">Administrador</TableHead>
                    <TableHead className="w-1/6">Socio</TableHead>
                    <TableHead className="w-1/6">Abogado</TableHead>
                    <TableHead className="w-1/6">Contador</TableHead>
                    <TableHead className="w-1/6">Pasante</TableHead>
                    <TableHead className="w-1/6">Cliente</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {systemModules.map((module) => (
                    <TableRow key={module}>
                      <TableCell className="font-medium">{module}</TableCell>
                      {["Administrador", "Socio", "Abogado", "Contador", "Pasante", "Cliente"].map((role) => (
                        <TableCell key={`${module}-${role}`}>
                          <Select
                            defaultValue={rolePermissions[role]?.[module] || "no"}
                            value={rolePermissions[role]?.[module] || "no"}
                            onValueChange={(value) => handlePermissionChange(role, module, value)}
                          >
                            <SelectTrigger className="w-[100px]">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="editar">Editar</SelectItem>
                              <SelectItem value="ver">Ver</SelectItem>
                              <SelectItem value="no">No</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="flex justify-end mt-6">
                <Button className="bg-orange-500 hover:bg-orange-600" onClick={saveRolePermissions}>
                  <Save className="mr-2 h-4 w-4" />
                  Guardar Configuración
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>

      {/* Modal para añadir usuario */}
      <Dialog open={isAddUserModalOpen} onOpenChange={setIsAddUserModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Añadir Nuevo Usuario</DialogTitle>
            <DialogDescription>Complete los detalles para crear un nuevo usuario</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUserSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label htmlFor="nombre" className="text-sm font-medium">
                  Nombre completo
                </label>
                <Input
                  id="nombre"
                  value={newUser.nombre}
                  onChange={(e) => setNewUser({ ...newUser, nombre: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="password" className="text-sm font-medium">
                  Contraseña
                </label>
                <Input
                  id="password"
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="rol" className="text-sm font-medium">
                  Rol
                </label>
                <Select value={newUser.rol} onValueChange={(value) => setNewUser({ ...newUser, rol: value })}>
                  <SelectTrigger id="rol">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {isUserSuperAdmin && <SelectItem value="Administrador">Administrador</SelectItem>}
                    <SelectItem value="Socio">Socio</SelectItem>
                    <SelectItem value="Abogado">Abogado</SelectItem>
                    <SelectItem value="Contador">Contador</SelectItem>
                    <SelectItem value="Pasante">Pasante</SelectItem>
                    <SelectItem value="Cliente">Cliente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label htmlFor="empresa" className="text-sm font-medium">
                  Empresa
                </label>
                <Select value={newUser.empresa} onValueChange={(value) => setNewUser({ ...newUser, empresa: value })}>
                  <SelectTrigger id="empresa">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {empresas.map((empresa) => (
                      <SelectItem key={empresa.id} value={empresa.nombre}>
                        {empresa.nombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="estado"
                    checked={newUser.estado}
                    onCheckedChange={(checked) => setNewUser({ ...newUser, estado: checked as boolean })}
                  />
                  <label htmlFor="estado" className="text-sm">
                    Usuario activo
                  </label>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddUserModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
                Guardar Usuario
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Modal para editar usuario */}
      <Dialog open={isEditUserModalOpen} onOpenChange={setIsEditUserModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Usuario</DialogTitle>
            <DialogDescription>Modifique los datos del usuario</DialogDescription>
          </DialogHeader>
          {currentEditUser && (
            <form onSubmit={handleUpdateUser}>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <label htmlFor="edit-nombre" className="text-sm font-medium">
                    Nombre completo
                  </label>
                  <Input
                    id="edit-nombre"
                    value={currentEditUser.nombre}
                    onChange={(e) => setCurrentEditUser({ ...currentEditUser, nombre: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="edit-email" className="text-sm font-medium">
                    Email
                  </label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={currentEditUser.email}
                    onChange={(e) => setCurrentEditUser({ ...currentEditUser, email: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="edit-rol" className="text-sm font-medium">
                    Rol
                  </label>
                  <Select
                    value={currentEditUser.rol}
                    onValueChange={(value) => setCurrentEditUser({ ...currentEditUser, rol: value })}
                  >
                    <SelectTrigger id="edit-rol">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {isUserSuperAdmin && <SelectItem value="Administrador">Administrador</SelectItem>}
                      <SelectItem value="Socio">Socio</SelectItem>
                      <SelectItem value="Abogado">Abogado</SelectItem>
                      <SelectItem value="Contador">Contador</SelectItem>
                      <SelectItem value="Pasante">Pasante</SelectItem>
                      <SelectItem value="Cliente">Cliente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label htmlFor="edit-empresa" className="text-sm font-medium">
                    Empresa
                  </label>
                  <Select
                    value={currentEditUser.empresa}
                    onValueChange={(value) => setCurrentEditUser({ ...currentEditUser, empresa: value })}
                  >
                    <SelectTrigger id="edit-empresa">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {empresas.map((empresa) => (
                        <SelectItem key={empresa.id} value={empresa.nombre}>
                          {empresa.nombre}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="edit-estado"
                      checked={currentEditUser.estado}
                      onCheckedChange={(checked) =>
                        setCurrentEditUser({ ...currentEditUser, estado: checked as boolean })
                      }
                    />
                    <label htmlFor="edit-estado" className="text-sm">
                      Usuario activo
                    </label>
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="edit-password" className="text-sm font-medium">
                    Nueva contraseña (dejar en blanco para mantener la actual)
                  </label>
                  <Input
                    id="edit-password"
                    type="password"
                    placeholder="Nueva contraseña"
                    value={currentEditUser.password || ""}
                    onChange={(e) => setCurrentEditUser({ ...currentEditUser, password: e.target.value })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsEditUserModalOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
                  Guardar Cambios
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Modal para añadir empresa */}
      <Dialog open={isAddEmpresaModalOpen} onOpenChange={setIsAddEmpresaModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Añadir Nueva Empresa</DialogTitle>
            <DialogDescription>Complete los detalles para crear una nueva empresa</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEmpresaSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label htmlFor="nombre-empresa" className="text-sm font-medium">
                  Nombre de la empresa
                </label>
                <Input
                  id="nombre-empresa"
                  value={newEmpresa.nombre}
                  onChange={(e) => setNewEmpresa({ ...newEmpresa, nombre: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="direccion" className="text-sm font-medium">
                  Dirección
                </label>
                <Input
                  id="direccion"
                  value={newEmpresa.direccion}
                  onChange={(e) => setNewEmpresa({ ...newEmpresa, direccion: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="telefono" className="text-sm font-medium">
                  Teléfono
                </label>
                <Input
                  id="telefono"
                  value={newEmpresa.telefono}
                  onChange={(e) => setNewEmpresa({ ...newEmpresa, telefono: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="email-empresa" className="text-sm font-medium">
                  Email
                </label>
                <Input
                  id="email-empresa"
                  type="email"
                  value={newEmpresa.email}
                  onChange={(e) => setNewEmpresa({ ...newEmpresa, email: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="estado-empresa"
                    checked={newEmpresa.estado}
                    onCheckedChange={(checked) => setNewEmpresa({ ...newEmpresa, estado: checked as boolean })}
                  />
                  <label htmlFor="estado-empresa" className="text-sm">
                    Empresa activa
                  </label>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddEmpresaModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
                Guardar Empresa
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Modal para editar empresa */}
      <Dialog open={isEditEmpresaModalOpen} onOpenChange={setIsEditEmpresaModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Empresa</DialogTitle>
            <DialogDescription>Modifique los datos de la empresa</DialogDescription>
          </DialogHeader>
          {currentEditEmpresa && (
            <form onSubmit={handleUpdateEmpresa}>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <label htmlFor="edit-nombre-empresa" className="text-sm font-medium">
                    Nombre de la empresa
                  </label>
                  <Input
                    id="edit-nombre-empresa"
                    value={currentEditEmpresa.nombre}
                    onChange={(e) => setCurrentEditEmpresa({ ...currentEditEmpresa, nombre: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="edit-direccion" className="text-sm font-medium">
                    Dirección
                  </label>
                  <Input
                    id="edit-direccion"
                    value={currentEditEmpresa.direccion}
                    onChange={(e) => setCurrentEditEmpresa({ ...currentEditEmpresa, direccion: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="edit-telefono" className="text-sm font-medium">
                    Teléfono
                  </label>
                  <Input
                    id="edit-telefono"
                    value={currentEditEmpresa.telefono}
                    onChange={(e) => setCurrentEditEmpresa({ ...currentEditEmpresa, telefono: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="edit-email-empresa" className="text-sm font-medium">
                    Email
                  </label>
                  <Input
                    id="edit-email-empresa"
                    type="email"
                    value={currentEditEmpresa.email}
                    onChange={(e) => setCurrentEditEmpresa({ ...currentEditEmpresa, email: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="edit-estado-empresa"
                      checked={currentEditEmpresa.estado}
                      onCheckedChange={(checked) =>
                        setCurrentEditEmpresa({ ...currentEditEmpresa, estado: checked as boolean })
                      }
                    />
                    <label htmlFor="edit-estado-empresa" className="text-sm">
                      Empresa activa
                    </label>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsEditEmpresaModalOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
                  Guardar Cambios
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  )
}
