"use client"

import { useState } from "react"
import { usePathname } from "next/navigation"
import { Search, Bell, ChevronDown } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useRouter } from "next/navigation"

export function Header() {
  const pathname = usePathname()
  const [notifications, setNotifications] = useState(3)
  const router = useRouter()

  const getPageTitle = () => {
    const path = pathname.split("/")[1]

    const titles = {
      dashboard: "Bienvenido, Legal Hub",
      asistente: "Asistente Legal",
      documentos: "Documentos",
      correos: "Correos",
      calendario: "Calendario",
      tareas: "Tareas",
      casos: "Casos",
      clientes: "Clientes",
      contactos: "Contactos",
      contabilidad: "Contabilidad",
      ajustes: "Ajustes",
      administracion: "Administración",
    }

    return titles[path] || "Legal Hub"
  }

  const handleLogout = () => {
    // Eliminar datos de sesión
    localStorage.removeItem("isAuthenticated")
    localStorage.removeItem("user")

    // Redirigir al login
    router.push("/login")
  }

  return (
    <header className="bg-white shadow-sm h-16 flex items-center justify-between px-6 sticky top-0 z-10 border-b border-gray-200">
      <h2 id="page-title" className="text-lg font-semibold text-gray-800">
        {getPageTitle()}
      </h2>
      <div className="flex items-center space-x-3">
        <button className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-700">
          <Search size={18} />
        </button>
        <button className="p-1.5 rounded-full hover:bg-gray-100 text-gray-500 hover:text-gray-700 relative">
          <Bell size={18} />
          {notifications > 0 && (
            <span className="absolute top-0.5 right-0.5 block h-2 w-2 rounded-full bg-red-500 ring-1 ring-white"></span>
          )}
        </button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <div className="flex items-center space-x-2 cursor-pointer">
              <Avatar className="h-8 w-8">
                <AvatarImage src="/placeholder.svg" alt="Avatar de usuario" />
                <AvatarFallback className="bg-orange-500 text-white">FN</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium text-gray-700 hidden sm:inline">Federico Nicokvsy</span>
              <ChevronDown size={16} className="text-gray-500" />
            </div>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Perfil</DropdownMenuItem>
            <DropdownMenuItem>Ajustes</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-red-600" onClick={handleLogout}>
              Cerrar Sesión
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
