import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

export function RecentClients() {
  const clients = [
    {
      initial: "M",
      name: "Maria González",
      caso: "Divorcio",
      status: "Nuevo",
      statusColor: "blue",
    },
    {
      initial: "J",
      name: "Juan Rodriguez",
      caso: "Reclamación laboral",
      status: "Nuevo",
      statusColor: "blue",
    },
    {
      initial: "A",
      name: "Ana López",
      caso: "Herencia",
      status: "Activo",
      statusColor: "green",
    },
    {
      initial: "C",
      name: "Carlos Martinez",
      caso: "Constitución de empresa",
      status: "Activo",
      statusColor: "green",
    },
    {
      initial: "L",
      name: "Laura Fernández",
      caso: "Reclamación de deuda",
      status: "Activo",
      statusColor: "green",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Clientes Recientes</CardTitle>
        <CardDescription>Últimos clientes añadidos a la plataforma</CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-4">
          {clients.map((client, index) => (
            <li key={index} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback className="bg-gray-200 text-gray-600">{client.initial}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-gray-700">{client.name}</p>
                  <p className="text-xs text-gray-500">Caso: {client.caso}</p>
                </div>
              </div>
              <span
                className={`px-2.5 py-0.5 rounded text-xs font-semibold ${
                  client.statusColor === "blue" ? "bg-blue-100 text-blue-700" : "bg-green-100 text-green-700"
                }`}
              >
                {client.status}
              </span>
            </li>
          ))}
        </ul>
        <div className="text-right mt-4">
          <a href="/clientes" className="text-sm text-orange-600 hover:underline font-medium">
            Ver todos los clientes
          </a>
        </div>
      </CardContent>
    </Card>
  )
}
