"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  BrainCircuit,
  FileText,
  Mail,
  CalendarDays,
  FolderOpen,
  Users,
  Contact,
  Calculator,
  Settings,
  ShieldCheck,
  LogOut,
  ListTodo,
  ChevronLeft,
  ChevronRight,
  Menu,
  Bell,
  Building,
  UserCog,
  FolderArchive,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/components/auth/auth-provider"

export function Sidebar() {
  const pathname = usePathname()
  const [activePage, setActivePage] = useState("")
  const [collapsed, setCollapsed] = useState(false)
  const { user, hasPermission, isSuperAdmin } = useAuth()

  useEffect(() => {
    const path = pathname.split("/")[1]
    setActivePage(path || "dashboard")

    // Recuperar el estado del sidebar del localStorage
    const savedState = localStorage.getItem("sidebar-collapsed")
    if (savedState) {
      setCollapsed(savedState === "true")
    }
  }, [pathname])

  const toggleSidebar = () => {
    const newState = !collapsed
    setCollapsed(newState)
    localStorage.setItem("sidebar-collapsed", String(newState))
  }

  const handleLogout = () => {
    // Eliminar datos de sesión
    localStorage.removeItem("isAuthenticated")
    localStorage.removeItem("user")

    // Redirigir al login
    window.location.href = "/login"
  }

  // Definir todos los elementos de navegación
  const allNavItems = [
    { icon: LayoutDashboard, text: "Dashboard", target: "dashboard", module: "dashboard" },
    { icon: BrainCircuit, text: "Asistente Legal", target: "asistente", module: "asistente" },
    { icon: FileText, text: "Documentos", target: "documentos", module: "documentos" },
    { icon: Mail, text: "Correos", target: "correos", module: "correos", badge: 1 },
    { icon: CalendarDays, text: "Calendario", target: "calendario", module: "calendario" },
    { icon: ListTodo, text: "Tareas", target: "tareas", module: "tareas" },
    { icon: FolderOpen, text: "Casos", target: "casos", module: "casos" },
    { icon: Users, text: "Clientes", target: "clientes", module: "clientes" },
    { icon: Contact, text: "Contactos", target: "contactos", module: "contactos" },
    { icon: Calculator, text: "Contabilidad", target: "contabilidad", module: "contabilidad" },
    { icon: Bell, text: "Notificaciones", target: "notificaciones", module: "notificaciones" },
    { icon: FolderArchive, text: "Archivos", target: "archivos", module: "archivos" },
    { icon: UserCog, text: "Usuarios", target: "usuarios", module: "usuarios" },
    { icon: Building, text: "Empresas", target: "empresas", module: "empresas", superAdminOnly: true },
    { icon: Settings, text: "Ajustes", target: "ajustes", module: "ajustes" },
    { icon: ShieldCheck, text: "Administración", target: "administracion", module: "administracion" },
  ]

  // Filtrar elementos de navegación según permisos
  const navItems = allNavItems.filter((item) => {
    // Si es SuperAdmin, mostrar todo
    if (isSuperAdmin()) {
      return true
    }

    // Si es solo para SuperAdmin, no mostrar
    if (item.superAdminOnly) {
      return false
    }

    // Verificar permisos
    const permiso = user?.permisos?.[item.module]
    return permiso !== "ocultar"
  })

  return (
    <>
      <aside
        className={`bg-[#202123] text-gray-300 flex flex-col fixed h-full z-20 transition-all duration-300 ease-in-out ${
          collapsed ? "w-[70px]" : "w-64"
        }`}
      >
        <div className="h-16 flex items-center justify-between px-4 border-b border-gray-700">
          {!collapsed && <h1 className="text-xl font-bold text-white">Legal Hub</h1>}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className={`text-gray-300 hover:text-white hover:bg-gray-800 ${collapsed ? "mx-auto" : "ml-auto"}`}
          >
            {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
          </Button>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {navItems.map((item) => (
            <SidebarLink
              key={item.target}
              icon={item.icon}
              text={item.text}
              target={item.target}
              activeTarget={activePage}
              badgeCount={item.badge}
              collapsed={collapsed}
            />
          ))}
        </nav>
        <div className="p-3 mt-auto border-t border-gray-700">
          <button
            onClick={handleLogout}
            className={`flex items-center gap-3 py-2.5 px-4 rounded-md transition-colors duration-150 ease-in-out font-medium text-sm text-red-400 hover:bg-red-800 hover:text-white ${
              collapsed ? "justify-center px-2" : ""
            }`}
          >
            <LogOut size={18} />
            {!collapsed && <span>Cerrar Sesión</span>}
          </button>
        </div>
      </aside>

      {/* Mobile menu button - visible only on small screens */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed bottom-4 left-4 z-30 bg-gray-800 text-white rounded-full p-2 shadow-lg md:hidden"
        onClick={toggleSidebar}
      >
        <Menu size={24} />
      </Button>
    </>
  )
}

function SidebarLink({ icon: Icon, text, target, activeTarget, badgeCount, isLogout = false, collapsed }) {
  const isActive = activeTarget === target

  const baseStyle =
    "flex items-center gap-3 py-2.5 px-4 rounded-md transition-colors duration-150 ease-in-out font-medium text-sm"
  const inactiveStyle = `text-gray-300 hover:bg-gray-800 hover:text-white`
  const activeStyle = "bg-gray-700 text-white"
  const logoutStyle = "text-red-400 hover:bg-red-800 hover:text-white"

  return (
    <Link
      href={isLogout ? "/login" : `/${target}`}
      className={`${baseStyle} ${isActive ? activeStyle : isLogout ? logoutStyle : inactiveStyle} ${
        collapsed ? "justify-center px-2" : ""
      }`}
    >
      <Icon size={18} />
      {!collapsed && (
        <>
          <span>{text}</span>
          {badgeCount && badgeCount > 0 && !isLogout && (
            <span className="ml-auto bg-orange-500 text-white text-xs font-semibold mr-1 px-2 py-0.5 rounded-full">
              {badgeCount}
            </span>
          )}
        </>
      )}
      {collapsed && badgeCount && badgeCount > 0 && !isLogout && (
        <span className="absolute top-0 right-0 bg-orange-500 text-white text-xs font-semibold w-4 h-4 flex items-center justify-center rounded-full">
          {badgeCount}
        </span>
      )}
    </Link>
  )
}
