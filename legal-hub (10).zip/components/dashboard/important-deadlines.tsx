import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, Clock, FileText, Landmark } from "lucide-react"

export function ImportantDeadlines() {
  const deadlines = [
    {
      title: "Presentación de Recurso - Caso #2458",
      dueIn: "2 días",
      priority: "Urgente",
      icon: AlertTriangle,
      iconBg: "bg-red-100",
      iconColor: "text-red-600",
      badgeBg: "bg-red-100",
      badgeColor: "text-red-700",
    },
    {
      title: "Audiencia Preliminar - Caso #1892",
      dueIn: "5 días",
      priority: "Importante",
      icon: Clock,
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      badgeBg: "bg-yellow-100",
      badgeColor: "text-yellow-700",
    },
    {
      title: "Entrega de Documentación - Caso #3201",
      dueIn: "7 días",
      priority: "Normal",
      icon: FileText,
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      badgeBg: "bg-gray-100",
      badgeColor: "text-gray-700",
    },
    {
      title: "Pago de Tasas Judiciales - Caso #7789",
      dueIn: "10 días",
      priority: "Normal",
      icon: Landmark,
      iconBg: "bg-indigo-100",
      iconColor: "text-indigo-600",
      badgeBg: "bg-gray-100",
      badgeColor: "text-gray-700",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Plazos importantes</CardTitle>
        <CardDescription>Próximos plazos legales a vencer</CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-4">
          {deadlines.map((deadline, index) => {
            const Icon = deadline.icon
            return (
              <li key={index} className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <span
                    className={`${deadline.iconBg} ${deadline.iconColor} p-1.5 rounded-full flex items-center justify-center`}
                  >
                    <Icon size={16} />
                  </span>
                  <div>
                    <span className="font-medium text-gray-700">{deadline.title}</span>
                    <p className="text-xs text-gray-500">Vence en {deadline.dueIn}</p>
                  </div>
                </div>
                <span
                  className={`${deadline.badgeBg} ${deadline.badgeColor} px-2.5 py-0.5 rounded text-xs font-semibold`}
                >
                  {deadline.priority}
                </span>
              </li>
            )
          })}
        </ul>
      </CardContent>
    </Card>
  )
}
