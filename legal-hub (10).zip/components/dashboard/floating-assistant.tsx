"use client"

import { useState } from "react"
import { MessageCircle, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

export function FloatingAssistant() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <button
        className="fixed bottom-8 right-8 bg-orange-500 text-white w-[50px] h-[50px] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform z-[1000]"
        title="Asistente Asis"
        onClick={() => setIsOpen(true)}
      >
        <MessageCircle />
      </button>

      {isOpen && (
        <div className="fixed bottom-8 right-8 z-[1001] w-80 md:w-96">
          <Card className="shadow-xl border-gray-200">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg">Asis - Asistente</CardTitle>
                <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <CardDescription>¿En qué puedo ayudarte hoy?</CardDescription>
            </CardHeader>
            <CardContent className="h-64 overflow-y-auto bg-gray-50 rounded-md p-3 space-y-4">
              <div className="bg-orange-100 p-3 rounded-lg inline-block max-w-[85%]">
                <p className="text-sm text-orange-800">
                  Hola, soy Asis, tu asistente legal. Puedo ayudarte con:
                  <br />• Agendar citas en el calendario
                  <br />• Enviar correos a contactos
                  <br />• Consultar información de casos
                  <br />• Iniciar flujos de trabajo
                </p>
              </div>
            </CardContent>
            <CardFooter className="pt-3">
              <div className="flex w-full gap-2">
                <Input placeholder="Escribe tu consulta aquí..." className="flex-grow" />
                <Button className="bg-orange-500 hover:bg-orange-600">Enviar</Button>
              </div>
            </CardFooter>
          </Card>
        </div>
      )}
    </>
  )
}
