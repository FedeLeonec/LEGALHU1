"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, ListChecks, MoreHorizontal, TrendingUp, Plus } from "lucide-react"
import { countClientes } from "@/app/actions/clientes"
import { getIngresosMensuales, countCasosMensuales } from "@/app/actions/transacciones"
import { getRecentTareas } from "@/app/actions/tareas"
import { useRouter } from "next/navigation"

export function DashboardMetrics() {
  const [clientesCount, setClientesCount] = useState(0)
  const [ingresosMensuales, setIngresosMensuales] = useState(0)
  const [casosMensuales, setCasosMensuales] = useState(0)
  const [tareas, setTareas] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true)

        // Obtener fecha actual para calcular mes y año
        const now = new Date()
        const currentMonth = now.getMonth() + 1 // JavaScript meses son 0-11
        const currentYear = now.getFullYear()

        // Cargar datos
        const clientesTotal = await countClientes()
        const ingresos = await getIngresosMensuales(currentMonth, currentYear)
        const casos = await countCasosMensuales(currentMonth, currentYear)
        const tareasRecientes = await getRecentTareas(3)

        // Actualizar estado
        setClientesCount(clientesTotal)
        setIngresosMensuales(ingresos)
        setCasosMensuales(casos)
        setTareas(tareasRecientes)
      } catch (error) {
        console.error("Error al cargar datos del dashboard:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()

    // Configurar intervalo para actualizar datos cada 30 segundos
    const interval = setInterval(() => {
      fetchData()
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-EC", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  const handleAddClient = () => {
    router.push("/clientes?action=new")
  }

  const handleAddDocument = () => {
    router.push("/documentos/nuevo")
  }

  const getPriorityClass = (priority: string) => {
    switch (priority) {
      case "Alta":
        return "bg-red-100 text-red-700"
      case "Urgente":
        return "bg-red-100 text-red-700"
      case "Media":
        return "bg-yellow-100 text-yellow-700"
      case "Baja":
        return "bg-green-100 text-green-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  return (
    <div>
      <div className="flex justify-end mb-6">
        <Button className="bg-orange-500 hover:bg-orange-600 text-white" onClick={handleAddDocument}>
          <Plus className="mr-2 h-4 w-4" />
          Nuevo documento
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <Card className="bg-orange-500 text-white border-none">
          <CardHeader className="pb-2">
            <div className="flex justify-between">
              <CardTitle className="text-lg font-semibold">Ingresos Mensuales</CardTitle>
              <button className="text-white opacity-70 hover:opacity-100">
                <MoreHorizontal size={18} />
              </button>
            </div>
            <CardDescription className="text-orange-100">{casosMensuales} Casos este mes</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-12 bg-orange-400/50 animate-pulse rounded"></div>
            ) : (
              <>
                <p className="text-3xl font-bold mb-1">{formatCurrency(ingresosMensuales)}</p>
                <div className="text-xs opacity-80 flex items-center">
                  <TrendingUp className="mr-1 h-3 w-3" />
                  <span className="font-semibold">Actualizado en tiempo real</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle className="text-lg font-semibold">Clientes</CardTitle>
              <Users className="text-gray-400" size={20} />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-12 bg-gray-200 animate-pulse rounded mb-4"></div>
            ) : (
              <p className="text-3xl font-bold text-gray-800 mb-4">{clientesCount}</p>
            )}
            <Button variant="outline" size="sm" onClick={handleAddClient}>
              Añadir
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle className="text-lg font-semibold">Lista de Tareas</CardTitle>
              <ListChecks className="text-gray-400" size={20} />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                <div className="h-6 bg-gray-200 animate-pulse rounded"></div>
                <div className="h-6 bg-gray-200 animate-pulse rounded"></div>
                <div className="h-6 bg-gray-200 animate-pulse rounded"></div>
              </div>
            ) : (
              <ul className="space-y-2.5">
                {tareas.length > 0 ? (
                  tareas.map((tarea) => (
                    <li key={tarea.id} className="flex justify-between items-center">
                      <span className="truncate">{tarea.titulo}</span>
                      <span
                        className={`${getPriorityClass(tarea.prioridad)} px-2.5 py-0.5 rounded text-xs font-semibold`}
                      >
                        {tarea.estado}
                      </span>
                    </li>
                  ))
                ) : (
                  <li className="text-gray-500 italic">No hay tareas pendientes</li>
                )}
              </ul>
            )}
            <div className="mt-4 text-right">
              <Button variant="link" className="text-orange-600 p-0 h-auto" onClick={() => router.push("/tareas")}>
                Ver todas las tareas
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
