"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Plus, Edit, Trash2, Filter, Flag, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth/auth-provider"

interface Task {
  id: number
  title: string
  assignedTo: string
  assignedToId: number
  dueDate: string
  status: string
  priority: string
  description?: string
  empresa: string
}

interface User {
  id: number
  nombre: string
  email: string
  rol: string
  empresa: string
  estado?: boolean
}

export function TareasManager() {
  // Envolvemos el uso de useAuth en un try-catch para manejar el error
  const auth = useAuth()
  let user = null
  try {
    user = auth.user
  } catch (error) {
    console.error("Error al usar useAuth:", error)
    // Continuamos con user = null
  }

  const [tasks, setTasks] = useState<Task[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isViewModalOpen, setIsViewModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [filterType, setFilterType] = useState("Mis Tareas")
  const [currentTask, setCurrentTask] = useState<Task | null>(null)

  const [newTask, setNewTask] = useState<Omit<Task, "id" | "assignedToId">>({
    title: "",
    assignedTo: "",
    dueDate: "",
    status: "Pendiente",
    priority: "Media",
    description: "",
    empresa: user?.empresa || "",
  })

  const { toast } = useToast()

  // Cargar usuarios y tareas al iniciar
  useEffect(() => {
    // Cargar usuarios
    const storedUsers = JSON.parse(localStorage.getItem("users") || "[]")
    setUsers(storedUsers)

    // Cargar tareas
    const storedTasks = localStorage.getItem("tasks")
    if (storedTasks) {
      try {
        setTasks(JSON.parse(storedTasks))
      } catch (error) {
        console.error("Error al cargar tareas:", error)
      }
    } else {
      // No inicializamos con tareas de ejemplo para mantener la plataforma limpia
      setTasks([])
      localStorage.setItem("tasks", JSON.stringify([]))
    }
  }, [])

  // Actualizar newTask cuando cambia el usuario
  useEffect(() => {
    setNewTask((prev) => ({
      ...prev,
      empresa: user?.empresa || "",
    }))
  }, [user])

  // Guardar tareas cuando cambien
  useEffect(() => {
    if (tasks.length > 0) {
      localStorage.setItem("tasks", JSON.stringify(tasks))
    }
  }, [tasks])

  // Filtrar usuarios según la empresa del usuario actual
  const filteredUsers = users.filter(
    (u) => u.estado !== false && (user?.role === "SuperAdmin" || u.empresa === user?.empresa),
  )

  const handleCreateTask = () => {
    setIsCreateModalOpen(true)
    setNewTask({
      title: "",
      assignedTo: "",
      dueDate: "",
      status: "Pendiente",
      priority: "Media",
      description: "",
      empresa: user?.empresa || "",
    })
  }

  const handleViewTask = (task: Task) => {
    setCurrentTask(task)
    setIsViewModalOpen(true)
  }

  const handleEditTask = (task: Task) => {
    setCurrentTask(task)
    setIsEditModalOpen(true)
  }

  const handleDeleteTask = (id: number) => {
    if (window.confirm("¿Está seguro que desea eliminar esta tarea?")) {
      setTasks((currentTasks) => currentTasks.filter((task) => task.id !== id))
      toast({
        title: "Tarea eliminada",
        description: "La tarea ha sido eliminada correctamente",
      })
    }
  }

  const handleNewTaskChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewTask((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleTaskPropertyChange = (property: string, value: string) => {
    setNewTask((prev) => ({
      ...prev,
      [property]: value,
    }))
  }

  const handleSaveNewTask = (e: React.FormEvent) => {
    e.preventDefault()

    // Validar datos
    if (!newTask.title || !newTask.assignedTo || !newTask.dueDate || !newTask.priority) {
      toast({
        title: "Error",
        description: "Todos los campos son obligatorios",
        variant: "destructive",
      })
      return
    }

    // Encontrar el ID del usuario asignado
    const assignedUser = users.find((u) => u.nombre === newTask.assignedTo)
    if (!assignedUser) {
      toast({
        title: "Error",
        description: "El usuario asignado no existe",
        variant: "destructive",
      })
      return
    }

    // Crear nueva tarea
    const taskToAdd = {
      ...newTask,
      id: Date.now(),
      assignedToId: assignedUser.id,
    }

    setTasks((prevTasks) => [taskToAdd, ...prevTasks])
    setIsCreateModalOpen(false)

    toast({
      title: "Tarea creada",
      description: "La tarea ha sido creada correctamente",
    })
  }

  const handleUpdateTask = (e: React.FormEvent) => {
    e.preventDefault()

    if (!currentTask) return

    // Validar datos
    if (!currentTask.title || !currentTask.assignedTo || !currentTask.dueDate || !currentTask.priority) {
      toast({
        title: "Error",
        description: "Todos los campos son obligatorios",
        variant: "destructive",
      })
      return
    }

    // Encontrar el ID del usuario asignado
    const assignedUser = users.find((u) => u.nombre === currentTask.assignedTo)
    if (!assignedUser) {
      toast({
        title: "Error",
        description: "El usuario asignado no existe",
        variant: "destructive",
      })
      return
    }

    // Actualizar tarea
    const updatedTask = {
      ...currentTask,
      assignedToId: assignedUser.id,
    }

    setTasks((prevTasks) => prevTasks.map((task) => (task.id === updatedTask.id ? updatedTask : task)))

    setIsEditModalOpen(false)
    setCurrentTask(null)

    toast({
      title: "Tarea actualizada",
      description: "La tarea ha sido actualizada correctamente",
    })
  }

  const handleStatusChange = (taskId: number, newStatus: string) => {
    setTasks((prevTasks) => prevTasks.map((task) => (task.id === taskId ? { ...task, status: newStatus } : task)))

    toast({
      title: "Estado actualizado",
      description: `La tarea ha sido marcada como "${newStatus}"`,
    })
  }

  const getStatusClass = (status: string) => {
    switch (status) {
      case "Pendiente":
        return "bg-yellow-100 text-yellow-800 border-yellow-300"
      case "En Progreso":
        return "bg-blue-100 text-blue-800 border-blue-300"
      case "Completada":
        return "bg-green-100 text-green-800 border-green-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  const getPriorityClass = (priority: string) => {
    switch (priority) {
      case "Alta":
        return "text-red-500"
      case "Urgente":
        return "text-red-700 font-bold"
      case "Media":
        return "text-yellow-500"
      case "Baja":
        return "text-green-500"
      default:
        return "text-gray-500"
    }
  }

  // Filtrar tareas según el filtro seleccionado y la empresa del usuario
  const filteredTasks = tasks.filter((task) => {
    // Filtrar por empresa del usuario actual (excepto SuperAdmin que ve todas)
    const matchesEmpresa = user?.role === "SuperAdmin" || task.empresa === user?.empresa

    // Aplicar filtros adicionales
    let matchesFilter = true
    switch (filterType) {
      case "Mis Tareas":
        matchesFilter = true // Mostrar todas las de su empresa
        break
      case "Asignadas a mí":
        matchesFilter = task.assignedTo === user?.name
        break
      case "Pendientes":
        matchesFilter = task.status === "Pendiente"
        break
      case "En Progreso":
        matchesFilter = task.status === "En Progreso"
        break
      case "Completadas":
        matchesFilter = task.status === "Completada"
        break
    }

    return matchesEmpresa && matchesFilter
  })

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
          <h3 className="text-lg font-semibold text-gray-800">Gestión de Tareas</h3>
          <div className="flex items-center space-x-4">
            <div className="flex items-center text-sm">
              <label htmlFor="filter-tareas" className="mr-2 text-gray-600 flex items-center gap-1">
                <Filter size={14} />
                Filtrar:
              </label>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger id="filter-tareas" className="w-[150px]">
                  <SelectValue placeholder="Mis Tareas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mis Tareas">Mis Tareas</SelectItem>
                  <SelectItem value="Asignadas a mí">Asignadas a mí</SelectItem>
                  <SelectItem value="Pendientes">Pendientes</SelectItem>
                  <SelectItem value="En Progreso">En Progreso</SelectItem>
                  <SelectItem value="Completadas">Completadas</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleCreateTask} className="bg-orange-500 hover:bg-orange-600">
              <Plus size={16} className="mr-2" />
              Crear Tarea
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-2/5">Tarea</TableHead>
                <TableHead>Asignado a</TableHead>
                <TableHead>Vencimiento</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Prioridad</TableHead>
                <TableHead className="text-center">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTasks.length > 0 ? (
                filteredTasks.map((task) => (
                  <TableRow key={task.id}>
                    <TableCell className="font-medium text-gray-900">{task.title}</TableCell>
                    <TableCell className="text-gray-500">{task.assignedTo}</TableCell>
                    <TableCell className="text-gray-500">{task.dueDate}</TableCell>
                    <TableCell>
                      <Select value={task.status} onValueChange={(value) => handleStatusChange(task.id, value)}>
                        <SelectTrigger
                          className={`inline-block px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusClass(task.status)}`}
                        >
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Pendiente">Pendiente</SelectItem>
                          <SelectItem value="En Progreso">En Progreso</SelectItem>
                          <SelectItem value="Completada">Completada</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <span className={`font-medium flex items-center gap-1 ${getPriorityClass(task.priority)}`}>
                        <Flag size={14} className={getPriorityClass(task.priority)} />
                        {task.priority}
                      </span>
                    </TableCell>
                    <TableCell className="text-center space-x-2">
                      <Button variant="ghost" size="icon" onClick={() => handleViewTask(task)} title="Ver Tarea">
                        <Eye size={16} className="text-gray-400 hover:text-blue-600" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleEditTask(task)} title="Editar Tarea">
                        <Edit size={16} className="text-gray-400 hover:text-blue-600" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteTask(task.id)}
                        title="Eliminar Tarea"
                      >
                        <Trash2 size={16} className="text-gray-400 hover:text-red-600" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-4 text-gray-500 italic">
                    No hay tareas para mostrar.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>

      {/* Modal para crear tarea */}
      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Crear Nueva Tarea</DialogTitle>
            <DialogDescription>Complete los detalles para crear una nueva tarea</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSaveNewTask}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">
                  Tarea <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="title"
                  name="title"
                  value={newTask.title}
                  onChange={handleNewTaskChange}
                  required
                  rows={3}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={newTask.description || ""}
                  onChange={handleNewTaskChange}
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="assignedTo">
                    Asignado a <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={newTask.assignedTo}
                    onValueChange={(value) => handleTaskPropertyChange("assignedTo", value)}
                  >
                    <SelectTrigger id="assignedTo">
                      <SelectValue placeholder="Seleccionar usuario" />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredUsers.map((user) => (
                        <SelectItem key={user.id} value={user.nombre}>
                          {user.nombre}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dueDate">
                    Fecha Vencimiento <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    type="date"
                    id="dueDate"
                    name="dueDate"
                    value={newTask.dueDate}
                    onChange={handleNewTaskChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="priority">
                    Prioridad <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={newTask.priority}
                    onValueChange={(value) => handleTaskPropertyChange("priority", value)}
                  >
                    <SelectTrigger id="priority">
                      <SelectValue placeholder="Seleccionar prioridad" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Baja">Baja</SelectItem>
                      <SelectItem value="Media">Media</SelectItem>
                      <SelectItem value="Alta">Alta</SelectItem>
                      <SelectItem value="Urgente">Urgente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
                Guardar Tarea
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Modal para ver tarea */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Detalles de la Tarea</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <h3 className="font-semibold text-lg">{currentTask?.title}</h3>
              <p className="text-sm text-gray-500 mt-1">ID: {currentTask?.id}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-gray-500">Asignado a</p>
                <p>{currentTask?.assignedTo}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Fecha de vencimiento</p>
                <p>{currentTask?.dueDate}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Estado</p>
                <p
                  className={`inline-block px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusClass(currentTask?.status || "")}`}
                >
                  {currentTask?.status}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Prioridad</p>
                <p className={`font-medium flex items-center gap-1 ${getPriorityClass(currentTask?.priority || "")}`}>
                  <Flag size={14} className={getPriorityClass(currentTask?.priority || "")} />
                  {currentTask?.priority}
                </p>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-gray-500">Descripción</p>
              <p className="mt-1">{currentTask?.description || "Sin descripción"}</p>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsViewModalOpen(false)}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para editar tarea */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Tarea</DialogTitle>
            <DialogDescription>Modifique los detalles de la tarea</DialogDescription>
          </DialogHeader>
          {currentTask && (
            <form onSubmit={handleUpdateTask}>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-title">
                    Tarea <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="edit-title"
                    value={currentTask.title}
                    onChange={(e) => setCurrentTask({ ...currentTask, title: e.target.value })}
                    required
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-description">Descripción</Label>
                  <Textarea
                    id="edit-description"
                    value={currentTask.description || ""}
                    onChange={(e) => setCurrentTask({ ...currentTask, description: e.target.value })}
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-assignedTo">
                      Asignado a <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={currentTask.assignedTo}
                      onValueChange={(value) => setCurrentTask({ ...currentTask, assignedTo: value })}
                    >
                      <SelectTrigger id="edit-assignedTo">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {filteredUsers.map((user) => (
                          <SelectItem key={user.id} value={user.nombre}>
                            {user.nombre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-dueDate">
                      Fecha Vencimiento <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      type="date"
                      id="edit-dueDate"
                      value={currentTask.dueDate}
                      onChange={(e) => setCurrentTask({ ...currentTask, dueDate: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-priority">
                      Prioridad <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={currentTask.priority}
                      onValueChange={(value) => setCurrentTask({ ...currentTask, priority: value })}
                    >
                      <SelectTrigger id="edit-priority">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Baja">Baja</SelectItem>
                        <SelectItem value="Media">Media</SelectItem>
                        <SelectItem value="Alta">Alta</SelectItem>
                        <SelectItem value="Urgente">Urgente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-status">
                    Estado <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={currentTask.status}
                    onValueChange={(value) => setCurrentTask({ ...currentTask, status: value })}
                  >
                    <SelectTrigger id="edit-status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pendiente">Pendiente</SelectItem>
                      <SelectItem value="En Progreso">En Progreso</SelectItem>
                      <SelectItem value="Completada">Completada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsEditModalOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-orange-500 hover:bg-orange-600">
                  Guardar Cambios
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  )
}
