"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { FolderPlus, Search, FolderOpen, Lock, File, Download, Eye, Trash2, Upload } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { supabaseClient } from "@/lib/supabase"

export function ArchivosManager() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [carpetas, setCarpetas] = useState([])
  const [carpetaActual, setCarpetaActual] = useState(null)
  const [archivos, setArchivos] = useState([])
  const [busqueda, setBusqueda] = useState("")
  const [isCreatingFolder, setIsCreatingFolder] = useState(false)
  const [isUploadingFile, setIsUploadingFile] = useState(false)
  const [isPasswordPrompt, setIsPasswordPrompt] = useState(false)
  const [passwordInput, setPasswordInput] = useState("")
  const [selectedCarpeta, setSelectedCarpeta] = useState(null)
  const [clientes, setClientes] = useState([])
  const [usuarios, setUsuarios] = useState([])
  const [casos, setCasos] = useState([])

  // Formulario para nueva carpeta
  const [nuevaCarpeta, setNuevaCarpeta] = useState({
    nombre: "",
    cliente_id: "",
    abogado_id: "",
    caso_id: "",
    tiene_password: false,
    password: "",
  })

  // Cargar datos iniciales
  useEffect(() => {
    cargarCarpetas()
    cargarClientes()
    cargarUsuarios()
    cargarCasos()
  }, [user])

  // Función para cargar carpetas
  const cargarCarpetas = async () => {
    try {
      // Si es SuperAdmin, carga todas las carpetas
      // Si no, carga solo las carpetas de su empresa
      let query = supabaseClient.from("carpetas").select("*")

      if (user && user.role !== "SuperAdmin") {
        query = query.eq("empresa_id", user.empresa)
      }

      const { data, error } = await query.order("created_at", { ascending: false })

      if (error) throw error

      setCarpetas(data || [])
    } catch (error) {
      console.error("Error al cargar carpetas:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar las carpetas",
        variant: "destructive",
      })
    }
  }

  // Función para cargar clientes
  const cargarClientes = async () => {
    try {
      let query = supabaseClient.from("clientes").select("*")

      if (user && user.role !== "SuperAdmin") {
        query = query.eq("empresa_id", user.empresa)
      }

      const { data, error } = await query

      if (error) throw error

      setClientes(data || [])
    } catch (error) {
      console.error("Error al cargar clientes:", error)
    }
  }

  // Función para cargar usuarios
  const cargarUsuarios = async () => {
    try {
      // Obtener usuarios desde localStorage para simplificar
      const storedUsers = JSON.parse(localStorage.getItem("users") || "[]")

      // Filtrar por empresa si no es SuperAdmin
      let filteredUsers = storedUsers
      if (user && user.role !== "SuperAdmin") {
        filteredUsers = storedUsers.filter((u) => u.empresa === user.empresa)
      }

      setUsuarios(filteredUsers)
    } catch (error) {
      console.error("Error al cargar usuarios:", error)
    }
  }

  // Función para cargar casos
  const cargarCasos = async () => {
    try {
      let query = supabaseClient.from("casos").select("*")

      if (user && user.role !== "SuperAdmin") {
        query = query.eq("empresa_id", user.empresa)
      }

      const { data, error } = await query

      if (error) throw error

      setCasos(data || [])
    } catch (error) {
      console.error("Error al cargar casos:", error)
    }
  }

  // Función para crear una nueva carpeta
  const crearCarpeta = async () => {
    try {
      if (!nuevaCarpeta.nombre) {
        toast({
          title: "Error",
          description: "El nombre de la carpeta es obligatorio",
          variant: "destructive",
        })
        return
      }

      const carpetaData = {
        ...nuevaCarpeta,
        empresa_id: user.empresa,
        creado_por: user.id,
        created_at: new Date().toISOString(),
      }

      const { data, error } = await supabaseClient.from("carpetas").insert(carpetaData).select()

      if (error) throw error

      toast({
        title: "Carpeta creada",
        description: "La carpeta se ha creado correctamente",
      })

      // Limpiar formulario y recargar carpetas
      setNuevaCarpeta({
        nombre: "",
        cliente_id: "",
        abogado_id: "",
        caso_id: "",
        tiene_password: false,
        password: "",
      })

      setIsCreatingFolder(false)
      cargarCarpetas()
    } catch (error) {
      console.error("Error al crear carpeta:", error)
      toast({
        title: "Error",
        description: "No se pudo crear la carpeta",
        variant: "destructive",
      })
    }
  }

  // Función para abrir una carpeta
  const abrirCarpeta = (carpeta) => {
    if (carpeta.tiene_password) {
      setSelectedCarpeta(carpeta)
      setIsPasswordPrompt(true)
    } else {
      setCarpetaActual(carpeta)
      cargarArchivos(carpeta.id)
    }
  }

  // Función para verificar contraseña
  const verificarPassword = () => {
    if (passwordInput === selectedCarpeta.password) {
      setCarpetaActual(selectedCarpeta)
      cargarArchivos(selectedCarpeta.id)
      setIsPasswordPrompt(false)
      setPasswordInput("")
    } else {
      toast({
        title: "Error",
        description: "Contraseña incorrecta",
        variant: "destructive",
      })
    }
  }

  // Función para cargar archivos de una carpeta
  const cargarArchivos = async (carpetaId) => {
    try {
      const { data, error } = await supabaseClient
        .from("archivos")
        .select("*")
        .eq("carpeta_id", carpetaId)
        .order("created_at", { ascending: false })

      if (error) throw error

      setArchivos(data || [])
    } catch (error) {
      console.error("Error al cargar archivos:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar los archivos",
        variant: "destructive",
      })
    }
  }

  // Función para subir un archivo
  const subirArchivo = async (e) => {
    const file = e.target.files[0]
    if (!file) return

    try {
      setIsUploadingFile(true)

      // 1. Subir el archivo al storage
      const fileExt = file.name.split(".").pop()
      const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`
      const filePath = `archivos/${carpetaActual.id}/${fileName}`

      const { data: uploadData, error: uploadError } = await supabaseClient.storage
        .from("legalhub")
        .upload(filePath, file)

      if (uploadError) throw uploadError

      // 2. Obtener la URL pública
      const { data: urlData } = await supabaseClient.storage.from("legalhub").getPublicUrl(filePath)

      // 3. Guardar referencia en la base de datos
      const archivoData = {
        nombre: file.name,
        tipo: file.type,
        tamano: file.size,
        url: urlData.publicUrl,
        carpeta_id: carpetaActual.id,
        subido_por: user.id,
        created_at: new Date().toISOString(),
      }

      const { error: dbError } = await supabaseClient.from("archivos").insert(archivoData)

      if (dbError) throw dbError

      toast({
        title: "Archivo subido",
        description: "El archivo se ha subido correctamente",
      })

      // Recargar archivos
      cargarArchivos(carpetaActual.id)
    } catch (error) {
      console.error("Error al subir archivo:", error)
      toast({
        title: "Error",
        description: "No se pudo subir el archivo",
        variant: "destructive",
      })
    } finally {
      setIsUploadingFile(false)
    }
  }

  // Función para eliminar un archivo
  const eliminarArchivo = async (archivo) => {
    try {
      // 1. Eliminar el archivo del storage
      const filePath = archivo.url.split("legalhub/")[1]

      const { error: storageError } = await supabaseClient.storage.from("legalhub").remove([filePath])

      if (storageError) throw storageError

      // 2. Eliminar la referencia de la base de datos
      const { error: dbError } = await supabaseClient.from("archivos").delete().eq("id", archivo.id)

      if (dbError) throw dbError

      toast({
        title: "Archivo eliminado",
        description: "El archivo se ha eliminado correctamente",
      })

      // Recargar archivos
      cargarArchivos(carpetaActual.id)
    } catch (error) {
      console.error("Error al eliminar archivo:", error)
      toast({
        title: "Error",
        description: "No se pudo eliminar el archivo",
        variant: "destructive",
      })
    }
  }

  // Función para volver a la lista de carpetas
  const volverACarpetas = () => {
    setCarpetaActual(null)
    setArchivos([])
  }

  // Filtrar carpetas por búsqueda
  const carpetasFiltradas = carpetas.filter((carpeta) => carpeta.nombre.toLowerCase().includes(busqueda.toLowerCase()))

  return (
    <div className="space-y-4">
      {/* Barra de acciones */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar carpetas..."
            className="pl-8"
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
          />
        </div>
        <Button onClick={() => setIsCreatingFolder(true)} className="bg-orange-500 hover:bg-orange-600">
          <FolderPlus className="mr-2 h-4 w-4" /> + Archivos
        </Button>
      </div>

      {/* Contenido principal */}
      {carpetaActual ? (
        <div className="space-y-4">
          {/* Cabecera de carpeta actual */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={volverACarpetas}>
                Volver
              </Button>
              <h2 className="text-xl font-semibold">{carpetaActual.nombre}</h2>
            </div>
            <div>
              <input
                type="file"
                id="file-upload"
                className="hidden"
                onChange={subirArchivo}
                disabled={isUploadingFile}
              />
              <label htmlFor="file-upload">
                <Button asChild>
                  <span>
                    <Upload className="mr-2 h-4 w-4" />
                    {isUploadingFile ? "Subiendo..." : "Subir archivo"}
                  </span>
                </Button>
              </label>
            </div>
          </div>

          {/* Lista de archivos */}
          {archivos.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {archivos.map((archivo) => (
                <Card key={archivo.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="p-4">
                      <div className="flex items-start gap-3">
                        <File className="h-10 w-10 text-blue-500 shrink-0" />
                        <div className="flex-1 overflow-hidden">
                          <h3 className="font-medium truncate" title={archivo.nombre}>
                            {archivo.nombre}
                          </h3>
                          <p className="text-sm text-gray-500">{(archivo.tamano / 1024 / 1024).toFixed(2)} MB</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex border-t">
                      <a
                        href={archivo.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 p-2 text-center hover:bg-gray-100 text-blue-600"
                      >
                        <Eye className="h-4 w-4 mx-auto" />
                      </a>
                      <a
                        href={archivo.url}
                        download
                        className="flex-1 p-2 text-center hover:bg-gray-100 text-green-600 border-l border-r"
                      >
                        <Download className="h-4 w-4 mx-auto" />
                      </a>
                      <button
                        onClick={() => eliminarArchivo(archivo)}
                        className="flex-1 p-2 text-center hover:bg-gray-100 text-red-600"
                      >
                        <Trash2 className="h-4 w-4 mx-auto" />
                      </button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-10 border rounded-lg">
              <File className="h-12 w-12 mx-auto text-gray-400" />
              <h3 className="mt-4 text-lg font-medium">No hay archivos</h3>
              <p className="mt-1 text-gray-500">Sube archivos a esta carpeta para comenzar</p>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {carpetasFiltradas.length > 0 ? (
            carpetasFiltradas.map((carpeta) => (
              <Card
                key={carpeta.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => abrirCarpeta(carpeta)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    {carpeta.tiene_password ? (
                      <div className="relative">
                        <FolderOpen className="h-10 w-10 text-orange-500" />
                        <Lock className="h-4 w-4 absolute -right-1 -bottom-1 text-gray-600" />
                      </div>
                    ) : (
                      <FolderOpen className="h-10 w-10 text-orange-500" />
                    )}
                    <div>
                      <h3 className="font-medium">{carpeta.nombre}</h3>
                      <p className="text-sm text-gray-500">{new Date(carpeta.created_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-10 border rounded-lg">
              <FolderOpen className="h-12 w-12 mx-auto text-gray-400" />
              <h3 className="mt-4 text-lg font-medium">No hay carpetas</h3>
              <p className="mt-1 text-gray-500">
                {busqueda
                  ? "No se encontraron carpetas con ese nombre"
                  : "Crea una carpeta para comenzar a organizar tus archivos"}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Modal para crear carpeta */}
      <Dialog open={isCreatingFolder} onOpenChange={setIsCreatingFolder}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Crear nueva carpeta</DialogTitle>
            <DialogDescription>Ingresa la información para crear una nueva carpeta de archivos</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="nombre">Nombre de la carpeta</Label>
              <Input
                id="nombre"
                value={nuevaCarpeta.nombre}
                onChange={(e) => setNuevaCarpeta({ ...nuevaCarpeta, nombre: e.target.value })}
                placeholder="Ej: Documentos Caso XYZ"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cliente">Cliente</Label>
              <Select
                value={nuevaCarpeta.cliente_id}
                onValueChange={(value) => setNuevaCarpeta({ ...nuevaCarpeta, cliente_id: value })}
              >
                <SelectTrigger id="cliente">
                  <SelectValue placeholder="Seleccionar cliente" />
                </SelectTrigger>
                <SelectContent>
                  {clientes.map((cliente) => (
                    <SelectItem key={cliente.id} value={cliente.id}>
                      {cliente.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="abogado">Abogado asignado</Label>
              <Select
                value={nuevaCarpeta.abogado_id}
                onValueChange={(value) => setNuevaCarpeta({ ...nuevaCarpeta, abogado_id: value })}
              >
                <SelectTrigger id="abogado">
                  <SelectValue placeholder="Seleccionar abogado" />
                </SelectTrigger>
                <SelectContent>
                  {usuarios
                    .filter((u) => u.rol === "Abogado" || u.rol === "Admin")
                    .map((usuario) => (
                      <SelectItem key={usuario.id} value={usuario.id}>
                        {usuario.nombre}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="caso">Caso</Label>
              <Select
                value={nuevaCarpeta.caso_id}
                onValueChange={(value) => setNuevaCarpeta({ ...nuevaCarpeta, caso_id: value })}
              >
                <SelectTrigger id="caso">
                  <SelectValue placeholder="Seleccionar caso" />
                </SelectTrigger>
                <SelectContent>
                  {casos.map((caso) => (
                    <SelectItem key={caso.id} value={caso.id}>
                      {caso.titulo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="tiene_password"
                checked={nuevaCarpeta.tiene_password}
                onCheckedChange={(checked) => setNuevaCarpeta({ ...nuevaCarpeta, tiene_password: checked === true })}
              />
              <label
                htmlFor="tiene_password"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Proteger con contraseña
              </label>
            </div>
            {nuevaCarpeta.tiene_password && (
              <div className="space-y-2">
                <Label htmlFor="password">Contraseña</Label>
                <Input
                  id="password"
                  type="password"
                  value={nuevaCarpeta.password}
                  onChange={(e) => setNuevaCarpeta({ ...nuevaCarpeta, password: e.target.value })}
                  placeholder="Ingresa una contraseña"
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreatingFolder(false)}>
              Cancelar
            </Button>
            <Button onClick={crearCarpeta} className="bg-orange-500 hover:bg-orange-600">
              Crear carpeta
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para ingresar contraseña */}
      <Dialog open={isPasswordPrompt} onOpenChange={setIsPasswordPrompt}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Carpeta protegida</DialogTitle>
            <DialogDescription>
              Esta carpeta está protegida con contraseña. Ingresa la contraseña para acceder.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="password-input">Contraseña</Label>
              <Input
                id="password-input"
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Ingresa la contraseña"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPasswordPrompt(false)}>
              Cancelar
            </Button>
            <Button onClick={verificarPassword} className="bg-orange-500 hover:bg-orange-600">
              Acceder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
