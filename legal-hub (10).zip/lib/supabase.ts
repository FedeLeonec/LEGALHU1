import { createClient } from "@supabase/supabase-js"

// Valores predeterminados en caso de que las variables de entorno no estén disponibles
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://vqjkpliuqjoqfascbhgh.supabase.co"
const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZxamtwbGl1cWpvcWZhc2NiaGdoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTMzNjY0MDAsImV4cCI6MjAyODk0MjQwMH0.Nh0fPXLQnbGaGN2rvw1FBGJ7HnJJOaFmR3WXS-QQmDY"

// Singleton para el cliente de Supabase (lado del cliente)
let supabaseClientInstance = null

export const getSupabaseClient = () => {
  if (supabaseClientInstance) return supabaseClientInstance

  supabaseClientInstance = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    },
  })

  return supabaseClientInstance
}

// Función para obtener el cliente (asegura que solo se crea una instancia)
export const supabaseClient = getSupabaseClient()

// Crear un cliente para el lado del servidor con la clave de servicio
export const createServerSupabaseClient = () => {
  const serverSupabaseUrl = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || supabaseUrl
  const serverSupabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || supabaseAnonKey

  return createClient(serverSupabaseUrl, serverSupabaseKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  })
}

// Función para manejar errores de Supabase de manera consistente
export const handleSupabaseError = (error: any) => {
  console.error("Error de Supabase:", error)
  return {
    error: true,
    message: error?.message || "Ha ocurrido un error en la conexión con la base de datos",
    details: error?.details || null,
  }
}
