import { generateText } from "ai"
import { groq } from "@ai-sdk/groq"

// Función para generar respuestas con IA
export async function generateLegalResponse(prompt: string) {
  try {
    const { text } = await generateText({
      model: groq("llama3-70b-8192"),
      prompt: `Eres un asistente legal experto. Responde a la siguiente consulta de manera profesional y precisa: ${prompt}`,
      maxTokens: 1000,
    })
    return text
  } catch (error) {
    console.error("Error al generar respuesta con IA:", error)
    return "Lo siento, no pude procesar tu consulta en este momento. Por favor, intenta de nuevo más tarde."
  }
}

// Función para generar documentos legales
export async function generateLegalDocument(type: string, details: string) {
  try {
    const { text } = await generateText({
      model: groq("llama3-70b-8192"),
      prompt: `Genera un documento legal de tipo ${type} con los siguientes detalles: ${details}. Formatea el documento de manera profesional y completa.`,
      maxTokens: 2000,
    })
    return text
  } catch (error) {
    console.error("Error al generar documento con IA:", error)
    return "Lo siento, no pude generar el documento en este momento. Por favor, intenta de nuevo más tarde."
  }
}

// Función para analizar documentos
export async function analyzeLegalDocument(content: string) {
  try {
    const { text } = await generateText({
      model: groq("llama3-70b-8192"),
      prompt: `Analiza el siguiente documento legal y proporciona un análisis detallado de sus implicaciones, posibles riesgos y recomendaciones: ${content}`,
      maxTokens: 1500,
    })
    return text
  } catch (error) {
    console.error("Error al analizar documento con IA:", error)
    return "Lo siento, no pude analizar el documento en este momento. Por favor, intenta de nuevo más tarde."
  }
}

// Función para resumir documentos
export async function summarizeLegalDocument(content: string) {
  try {
    const { text } = await generateText({
      model: groq("llama3-70b-8192"),
      prompt: `Resume el siguiente documento legal de manera concisa pero manteniendo todos los puntos importantes: ${content}`,
      maxTokens: 800,
    })
    return text
  } catch (error) {
    console.error("Error al resumir documento con IA:", error)
    return "Lo siento, no pude resumir el documento en este momento. Por favor, intenta de nuevo más tarde."
  }
}

// Función para revisar y corregir documentos
export async function reviewLegalDocument(content: string) {
  try {
    const { text } = await generateText({
      model: groq("llama3-70b-8192"),
      prompt: `Revisa el siguiente documento legal, corrige errores ortográficos, gramaticales y de redacción, y sugiere mejoras para hacerlo más claro y efectivo: ${content}`,
      maxTokens: 1500,
    })
    return text
  } catch (error) {
    console.error("Error al revisar documento con IA:", error)
    return "Lo siento, no pude revisar el documento en este momento. Por favor, intenta de nuevo más tarde."
  }
}

// Función para responder preguntas sobre documentos
export async function answerQuestionsAboutDocument(document: string, question: string) {
  try {
    const { text } = await generateText({
      model: groq("llama3-70b-8192"),
      prompt: `Basándote en el siguiente documento legal: "${document}", responde a esta pregunta: "${question}"`,
      maxTokens: 1000,
    })
    return text
  } catch (error) {
    console.error("Error al responder pregunta con IA:", error)
    return "Lo siento, no pude responder a tu pregunta en este momento. Por favor, intenta de nuevo más tarde."
  }
}
